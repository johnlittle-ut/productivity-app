# Handoff 003 (OUTLINE): Connect the backend (Firebase) from John's personal laptop

Status: **outline only.** Craig 2 will finalize this into a full handoff when John is ready to start. Do not build from this yet.
Date: 2026-11-04.

## Purpose
Replace the local IndexedDB data layer with Firestore, add real Google sign-in with the invite-only allow-list, deploy to Firebase Hosting, and prove it on John's iPhone Home Screen app. All front-end screens should **not** need changes beyond the auth and data-layer swap.

## Preconditions
- John works from his **personal laptop** and personal Google account.
- The front-end repo is moved there (private GitHub repo, `git clone`). Node and Git installed normally.
- Planning docs (`CLAUDE.md`, `Plan.md`, `handoffs/`) copied into the repo.
- The front end (handoff 002) is complete and John has reviewed it.
- John may use the local app in the meantime; his data is exportable as versioned JSON.

## Steps (to be detailed)
1. **Firebase setup.** Reuse handoff 001 steps 3 (project on Spark plan, Google provider, Firestore in production mode, web app config in `.env`, Hosting). Dan 2 guides John click by click.
2. **Allow-list first.** Per handoff 001 step 5 and `Plan.md` 3.0: seed `allowedEmails/{John's lowercased email}` **before** deploying rules; per-user rules; friendly invite-only screen.
3. **Real auth.** Replace the auth stub with Firebase Google sign-in (popup first, redirect fallback, `authDomain` matching the hosted domain). Settings document created on first sign-in.
4. **Firestore data layer.** Implement the existing `DataLayer` interface on Firestore under `users/{uid}/...` with offline persistence enabled and real-time subscriptions. Keep the **local implementation selectable** (env flag) for development and tests. Same types, same behavior, same export format.
5. **Migrate John's data.** One-time **Import JSON** of the local export into Firestore, with validation and a confirm step. Keep a backup of the export file. Do not delete the local copy until John has verified the data in the cloud.
6. **Deploy.** Firebase Hosting; live URL; Home Screen install on iPhone.
7. **Acceptance tests.** Same checklist as handoff 001 step 7: standalone mode, **Google sign-in works in the Home Screen app**, stays signed in after closing, offline open, not-invited screen, added then removed account, John's settings exist. Plus: data created on the laptop appears on the iPhone and the reverse; edits sync; airplane-mode edits sync when back online.
8. **Docs.** README sections for running with either data layer, deploying, and adding or removing a person. Changelog entry.

## Risks to plan for
- Google sign-in inside the iPhone Home Screen app (the known weak point); stop and report if it fails.
- Firestore rules cost a small read per request; keep reads sensible.
- Two data layers must stay behavior-identical; shared contract tests recommended.

## Later phases (not in this handoff)
Phase 2 notifications and digest (per-user, Cloudflare Worker), Phase 3 read-only Scriptable widget, Phase 4 shared calendar. See `Plan.md`.
