// The one place the app picks its data-layer implementation.
// To connect Firebase later: build a Firestore implementation of DataLayer
// (see ./types.ts) and export it here instead of the Dexie one.

import { auth } from '../auth/auth'
import { createDexieDataLayer } from './dexieDataLayer'
import type { DataLayer } from './types'

export const dataLayer: DataLayer = createDexieDataLayer(auth.getUserId())
export type { DataLayer } from './types'
