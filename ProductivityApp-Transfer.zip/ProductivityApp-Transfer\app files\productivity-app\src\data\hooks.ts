import { useEffect, useState } from 'react'
import { dataLayer } from './index'
import type { Listener, Unsubscribe } from './types'
import type { Item, ListEntry, Settings } from '../types'

/** Subscribe to a data-layer collection; returns `initial` until the first value arrives. */
export function useSubscription<T>(subscribe: (cb: Listener<T>) => Unsubscribe, initial: T): T {
  const [value, setValue] = useState<T>(initial)
  useEffect(() => subscribe(setValue), [subscribe])
  return value
}

const subscribeItems = (cb: Listener<Item[]>) => dataLayer.items.subscribe(cb)
const subscribeShopping = (cb: Listener<ListEntry[]>) => dataLayer.shopping.subscribe(cb)
const subscribeTodos = (cb: Listener<ListEntry[]>) => dataLayer.todos.subscribe(cb)
const subscribeSettings = (cb: Listener<Settings | null>) =>
  dataLayer.settings.subscribe(cb as Listener<Settings>)

const EMPTY_ITEMS: Item[] = []
const EMPTY_LIST: ListEntry[] = []

export const useItems = () => useSubscription(subscribeItems, EMPTY_ITEMS)
export const useShopping = () => useSubscription(subscribeShopping, EMPTY_LIST)
export const useTodos = () => useSubscription(subscribeTodos, EMPTY_LIST)
/** Null until settings have loaded. */
export const useSettings = () => useSubscription<Settings | null>(subscribeSettings, null)
