// Gap-based ordering for the Shopping and To-Do lists: a drag changes ONE entry's `order`.

import { ORDER_GAP } from '../data/defaults'
import type { ListEntry } from '../types'

const MIN_GAP = 1e-6

/**
 * New `order` for the entry at `from` after it is dragged to index `to`
 * (indexes refer to the visible list, which excludes checked-off entries).
 * Lands between its new neighbours; at either end it goes one gap past the edge.
 */
export function orderForMove(list: ListEntry[], from: number, to: number): number {
  const rest = list.filter((_, i) => i !== from)
  const prev = rest[to - 1]
  const next = rest[to]
  if (!prev && !next) return ORDER_GAP
  if (!prev) return next.order - ORDER_GAP
  if (!next) return prev.order + ORDER_GAP
  return (prev.order + next.order) / 2
}

/** True when repeated midpoints have squeezed two neighbours too close together. */
export function needsRebalance(list: ListEntry[]): boolean {
  const sorted = [...list].sort((a, b) => a.order - b.order)
  return sorted.some((e, i) => i > 0 && e.order - sorted[i - 1].order < MIN_GAP)
}

/** Fresh evenly spaced orders for the whole list, keeping its current sequence. */
export function rebalanced(list: ListEntry[]): { id: string; order: number }[] {
  return [...list].sort((a, b) => a.order - b.order).map((e, i) => ({ id: e.id, order: (i + 1) * ORDER_GAP }))
}

/** Entries checked off 24h+ ago, to be deleted for good. */
export function expiredEntryIds(entries: ListEntry[], now: number, dayMs: number): string[] {
  const cutoff = now - dayMs
  return entries.filter((e) => e.done && e.doneAt !== null && e.doneAt <= cutoff).map((e) => e.id)
}

/** Entries checked off within the last 24h, newest first. */
export function recentEntries(entries: ListEntry[], now: number, dayMs: number): ListEntry[] {
  const cutoff = now - dayMs
  return entries
    .filter((e) => e.done && e.doneAt !== null && e.doneAt > cutoff)
    .sort((a, b) => (b.doneAt ?? 0) - (a.doneAt ?? 0))
}

/** Shopping sections. Entries without a section (older data) count as groceries. */
export const SHOPPING_SECTIONS = [
  { id: 'groceries', label: 'Groceries' },
  { id: 'general', label: 'General' },
] as const

export function sectionOf(entry: ListEntry): 'groceries' | 'general' {
  return entry.section ?? 'groceries'
}
