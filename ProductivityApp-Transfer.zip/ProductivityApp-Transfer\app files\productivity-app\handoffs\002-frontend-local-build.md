# Handoff 002: Build the full front end on a local dev server (no backend yet)

From: Craig 2 (planner). To: Dan 2 (builder). Relayed by John.
Date: 2026-11-04.
Supersedes in part: handoff 001 (see "What changed from handoff 001" below).

## Read first
1. `CLAUDE.md` (roles, workflow, changelog rules, constraints).
2. `Plan.md` (source of truth). **Sections 3 and 4 are the spec for data and screens.** This handoff only adds the overrides and the build order below. If something here conflicts with Plan.md, this handoff wins for the front end, and you should tell John so Craig 2 can update Plan.md.

## Why this changed
John must do the **backend (Firebase, Google sign-in, hosting) from his personal laptop**, because it is tied to his personal Google account. So for now we build the **whole front end running on a local dev server**, with data saved on the device, and John will review and request changes directly with you. The backend gets connected later in a separate handoff.

## Goal
Run `npm run dev`, open the local URL, and have a **fully working app** with all four tabs, backed by **local on-device storage**. John reviews it in a browser (laptop and phone-sized view), and asks you for tweaks directly. Nothing in this handoff may require a Google account, Firebase, a credit card, or any paid service.

## What changed from handoff 001
- **Still do:** Step 0 (working location), Step 1 (Node, Git), Step 2 (scaffold: Vite + React + TypeScript + `vite-plugin-pwa`, iOS meta tags, `.gitignore`), Step 6 (app shell, bottom tab bar, Settings gear, light and dark mode, safe areas).
- **Do NOT do yet (deferred to the backend phase, John's personal laptop):** Step 3 (Firebase project), Step 4 (Google sign-in), Step 5 (allow-list and security rules), Step 7 (deploy and iPhone sign-in test). Do not install Firebase packages or the Firebase CLI. Do not create a Firebase project.
- **Git:** `git init` and keep it committed locally. A **private GitHub repo** is still wanted so John can move the code to his personal laptop. Ask John whether he wants it pushed now (he may prefer to create the repo from his personal account). Never commit secrets or `.env` files.

## Architecture rules for this phase (important, so the backend swap is easy later)

1. **One data-layer module.** All reads and writes of items, shopping items, to-dos and settings go through a single data-layer interface. No screen or component touches storage directly. Rationale: later we replace the local implementation with Firestore, and Phase 4 adds a second data source (shared calendar).
2. **The interface must be subscription-style**, not one-off fetches. Screens subscribe to a collection and get called again whenever it changes (this mirrors how Firestore works, so the swap is clean). It needs: subscribe to items, add, update, delete; the same for shopping items and to-dos; get, subscribe to and update settings.
3. **Local implementation:** store data in the browser using **IndexedDB** (a small wrapper library such as Dexie or idb is fine; tell John which you pick). Data must survive closing the tab and restarting the dev server. Do not use `localStorage` for the main data.
4. **Per-user shape from day one** (see CLAUDE.md): store everything under a user key, using a **stub "local user"** id from an **auth abstraction** (a tiny module that for now simply returns the fixed local user, with a `signOut` that does nothing). No sign-in screen and no invite-only screen in this phase. No hard-coded personal email or UID. Later the real Google auth replaces the stub.
5. **Export and Import JSON** in Settings must produce one file with everything (items, shopping, todos, settings). This doubles as the **migration path** from local storage into Firestore later, so keep the format clean and versioned (include a `version` field).
6. **Dates and times:** dates are plain `YYYY-MM-DD` strings, times are `HH:mm` strings, per Plan.md. "Today" and "now" are computed in the **user's timezone setting** (default: the browser's timezone; John will set `America/New_York`). Never use UTC dates for day logic; daylight saving must not shift anything. Timestamps like `doneAt` may be real timestamps.
7. **Keep it simple and maintainable.** Standard React patterns, small files, clear names. Flag any extra library you want to add (drag and drop, date utilities, testing) to John before adding. Suggested: `@dnd-kit` for drag-to-reorder, `date-fns` or small hand-written helpers for dates, **Vitest** for tests.

## Spec: follow Plan.md sections 3 and 4, with these specifics

**Data model:** exactly as Plan.md 3.1 to 3.4 (items with `type` event/task, repeats weekly or monthly with `completedOccurrences` and `skippedDates`, `reminder` field saved but unused; shopping items and to-dos with `order`; per-user settings). Recurrence rules and month-end clamping as written. Occurrences are **calculated, never stored.**

**Colors and look:** events and tasks must be clearly different in color **and** icon or shape. Suggested events blue, tasks orange (Dan may refine; John will give feedback). Mobile-first, iPhone safe areas, system light and dark mode. Laptop layouts must work and look reasonable but get **no extra polish** (CLAUDE.md).

**Add/Edit form:** Title, Type toggle, Date, optional Time, optional End time (events), Notes, Repeat (None, Weekly, Monthly). **Hide all reminder UI** (keep the data field with defaults: events enabled at 60, tasks off). Editing or deleting a repeating item asks **this occurrence only** or **all occurrences**. Delete asks for confirmation.

**Daily Schedule tab (OneNote style):** continuous scroll from today forward, one block per date, header like `11/2` plus day name, **Mondays bold with extra spacing**, **every date shown even if empty**, load more dates as the user scrolls (about 60 days at a time). Within a date: timed items in time order, then untimed items as a checklist; time shown in the text ("Thrive at 6:30 PM"). Check circle on each item. Inline quick-add on each date (title only, expandable to the full form). **Overdue** section at the top for unfinished past **tasks**; past events and past dates do not appear.

**Calendar tab (week view):** Monday to Sunday, previous / next / Today controls, today highlighted. **Laptop (wide):** seven columns, untimed items at the top of each column, timed items in order. **Phone (narrow):** Monday to Sunday strip at the top with dots for days that have items, and the selected day's items below; swipe left or right to change week. Tap an item to view, edit, check off or delete. "+" adds on the selected day.

**Check-off and cleanup:** checking off hides the item immediately; **permanently deleted 24 hours after** checking off (for repeating items, check-off applies to **that occurrence** only). Cleanup runs when the app opens and when it returns to the foreground. **Undo** available during the 24 hours (toast right after, plus a small "Recently completed" area reachable from each tab or Settings; Dan picks a simple placement and tells John).

**Shopping List and To-Do tabs:** each a single list. Type to add; **new items go at the bottom**; **drag to reorder** using a drag handle (must work with touch on iPhone and mouse on laptop, and must not interfere with scrolling); check-off hides the item and it is deleted after 24 hours (with the same undo). To-Do items support optional notes.

**Settings:** timezone (default browser timezone, selectable), default reminder (can be omitted this phase), **Export JSON**, **Import JSON** (confirm before replacing; validate the file and show a friendly error if invalid), and a **developer section** (see below). No sign-out button.

**Developer section in Settings (show only in dev mode, hidden in production builds):**
- **Load sample data** and **Clear all data** (with confirmation).
- Sample data should reflect John's real OneNote page so he can judge the look immediately. Use dates relative to the current month. Include: Rent due (task, monthly, on the 1st); Module assignments due at 11:59 PM (tasks, e.g. weekly); an LG&E bill due (task, monthly); Community groups at 7 PM (event, weekly on Wednesday); Thrive at 6:30 PM (event, weekly on Friday); Men's bonfire (church) 7 PM (one-time event, with a note); a night out with friends at about 9 PM (one-time event, with a long note such as "pregame at my apartment"); "Follow up with Trevor on seeing his new place" (untimed task); "Make sure apartment is tip top shape for hosting" (untimed task). Also a few shopping items and a few general to-dos. Include one item on the 31st (monthly) to demonstrate month-end clamping, and one overdue unfinished task.

**PWA basics:** manifest, placeholder icons, service worker caching the app shell (so it opens offline), iOS meta tags. Real install testing happens later when it is hosted.

## Local server and phone preview
- `npm run dev` serves on localhost. Also make the dev server reachable on the local network (Vite `--host`) so John can open it from his iPhone in **Safari** on the same Wi-Fi to check the mobile layout. Tell John how to find the address, and that it may not work on a locked-down work network or VPN. **Home Screen install and offline testing need HTTPS and are not possible this way**, so those wait for hosting. Do not set up tunnels or any external service without asking John.
- In the laptop browser, also verify the phone layout using responsive/device mode.

## Testing and quality
- **Vitest unit tests** for: the recurrence engine (weekly, monthly, month-end clamping, skipped dates, completed occurrences, `until`), date helpers around timezone and daylight saving boundaries, 24-hour cleanup, and ordering logic for lists. Tests must pass before each report.
- Manual check list for John at the end (Dan produces this): add event; add task; repeating weekly and monthly; edit one occurrence versus all; delete one versus all; check off and undo; 24-hour cleanup (provide a dev-only way to simulate time passing, such as shortening the window in dev, or a "Run cleanup as if 24h later" button in the developer section); both list tabs with reorder; export then clear then import round trip; reload keeps data; dark mode; narrow and wide layouts.
- No console errors or warnings in normal use.

## Build order (milestones)
Commit at each milestone and add a changelog entry for each. After each milestone, report briefly to John so he can look at it before you continue (John will give feedback directly to you).

1. **M1: Foundation.** Scaffold, tab shell, theme, data-layer interface and IndexedDB implementation, auth stub, settings, developer section with sample data, `npm run dev` working, Vitest set up.
2. **M2: Items.** Types, recurrence engine with tests, Add/Edit form, edit/delete flows including this-versus-all.
3. **M3: Daily Schedule tab**, with check-off, undo, 24-hour cleanup, overdue section.
4. **M4: Calendar tab**, wide and narrow layouts.
5. **M5: Shopping List and To-Do tabs**, with drag-to-reorder.
6. **M6: Settings completion, Export/Import, PWA basics, polish, manual checklist.**

## Do NOT do in this handoff
- No Firebase, Google sign-in, allow-list, security rules, hosting, deploy.
- No notifications, push, Cloudflare Worker, or widget code (Phases 2 and 3).
- No shared-calendar features and no `calendarId` field (Phase 4; the data-layer abstraction is the only preparation).
- No analytics, tracking, or extra third-party services.
- No architecture or scope decisions on your own: flag them to John.

## Deliverables
- Working front end running locally with `npm run dev`, with all four tabs functioning on local data.
- Unit tests passing, plus the manual checklist for John.
- `README.md`: how to install, run, test, preview on a phone, and how the data layer is organized (especially **where the Firebase implementation will plug in later**).
- **`CHANGELOG.md`** created and updated for every milestone (date, title, handoff reference "002", bullets of what changed, anything left undone or deviating).
- Private GitHub repo if John wants it now (see above).

## Definition of done
All milestones M1 to M6 are working locally, tests pass, the manual checklist has been run, the README explains how to plug in a real backend, and John has reviewed it. Backend connection is a **later handoff**, planned by Craig 2 once John is ready to work from his personal laptop. See `handoffs/003-backend-outline.md` for the outline.

---

## ADDENDUM A (2026-11-04, Craig 2): answers to Dan 2's M2 to M4 questions

**1. Occurrence edits (data model).** Use Plan.md section 3.1 (updated today):
- Delete one occurrence: push its date onto `skippedDates`.
- Edit one occurrence: push its date onto `skippedDates` and create a **new non-repeating item** with the edited values, with optional `seriesId` (parent id) and `originalDate`. No override map.
- Add `seriesId?` and `originalDate?` to the item type. Edits to "all occurrences" do not touch detached items.
- Monthly repeats compute from the **original** day-of-month (clamp to month end each month; never drift).
- Completed repeating occurrences live in `completedOccurrences`; cleanup deletes entries older than 24 hours. You may also prune `skippedDates` entries older than today.
- **Overdue:** for repeating tasks, show only the **most recent** missed unfinished occurrence per series (older ones drop off). Non-repeating overdue tasks always show.
- Check-off of an occurrence is stored on the parent; do not detach on check-off.

**2. Add/Edit form (iPhone 15).** Use a **bottom sheet** (about 90% height, grows to full height if needed, rounded top, dimmed backdrop), not a separate full-screen route. Use the same sheet for Add and Edit. Layout top to bottom: Title (autofocus on Add), Event/Task segmented control, Date, Time (with an "All day / no time" toggle), End time (events only), Repeat (None/Weekly/Monthly), Notes. **Use native `<input type="date">` and `<input type="time">`** (good iOS pickers). Sticky **Save** bar at the bottom that stays above the keyboard (use `100dvh` and safe-area padding), Cancel at top left. Edit mode adds a **Delete** button at the bottom (with confirm, and the this-or-all prompt for repeating items). Tapping an item row opens it in Edit; the check circle is a separate tap target that only checks off.

**3. Calendar tab (phone layout, M4).**
- Header: week range ("Nov 2 to 8"), previous / next arrows, and a **Today** button.
- Below it: a Monday to Sunday strip with weekday letter and date number, **today ringed**, selected day filled. Under each day, up to two tiny dots (blue = event present, orange = task present).
- Below the strip: the **selected day's agenda**. Untimed items first (task checklist and untimed events), then timed items in order with the time in a left gutter. Tasks with a time (e.g. due 11:59 PM) show the time as a marker. Check circles work here too. Keep it a simple list, **not** a positioned hour grid (overlaps add complexity; John can ask for a grid later).
- Swipe left/right on the agenda or strip to change week. Tapping a strip day selects it. The "+" button adds on the **selected** day. Selecting a day should persist while moving between tabs in the session.
- This differs from Daily Schedule on purpose: Calendar is one day at a time with a week strip; Daily Schedule is a continuous scrolling list.

**4. Desktop.** The iPhone 15 (393x852) only decision is pending John's confirmation to Craig 2. Until Craig 2 updates CLAUDE.md and Plan.md, keep your centered phone-sized frame and do not build wide layouts.

**5. Backend later.** Outline is in `handoffs/003-backend-outline.md`. Nothing to build now; just keep the data-layer interface clean.
