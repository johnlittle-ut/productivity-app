import { useState } from 'react'
import type { BusyInterval, GroupEventInput, Member } from '../groups/model'
import { toMinutes } from '../lib/gridLayout'
import { Sheet } from './Dialogs'
import { SchedulingAssistant } from './SchedulingAssistant'

interface Props {
  mode: 'add' | 'edit'
  initial: GroupEventInput
  onSave: (input: GroupEventInput) => void
  onClose: () => void
  /** Group members and their busy time, for the scheduling assistant. */
  lanes?: Member[]
  busy?: BusyInterval[]
  meId?: string
  tz?: string
}

export function GroupEventForm({ mode, initial, onSave, onClose, lanes, busy = [], meId = '', tz = 'UTC' }: Props) {
  const [title, setTitle] = useState(initial.title)
  const [date, setDate] = useState(initial.date)
  const [startTime, setStartTime] = useState(initial.startTime)
  const [endTime, setEndTime] = useState(initial.endTime)
  const [notes, setNotes] = useState(initial.notes)
  const [error, setError] = useState('')

  function save() {
    if (!title.trim()) return setError('Add a title.')
    if (!date) return setError('Pick a date.')
    if (!startTime || !endTime) return setError('Pick a start and end time.')
    if (toMinutes(endTime) <= toMinutes(startTime)) return setError('End time must be after the start.')
    onSave({ title: title.trim(), date, startTime, endTime, notes: notes.trim() })
  }

  return (
    <Sheet
      title={mode === 'add' ? 'New group event' : 'Edit group event'}
      onCancel={onClose}
      footer={
        <>
          {error && <p className="error small form-error">{error}</p>}
          <button className="btn primary wide" onClick={save}>
            {mode === 'add' ? 'Send invites' : 'Save'}
          </button>
        </>
      }
    >
      <label className="field">
        <span>Title</span>
        <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} autoFocus={mode === 'add'} />
      </label>
      <label className="field">
        <span>Date</span>
        <input className="input" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </label>
      <div className="two-col">
        <label className="field">
          <span>Starts</span>
          <input className="input" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
        </label>
        <label className="field">
          <span>Ends</span>
          <input className="input" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
        </label>
      </div>
      {lanes && lanes.length > 0 && (
        <SchedulingAssistant
          lanes={lanes}
          busy={busy}
          date={date}
          startTime={startTime}
          endTime={endTime}
          meId={meId}
          tz={tz}
          onChange={(s, e) => {
            setStartTime(s)
            setEndTime(e)
          }}
        />
      )}
      <label className="field">
        <span>Notes</span>
        <textarea className="input" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </label>
    </Sheet>
  )
}
