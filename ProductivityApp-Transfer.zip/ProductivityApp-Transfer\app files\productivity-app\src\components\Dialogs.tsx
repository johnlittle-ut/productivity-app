import type { ReactNode } from 'react'

/** Bottom sheet (about 90% height) inside the phone frame, with a dimmed backdrop. */
export function Sheet({
  title,
  onCancel,
  children,
  footer,
}: {
  title: string
  onCancel: () => void
  children: ReactNode
  footer?: ReactNode
}) {
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label={title}>
      <div className="sheet">
        <div className="sheet-head">
          <button className="link-btn" onClick={onCancel}>
            Cancel
          </button>
          <h2>{title}</h2>
          <span className="sheet-head-spacer" />
        </div>
        <div className="sheet-body">{children}</div>
        {footer && <div className="sheet-foot">{footer}</div>}
      </div>
    </div>
  )
}

export interface Choice<T extends string> {
  label: string
  value: T
  danger?: boolean
}

/** Small centered dialog with a list of choices (and Cancel). */
export function ChoiceDialog<T extends string>({
  title,
  message,
  choices,
  onChoose,
  onCancel,
}: {
  title: string
  message?: string
  choices: Choice<T>[]
  onChoose: (value: T) => void
  onCancel: () => void
}) {
  return (
    <div className="overlay center" role="alertdialog" aria-modal="true" aria-label={title}>
      <div className="dialog">
        <h2>{title}</h2>
        {message && <p className="muted small">{message}</p>}
        <div className="dialog-choices">
          {choices.map((c) => (
            <button key={c.value} className={`btn ${c.danger ? 'danger' : ''}`} onClick={() => onChoose(c.value)}>
              {c.label}
            </button>
          ))}
          <button className="btn" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  )
}

export function Toast({ message, onUndo }: { message: string; onUndo?: () => void }) {
  return (
    <div className="toast" role="status">
      <span>{message}</span>
      {onUndo && (
        <button className="link-btn" onClick={onUndo}>
          Undo
        </button>
      )}
    </div>
  )
}
