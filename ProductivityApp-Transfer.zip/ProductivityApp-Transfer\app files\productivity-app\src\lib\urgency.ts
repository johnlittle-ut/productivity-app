// To-Do urgency. Urgent = flagged OR due within 7 days (overdue included).

import type { ListEntry } from '../types'
import { diffDays } from './recurrence'

export const URGENT_WITHIN_DAYS = 7

/** 0 = due soon / overdue (soonest first), 1 = flagged urgent only, 2 = everything else. */
export type UrgencyGroup = 0 | 1 | 2

const dueSoon = (e: ListEntry, today: string) => !!e.dueDate && diffDays(today, e.dueDate) <= URGENT_WITHIN_DAYS

export const isUrgent = (e: ListEntry, today: string): boolean => e.urgent === true || dueSoon(e, today)

export function urgencyGroup(e: ListEntry, today: string): UrgencyGroup {
  if (dueSoon(e, today)) return 0
  return e.urgent === true ? 1 : 2
}

/** Urgent items first (soonest due, then flagged); every group keeps the user's manual order. */
export function sortTodos(entries: ListEntry[], today: string): ListEntry[] {
  return [...entries].sort((a, b) => {
    const ga = urgencyGroup(a, today)
    const gb = urgencyGroup(b, today)
    if (ga !== gb) return ga - gb
    if (ga === 0 && a.dueDate !== b.dueDate) return a.dueDate!.localeCompare(b.dueDate!)
    return a.order - b.order
  })
}
