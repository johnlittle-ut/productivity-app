import { describe, expect, it } from 'vitest'
import { buildSampleData } from './sample'

describe('buildSampleData', () => {
  const data = buildSampleData('2026-11-04')

  it('has an item on the 31st (monthly) and an overdue task', () => {
    expect(data.items.some((i) => i.date.endsWith('-31') && i.repeat?.freq === 'monthly')).toBe(true)
    expect(data.items.some((i) => i.type === 'task' && !i.repeat && i.date < '2026-11-04')).toBe(true)
  })

  it('puts weekly items on the right weekdays', () => {
    const wed = data.items.find((i) => i.title === 'Community groups')!
    const fri = data.items.find((i) => i.title === 'Thrive')!
    expect(new Date(wed.date + 'T12:00:00Z').getUTCDay()).toBe(3)
    expect(new Date(fri.date + 'T12:00:00Z').getUTCDay()).toBe(5)
  })

  it('includes shopping items and to-dos', () => {
    expect(data.shopping.length).toBeGreaterThan(2)
    expect(data.todos.length).toBeGreaterThan(2)
  })
})
