// Turns stored items into dated occurrences for the screens.

import type { Item } from '../types'
import { addDays } from './dates'
import { occurrenceDates } from './recurrence'
import { convertWall } from './tz'

export interface Occurrence {
  key: string
  item: Item
  /** Date in the VIEWING zone (what the screens bucket by). */
  date: string
  /** The occurrence's date in the item's own zone: the key for completedOccurrences / skippedDates. */
  srcDate: string
  /** Start/end as shown in the viewing zone (null = untimed). */
  startTime: string | null
  endTime: string | null
  done: boolean
}

/** How far back to look for a missed occurrence of a repeating task (covers monthly repeats). */
export const OVERDUE_LOOKBACK_DAYS = 400

function isDone(item: Item, date: string): boolean {
  return item.repeat ? date in item.completedOccurrences : item.done
}

function shifts(item: Item, viewTz?: string): viewTz is string {
  return !!viewTz && !!item.startTime && !!item.tz && item.tz !== viewTz
}

function toOccurrence(item: Item, srcDate: string, viewTz?: string): Occurrence {
  let date = srcDate
  let startTime = item.startTime
  let endTime = item.endTime
  if (shifts(item, viewTz)) {
    const s = convertWall(srcDate, item.startTime!, item.tz!, viewTz)
    date = s.date
    startTime = s.time
    if (item.endTime) endTime = convertWall(srcDate, item.endTime, item.tz!, viewTz).time
  }
  return { key: `${item.id}:${srcDate}`, item, date, srcDate, startTime, endTime, done: isDone(item, srcDate) }
}

/** Dates (in the item's zone) that could land in [from, to] in the viewing zone. */
function srcRange(item: Item, from: string, to: string, viewTz?: string): [string, string] {
  return shifts(item, viewTz) ? [addDays(from, -1), addDays(to, 1)] : [from, to]
}

/** Timed items first in time order, then untimed in creation order. */
export function compareWithinDay(a: Occurrence, b: Occurrence): number {
  const ta = a.startTime
  const tb = b.startTime
  if (ta && tb) return ta.localeCompare(tb) || a.item.title.localeCompare(b.item.title)
  if (ta) return -1
  if (tb) return 1
  return a.item.createdAt - b.item.createdAt
}

/** Not-done occurrences in [from, to], grouped by date, sorted within each date. */
export function occurrencesByDate(items: Item[], from: string, to: string, viewTz?: string): Map<string, Occurrence[]> {
  const map = new Map<string, Occurrence[]>()
  for (const item of items) {
    const [f, t] = srcRange(item, from, to, viewTz)
    for (const srcDate of occurrenceDates(item, f, t)) {
      const occ = toOccurrence(item, srcDate, viewTz)
      if (occ.done || occ.date < from || occ.date > to) continue
      const list = map.get(occ.date)
      if (list) list.push(occ)
      else map.set(occ.date, [occ])
    }
  }
  for (const list of map.values()) list.sort(compareWithinDay)
  return map
}

/**
 * Unfinished tasks from past dates, oldest first. Past events are not shown.
 * A repeating task contributes only its most recent missed, unfinished occurrence.
 */
export function overdueOccurrences(items: Item[], today: string, viewTz?: string): Occurrence[] {
  const yesterday = addDays(today, -1)
  const lookbackStart = addDays(today, -OVERDUE_LOOKBACK_DAYS)
  const out: Occurrence[] = []
  for (const item of items) {
    if (item.type !== 'task') continue
    if (!item.repeat) {
      const occ = toOccurrence(item, item.date, viewTz)
      if (occ.date <= yesterday && !occ.done) out.push(occ)
      continue
    }
    // Only the latest past occurrence counts; if it was completed or skipped, nothing is overdue
    // (older misses silently drop off, so a missed bill never piles up or reappears).
    const [f, t] = srcRange(item, lookbackStart, yesterday, viewTz)
    const schedule = occurrenceDates({ ...item, skippedDates: [] }, f, t)
      .map((d) => toOccurrence(item, d, viewTz))
      .filter((o) => o.date <= yesterday)
    const latest = schedule[schedule.length - 1]
    if (latest && !item.skippedDates.includes(latest.srcDate) && !latest.done) out.push(latest)
  }
  return out.sort((a, b) => a.date.localeCompare(b.date) || compareWithinDay(a, b))
}

/** What the Calendar grid shows: events, plus tasks the user flagged "Show on calendar". */
export function showsOnCalendar(item: Item): boolean {
  return item.type === 'event' || item.showOnCalendar === true
}

/** Like occurrencesByDate, restricted to what the Calendar shows. */
export function calendarOccurrencesByDate(items: Item[], from: string, to: string, viewTz?: string): Map<string, Occurrence[]> {
  return occurrencesByDate(items.filter(showsOnCalendar), from, to, viewTz)
}

/** What "Move to tomorrow" changes for a task occurrence. Repeating: this occurrence only (skip it + a one-off copy). */
export function planMoveToTomorrow(
  item: Item,
  occDate: string,
  tomorrow: string,
  /** The occurrence as displayed in the viewing zone; the moved item is re-anchored to that zone. */
  view?: { startTime: string | null; endTime: string | null; tz: string },
) {
  const { id: _id, createdAt: _c, updatedAt: _u, ...rest } = item
  const anchor: Partial<Item> = view && view.startTime ? { startTime: view.startTime, endTime: view.endTime, tz: view.tz } : {}
  if (!item.repeat)
    return {
      patch: { date: tomorrow, ...anchor } as Partial<Item>,
      undoPatch: { date: item.date, startTime: item.startTime, endTime: item.endTime, tz: item.tz } as Partial<Item>,
      copy: null,
    }
  return {
    patch: { skippedDates: [...item.skippedDates, occDate] } as Partial<Item>,
    undoPatch: { skippedDates: item.skippedDates } as Partial<Item>,
    copy: { ...rest, ...anchor, date: tomorrow, repeat: null, completedOccurrences: {}, skippedDates: [], done: false, doneAt: null, seriesId: item.id, originalDate: occDate },
  }
}

/** Search upcoming (next year) and overdue occurrences by title or notes; one hit per item, overdue first. */
export function searchOccurrences(items: Item[], today: string, query: string, viewTz?: string, limit = 60): Occurrence[] {
  const q = query.trim().toLowerCase()
  if (!q) return []
  const hit = (o: Occurrence) => o.item.title.toLowerCase().includes(q) || o.item.notes.toLowerCase().includes(q)
  const seen = new Set<string>()
  const out: Occurrence[] = []
  const upcoming = [...occurrencesByDate(items, today, addDays(today, 365), viewTz).entries()].sort(([x], [y]) => x.localeCompare(y)).flatMap(([, v]) => v)
  for (const o of [...overdueOccurrences(items, today, viewTz), ...upcoming]) {
    if (o.done || seen.has(o.item.id) || !hit(o)) continue
    seen.add(o.item.id)
    out.push(o)
    if (out.length >= limit) break
  }
  return out
}
