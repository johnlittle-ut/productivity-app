export type Theme = 'system' | 'light' | 'dark'

const KEY = 'productivity-app:theme'

/** Set the theme on <html> (system = follow the device) and remember it for the next launch. */
export function applyTheme(theme: Theme): void {
  const root = document.documentElement
  if (theme === 'system') root.removeAttribute('data-theme')
  else root.setAttribute('data-theme', theme)
  try {
    localStorage.setItem(KEY, theme)
  } catch {
    /* storage unavailable: fine, the setting still applies this session */
  }
}

/** Apply the remembered theme before the first render, so there is no flash of the wrong theme. */
export function applySavedTheme(): void {
  try {
    const saved = localStorage.getItem(KEY)
    if (saved === 'light' || saved === 'dark') document.documentElement.setAttribute('data-theme', saved)
  } catch {
    /* ignore */
  }
}
