# Handoff 004: Interactive tab (groups, availability, group events), front end with mock data

From: Craig 2. To: Dan 2. Date: 2026-11-04. Decisions confirmed by John to Craig 2 today.
Backend is **not** part of this handoff. Build the UI and logic against **local mock data**; real invite links, Firestore and notifications come in the backend phase.

## Concept
A fifth tab, **Interactive**, for sharing **availability** (not calendars) with friends, roommates, family, partner. Expected scale: under about 30 users total, mostly close friends.
- A user can be in **several groups**, each with its own members.
- A group's calendar shows **when members are busy**, never **what** they are doing. No titles, notes or any details of personal events, only blocked-off time. It reflects each member's real personal calendar.
- Anyone in the group can **add a group event**, which sends an **invite** to the other members. Each member can accept (it is copied onto their personal calendar in a group color) or decline.

## Screens

**1. Interactive tab (group list).** Lists the user's groups (name, member initials). "New group" and "Join with link" actions. Also an **Invitations** section at the top listing pending group-event invites (see 4), with Accept and Decline.

**2. Group screen.** Header with group name and a settings gear. Below, an **availability view** for a selected day:
- Same week strip and Day navigation pattern as the Calendar tab.
- Below it, an hour grid like the Calendar tab's Day view, but showing **one lane per member** (initials and color at the top of each lane) with **busy blocks only** (no text inside them). Add a highlighted **"everyone free"** band for time ranges where nobody is busy (within about 7 AM to 11 PM).
- **Group events** appear as normal labeled blocks in the **group color** across the grid.
- Button **"Add group event"** (title, date, start, end, notes). Creating one sends invites to all other members.
- Tap a group event to see title, time, creator and each member's response (Accepted, Declined, Pending).

**3. Group settings.** Group name (editable), **members list**, **Invite someone** (generates the one-time link, see below), **Leave group** (confirm), and a **Notifications** section as a **placeholder** (disabled, "coming soon"; real notifications are Phase 2). Group color picker (used for that group's events). No admin roles: any member can invite, rename, or leave. No removing other members.

**4. Invitations.** A pending group-event invite shows group, title, time, who sent it, and whether it conflicts with the user's own events (show a small "You're busy then" note, without naming the conflicting event). **Accept** copies it to the user's personal calendar as an **event** in the group's color (store `groupId` and `groupEventId` on the personal item; it must still show up in Calendar and Schedule). **Decline** records the response only. Cancelling or editing the group event by its creator updates accepted copies (mock this in the local layer).

## Invite links (mock now, real later)
- "Invite someone" generates a **one-time link that expires in 20 minutes**, shows a copy and share button and a **countdown**. A used or expired link shows a clear message.
- **Mock now:** generate a fake token and URL; "Join with link" accepts a pasted fake link and adds a mock member. Include a dev-only button to simulate a second user joining or leaving.
- **Real later (backend phase):** token documents in Firestore redeemed by Firestore rules (one-time, expiry); the invitee must **already be on the app's allow-list**, since the app stays invite-only.

## Busy computation (important, unit test it)
A function that turns a user's personal items into **busy intervals** for the next 60 days:
- **Events with a time:** busy from start to end; **no end time = 1 hour** (same as the Calendar grid). Expand repeating events with the existing recurrence engine, respecting `skippedDates`.
- **Untimed (all-day) events:** **not busy** (default; John may change).
- **Tasks:** **not busy** by default, **unless** the task has `showOnCalendar` on and a time (30 minutes, matching the Calendar grid).
- Optional later: a per-event "private / don't count as busy" toggle. Do not build it now.
- Output contains **only start and end** (plus the user id), never titles or notes. That output is what a real backend would publish to a group.

## Data and architecture
- Keep the **data-layer pattern**: add a separate **GroupLayer** interface (groups, members, group events, invites, responses, busy intervals per member) with a **local mock implementation** (IndexedDB or in-memory plus seeded fake members with realistic busy patterns). Same subscription style as the existing layer.
- Personal items get optional `groupId` and `groupEventId` (accepted group events only). Keep export/import compatible; optional fields only.
- Settings stay per user. Mock members need a display name and a color.
- Real structure later (informational, do not build): `groups/{groupId}` with member list; `groups/{groupId}/busy/{uid}` holding only intervals; `groups/{groupId}/events/{id}` with responses. Members can read the group's busy docs; each user writes only their own.

## Constraints
- Phone layout only (iPhone 15, 393x852). Light and dark mode. Concise UI text.
- Add the tab to the tab bar (five tabs now; if it gets crowded, tell me and propose a fix rather than shrinking tap targets below 44 pt).
- No notifications or push yet. No real network. No new libraries without asking.
- Do **not** edit `FUTURECHANGES.md`.

## Deliverables
- Working Interactive tab on mock data, per the screens above.
- **Minimal tests only** (see CLAUDE.md "Token economy"): a few focused tests for busy-interval computation (repeats, skipped dates, default 1 h, untimed ignored, flagged tasks) and invite expiry. No UI tests. Test each new behavior once; no redundant tests (cap relaxed by John, see CLAUDE.md).
- Dev section in Settings: seed mock groups, simulate a member joining or leaving, simulate an incoming invite.
- CHANGELOG entry, short report to Craig 2 (built, tests, deviations, questions), and additions to MANUAL-CHECKLIST.md.
