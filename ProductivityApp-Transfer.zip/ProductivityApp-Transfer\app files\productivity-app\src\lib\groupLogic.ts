// Pure rules for group events, invitations and invite links.

import type { Group, GroupEvent, Invitation, InviteLink } from '../groups/model'
import type { Item, NewItem } from '../types'
import { overlaps } from './busy'
import { zonedToInstant } from './tz'

/** Pending group-event invitations for `meId`: not mine, not cancelled, not past, not yet answered. */
export function pendingInvitesFor(events: GroupEvent[], groups: Group[], meId: string, today: string): Invitation[] {
  const out: Invitation[] = []
  for (const event of events) {
    const group = groups.find((g) => g.id === event.groupId)
    if (!group || !group.memberIds.includes(meId)) continue
    if (event.creatorId === meId || event.cancelled || event.date < today) continue
    if (event.responses[meId] !== 'pending') continue
    out.push({ event, group })
  }
  return out.sort((a, b) => a.event.date.localeCompare(b.event.date) || a.event.startTime.localeCompare(b.event.startTime))
}

/** Does the event overlap the user's own busy time? (Used for "You're busy then" without naming anything.) */
export function conflictsWithBusy(event: GroupEvent, mine: { start: number; end: number }[], tz: string): boolean {
  const range = { start: zonedToInstant(event.date, event.startTime, tz), end: zonedToInstant(event.date, event.endTime, tz) }
  return mine.some((b) => overlaps(range, b))
}

/** The personal calendar copy made when someone accepts (or creates) a group event. */
export function acceptedCopy(event: GroupEvent): NewItem {
  return {
    title: event.title,
    type: 'event',
    date: event.date,
    startTime: event.startTime,
    endTime: event.endTime,
    notes: event.notes,
    groupId: event.groupId,
    groupEventId: event.id,
  }
}

export interface GroupSyncPlan {
  removeIds: string[]
  updates: { id: string; patch: Partial<Item> }[]
}

/**
 * Keeps accepted copies in step with their group event:
 * cancelled -> remove the copy; edited -> update it; group event gone entirely (e.g. user left) -> keep as a plain event.
 */
export function planGroupSync(items: Item[], events: GroupEvent[]): GroupSyncPlan {
  const plan: GroupSyncPlan = { removeIds: [], updates: [] }
  for (const item of items) {
    if (!item.groupEventId) continue
    const ev = events.find((e) => e.id === item.groupEventId)
    if (!ev) {
      plan.updates.push({ id: item.id, patch: { groupId: undefined, groupEventId: undefined } })
    } else if (ev.cancelled) {
      plan.removeIds.push(item.id)
    } else if (
      item.title !== ev.title ||
      item.date !== ev.date ||
      item.startTime !== ev.startTime ||
      item.endTime !== ev.endTime ||
      item.notes !== ev.notes
    ) {
      plan.updates.push({
        id: item.id,
        patch: { title: ev.title, date: ev.date, startTime: ev.startTime, endTime: ev.endTime, notes: ev.notes },
      })
    }
  }
  return plan
}

// ---------- One-time invite links (20 minutes) ----------

export type LinkStatus = 'valid' | 'expired' | 'used'

export function linkStatus(link: InviteLink, now: number): LinkStatus {
  if (link.usedAt !== null) return 'used'
  return now >= link.expiresAt ? 'expired' : 'valid'
}

export const remainingMs = (link: InviteLink, now: number): number => Math.max(0, link.expiresAt - now)

/** 1_179_000 ms -> '19:39' */
export function formatCountdown(ms: number): string {
  const total = Math.ceil(Math.max(0, ms) / 1000)
  const m = Math.floor(total / 60)
  const s = total % 60
  return `${m}:${String(s).padStart(2, '0')}`
}

/** Accepts a pasted link or a bare token; returns the token or null. */
export function parseToken(text: string): string | null {
  const t = text.trim()
  if (!t) return null
  const m = t.match(/\/join\/([A-Za-z0-9_-]+)\s*$/)
  if (m) return m[1]
  return /^[A-Za-z0-9_-]{4,64}$/.test(t) ? t : null
}
