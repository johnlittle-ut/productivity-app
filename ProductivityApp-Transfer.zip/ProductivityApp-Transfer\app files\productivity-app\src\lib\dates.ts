// Date helpers. Day logic uses plain 'YYYY-MM-DD' strings and the user's timezone, never UTC dates.

export function browserTimezone(): string {
  return Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/New_York'
}

/** Today's date in the given IANA timezone as 'YYYY-MM-DD'. */
export function todayIn(timezone: string, now: Date = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(now)
}

export function parseDate(s: string): { y: number; m: number; d: number } {
  const [y, m, d] = s.split('-').map(Number)
  return { y, m, d }
}

export function toDateString(y: number, m: number, d: number): string {
  return `${String(y).padStart(4, '0')}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`
}

export function daysInMonth(y: number, m: number): number {
  return new Date(Date.UTC(y, m, 0)).getUTCDate()
}

export function addDays(s: string, n: number): string {
  const { y, m, d } = parseDate(s)
  const dt = new Date(Date.UTC(y, m - 1, d + n))
  return toDateString(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate())
}

/** 0 = Sunday ... 6 = Saturday. */
export function dayOfWeek(s: string): number {
  const { y, m, d } = parseDate(s)
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay()
}

/** Date in the given month of `s` on day `day`, clamped to the last day of that month. */
export function clampedDay(y: number, m: number, day: number): string {
  return toDateString(y, m, Math.min(day, daysInMonth(y, m)))
}

/** Monday of the week containing `s` (weeks run Monday to Sunday). */
export function weekStart(s: string): string {
  return addDays(s, -((dayOfWeek(s) + 6) % 7))
}

/** Minutes since midnight right now in the given timezone (0 to 1439). */
export function minutesNowIn(timezone: string, now: Date = new Date()): number {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: timezone,
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(now)
  const h = Number(parts.find((p) => p.type === 'hour')?.value ?? 0)
  const m = Number(parts.find((p) => p.type === 'minute')?.value ?? 0)
  return h * 60 + m
}
