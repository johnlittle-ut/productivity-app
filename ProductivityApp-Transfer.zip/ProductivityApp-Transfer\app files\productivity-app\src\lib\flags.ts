/** Interactive (groups) tab: on in dev, off in production builds unless VITE_ENABLE_INTERACTIVE=true. */
export const INTERACTIVE_ENABLED: boolean = import.meta.env.VITE_ENABLE_INTERACTIVE
  ? import.meta.env.VITE_ENABLE_INTERACTIVE === 'true'
  : import.meta.env.DEV
