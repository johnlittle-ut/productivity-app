# CLAUDE.md — Productivity App

This file is read by **both** Claude chats working on this project. Read it fully before doing anything.

## Roles

### John (the user)
- **Functional manager** (updated 2026-11-04): owns the product, sets priorities, makes the final call on scope, cost, and design direction, and tests the app on his iPhone and Windows laptop.
- Directs the agents below. Gives small tweaks straight to Dan 2, design direction to Ava, and planning or scope changes to Craig 2.
- Develops from a **Windows laptop**. There is **no Mac**. Only Apple device is an iPhone.

### Craig 2 (technical project manager, updated 2026-11-04)
- **Acts as technical project manager for Dan 2. Craig 2 NEVER writes application code.**
- Owns the plan: keeps `Plan.md`, this file, and the handoff docs current; tracks milestones and status against the plan; keeps the open-questions and risk lists.
- Makes day-to-day planning and architecture calls **within the agreed plan** (e.g. data-model details, UX specifics) and answers Dan 2's questions **directly by chat-to-chat message**, without routing every question through John.
- Escalates to John anything that changes scope, cost, devices, access/security, or a decision John already made. **Craig 2 only updates this file for decisions John has confirmed to Craig 2 himself**, not on a peer's relay alone.
- Reviews Dan 2's `CHANGELOG.md` and milestone reports against the plan, flags deviations, and approves or redirects.
- Allowed outputs: `.md` files, planning documents, status summaries, and handoff instructions for Dan 2. Handoffs may be sent directly to Dan 2 by message or saved as files in `handoffs/` (use a file when large). John does not need to copy-paste them anymore.
- Keeps replies to John short (see Communication style).

### Dan 2 (coding chat)
- **Implements everything.** Writes, edits, and tests all code.
- Works from handoffs Craig 2 produces (by message or in `handoffs/`). If a handoff is ambiguous or conflicts with this file, Dan 2 asks **Craig 2 directly** (or John) instead of guessing. John will occasionally request changes directly from Dan 2, which is fine and usually for small things; Dan 2 should log them in the changelog and tell Craig 2 if they affect the plan.
- **After every set of changes, Dan 2 must update `CHANGELOG.md`** (see below) before reporting back as done.
- Does not make architecture or scope decisions on his own. Flag them to Craig 2 (who escalates to John when needed).
- Reports to Craig 2 at each milestone (what was built, tests, deviations, questions).

### Ava (design specialist, added 2026-11-04)
- Owns **visual design and UX**: look and feel, layout, spacing, typography, color and dark mode, icons, motion, empty and error states, and iPhone-native feel.
- Produces **design specs and mockups** (in `design/`), not production code. Dan 2 implements. (Assumption: Ava does not edit `src/` unless John says otherwise.)
- Brief and first assignments: `design/AVA-brief.md`.
- Sends specs to Dan 2 via Craig 2, who checks them against the plan. John gives Ava design direction directly and has the final say.
- Anything that changes scope, features, or data goes to Craig 2 first.

## Workflow

1. John and Craig 2 plan a feature or change; Craig 2 records it in `Plan.md` and writes the handoff.
2. Craig 2 sends the handoff to Dan 2 directly (message or `handoffs/` file). John may still paste handoffs manually if cross-chat messaging is unavailable.
3. Dan 2 builds in milestones, commits, and updates `CHANGELOG.md`.
4. Dan 2 reports each milestone to Craig 2, who reviews it against the plan and keeps John briefed.
5. John tests and gives feedback directly to Dan 2 (small tweaks) or to Craig 2 (planning changes, new ideas, scope).

## Changelog rules (for Dan 2)

- File: `CHANGELOG.md` in the project root. Create it on the first build.
- Newest entry on top. Each entry has: date, short title, handoff reference, and bullet list of what changed (files touched, behavior added or changed, anything left undone or any deviation from the handoff).
- Never skip an entry, even for small changes.

## Project summary

A personal calendar / to-do app for John's iPhone (also usable on a Windows laptop). It may later be shared, invite-only, with a girlfriend and/or roommates, each with their own private data. John treats his calendar like a to-do list. His current system is one long OneNote page listing every date of the year (Mondays in bold) with homework due dates, regular events, and special events. The app replaces this.

**Core pain point:** regular calendar apps send excessive notifications (e.g. 15 for one event), which also clutter his CarPlay display. Notifications in this app must be minimal, opt-in per item, and one clean notification per item.

### Planned tabs
Tab order (confirmed by John 2026-11-04):
1. **Calendar** — Outlook-style time grid (Day and Week) of events; tasks only if flagged.
2. **Schedule** — OneNote-style list of every date with events and tasks.
3. **To-Do** — undated tasks, with urgency marks.
4. **Shopping** — Groceries and General sub-tabs.
5. **Interactive** — groups, shared availability, group events.

## Decisions made so far

| Topic | Decision |
|---|---|
| Platform | **PWA** (web app installed to iPhone Home Screen). No App Store, no Apple Developer account. |
| Hosting | **Firebase Hosting (free)** preferred, so Google sign-in works reliably in the iPhone Home Screen app. Code in a private GitHub repo (John has an account). GitHub Pages is the fallback. |
| Cost | **$0 recurring.** A very small one-time cost is acceptable in the worst case. No ongoing hosting fees. |
| Devices | **Phone-only layout, confirmed by John 2026-11-04.** Designed around **iPhone 15 (393x852)** but must be **flexible across other phone sizes, iPhone and Android** (no foldables). **Desktop just shows the same phone-sized column, like a phone emulator** (black backdrop); no wide or desktop layouts. Same PWA codebase everywhere. |
| Auth and access | **Google sign-in, invite-only, multiple users (decided 2026-11-03, replaces "locked to John only").** Option A: an **allow-list in Firestore**, documents `allowedEmails/{lowercased email}`, managed by John in the Firebase console (no rules redeploy needed to add someone). Rules let a user touch only their own `users/{uid}/...` and only while on the allow-list. Not-invited users see a friendly "invite-only" screen, never a raw error. **Never hard-code a UID or email.** Details in `Plan.md` section 3.0. |
| Per-user everything | Each person has their own private calendar, lists and **settings (timezone, digest time, etc.)**. Phase 2 push subscriptions and Phase 3 widget tokens are also **per-user**; one Cloudflare Worker serves all users. |
| Interactive tab (groups) | **Designed 2026-11-04, confirmed by John.** Fifth tab for sharing **availability** (busy blocks only, no event details) across multiple groups, plus group events with invites and accept/decline, and one-time 20-minute invite links. Expected scale under about 30 users. **Front end now on mock data (handoff 004); real backend last** (needs multiple Google accounts to test). See `Plan.md` Phase 4 and `handoffs/004-interactive-tab.md`. |
| Data safety | Local-first storage (IndexedDB) + cloud sync + manual JSON export/import backup. Must not lose the calendar if something glitches. |
| Sync backend | **Firebase** (Firestore + Google sign-in), free Spark tier. John has **never used Firebase**, so Dan 2 must give clear, step-by-step, Windows-friendly setup instructions (create project, enable Google sign-in, set Firestore security rules locking data to John's account, etc.) and not assume prior knowledge. Firestore storage is separate from John's Google One storage plan, so it does not use his photo/email space. |
| Item model | One unified "item" with a **type of Event or Task** (deadlines like "rent due" or "Module 2 due at 11:59" are Tasks with a date/time). Fields: title, type, date, optional time, optional notes, done flag, optional repeat, optional notification. Events and tasks use **different colors**. No other categories/tags. |
| Views | Calendar tab and Daily Schedule tab show the **same underlying data** differently. **Calendar tab = week view.** **Daily Schedule tab = styled like John's OneNote page** (date headers, items listed beneath, weeks start on Monday and are visually marked, timed items in order, untimed tasks as a checklist). |
| Shopping List | One tab with **Groceries** and **General** as top sub-tabs, each showing one list (confirmed by John 2026-11-04). No separation by store. |
| Repeats | **Weekly and monthly only.** |
| Completion | Check-off hides the item, and **completed items are auto-cleared 24 hours after being checked off.** Dates are generated, never stored, so there are no past dates to delete. Manual delete is still available. |
| Data sensitivity | Not sensitive (no passwords, financial, etc.). |
| Notifications | Regular iPhone notifications (NOT calendar-style spam). **One notification per item.** Adjustable per item; **default for Events is 1 hour before.** Never ask for permission unprompted. |
| Daily digest | **One notification at 9:00 AM daily** summarizing that day's calendar and to-do items. (Delivery mechanism TBD, see open questions.) |
| Widget | John wanted an interactive widget, but that is **not possible with a PWA**. **Decision: read-only widget via the free Scriptable app, built in Phase 3.** |
| Build order (changed 2026-11-04) | **Front end first, backend later.** John must do the Firebase and Google sign-in work from his **personal laptop** (tied to his personal Google account). Dan 2 now builds the **whole front end on a local dev server** with **local IndexedDB storage** behind a single data-layer interface and an auth stub (handoff 002). **No Firebase, sign-in, hosting, or deploy until a later backend handoff.** John reviews the front end and requests changes directly with Dan 2. Handoff 001 steps 3, 4, 5, 7 are deferred, not cancelled. |
| Versioning | **Most recently edited version wins** whenever copies disagree (phone, laptop, cloud, imports), judged by per-record `updatedAt` (edit time). Partial-field updates, stale writes rejected by rules, timestamped deletes, newest-wins Import. Required by John 2026-11-04. Full rules in `Plan.md` 3.6; built in `handoffs/003-backend-connect.md` step 4b. |
| Master plan | **`Plan.md`** is the detailed plan and source of truth for scope, data model, screens, and phases. Read it before starting any work. If a handoff conflicts with it, ask John. |

## Open questions (not yet decided)

- **Notification delivery:** iOS PWAs support Web Push (iOS 16.4+, only when installed to Home Screen). Scheduled pushes need a server-side sender. Must find a **$0** way to do this (e.g. Cloudflare Workers cron triggers, or Firebase options). Firebase Cloud Functions requires a billing-enabled plan, so check that it stays within free limits and acceptable to John before choosing.
- **Home screen widget:** a PWA cannot have one. Options being discussed: (a) read-only widget via the free Scriptable app, (b) skip the widget, (c) native app later (needs Apple Developer account, $99/yr, which breaks the $0 rule). Interactive check-off from a widget is not achievable for free.
- **9:00 AM digest and 1-hour-before reminders:** both need a server-side sender (or an iOS Shortcuts automation as a fallback for the digest). Timezone: John appears to be in Eastern time; scheduling must handle daylight saving.
- **Build phases:** Phase 1 = four tabs, Google sign-in with invite-only allow-list, Firebase sync, backup export. Phase 2 = notifications and digest (per-user). Phase 3 = read-only widget (per-user token) and polish. **Phase 4 = shared calendar (rough idea, not designed).**
- **Possible Workspace issue:** a company or school Google account may be blocked by its admin from signing in to outside apps. Use personal Google accounts, and test when the first extra person is invited.

## Communication style (ALL agents: Craig 2, Dan 2, Ava, and any future agent)

- Keep all chat responses **concise, at the level of detail appropriate for the task.** Small task, short reply.
- Applies to messages to John **and** agent-to-agent messages: lead with the answer or decision, then only what is needed. No recaps of things already said, no restating the whole plan, no filler.
- Milestone reports: what was built, tests, deviations, open questions. A few lines each.
- John is fairly technically fluent. Technical shorthand and standard terms are fine (usually). Explain only when something is new to him (e.g. Firebase console steps) or when he asks.
- Added by John, 2026-11-04.

## Accidental attachments (added by John, 2026-11-04)

- John's editor often auto-attaches the open file to his messages ("user opened file X in the IDE"). This is usually **accidental**.
- **Do not read, open, or act on an auto-attached file** unless John's message actually refers to it. Judge by the message text.

## Design tokens (approved by John, 2026-11-04)

- Colors come from **`design/color-tokens.md`** (light option E, **dark option R, Espresso + Deep Copper**, final per John 2026-11-04). Use the CSS variables, **never hard-coded colors**, in existing and all future screens.
- Accent (`--accent`, `--on-accent`) is separate from event (`--event`) and task (`--task`) colors. `--danger` only for Overdue.

## Token economy (added by John, 2026-11-04)

- Tokens cost John money. **Do the minimum that gets the task done well.**
- **Tests (clarified by John, 2026-11-04):** testing **new changes** is fine and expected. The waste to avoid is **re-testing the same feature the same way many times** (duplicate tests, repeated full-suite runs, re-verifying unchanged features). Test each new behavior once, focused on logic that is easy to get wrong (recurrence, busy intervals, date and timezone math, cleanup rules, import/export). Skip tests for trivial UI and simple CRUD. Run the full suite once before reporting.
- There is **no hard cap** on test count; the goal is no redundancy. Craig 2 handoffs should say "test the new behavior once" rather than ask for broad coverage.
- Do not re-read large files, re-explain plans, or produce long reports. Short messages only.
- **Editing documents and code:** make **targeted edits only** (replace or insert the specific lines that change). **Never rewrite or regenerate a whole file** to change part of it. New `CHANGELOG.md` entries are inserted as a new block at the top with an edit, not by rewriting the file. Find the spot with a search (grep or line offsets) instead of reading the entire file, and don't re-read a file you just edited. Whole-file writes are only for creating new files.
- Craig 2 must not request broad test coverage in handoffs.

## Constraints for Dan 2

- Develop and test on **Windows**. Do not require a Mac or Xcode.
- Prefer simple, maintainable tech. Avoid anything that needs paid services.
- The app must work offline and sync when back online.
- Keep the UI mobile-first (iPhone), but usable on a laptop browser. The laptop is the same PWA in a browser; do not build or maintain a separate desktop app. Do not spend extra time polishing laptop layouts beyond making them work and look reasonable.
- Do not add notifications, tracking, or analytics that John has not asked for.
- Build everything **per-user** from the start: data under `users/{uid}`, settings per user, no global user-specific constants (no hard-coded UID, email, or timezone).
