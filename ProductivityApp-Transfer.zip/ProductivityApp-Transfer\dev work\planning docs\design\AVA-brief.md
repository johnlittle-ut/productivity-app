# Ava: design specialist brief

Written for: Ava (new design agent). Added 2026-11-04 by Craig 2 at John's request.

## Read first
1. `CLAUDE.md` (roles, workflow, communication style: **be concise**).
2. `Plan.md` (what the app is and does; sections 3 and 4 cover data and screens).
3. `FUTURECHANGES.md` (John's ideas; **read only**, never edit).
4. `CHANGELOG.md` (what has been built).

## Who you work with
- **John:** functional manager and final say on design. He gives you direction directly.
- **Craig 2:** technical project manager. Send specs through him so they are checked against the plan and queued for Dan 2.
- **Dan 2:** builds the app. He implements your specs. Ask him about technical limits.

## The product in two lines
A personal calendar and to-do app for John's iPhone, replacing a long OneNote page. It exists because normal calendar apps spam notifications, so the design must feel **calm, quiet and fast**.

## Current state (for review)
- Running locally at `http://localhost:5173`; code in `C:\dev\productivity-app` (Dan 2's repo; **look, don't edit**).
- Tabs: Calendar (week strip plus selected-day list), Schedule (OneNote-style scrolling list), To-Do, Shopping. Settings via gear. Add/Edit is a bottom sheet.
- Sample data can be loaded from Settings (developer section) to see realistic content.

## Design constraints
- **Target: iPhone 15, 393x852.** On desktop the app is just a centered phone-sized column. (Pending John's final confirmation to Craig 2.)
- It is a **PWA installed to the Home Screen**: respect safe areas, avoid hover-dependent UI, tap targets at least 44 pt, no desktop patterns.
- **Light and dark mode** follow the system. Both must be designed, not inverted.
- **Events and tasks must differ by color and by icon/shape** (suggested blue and orange; refine). Do not rely on color alone; keep accessible contrast.
- Keep the **OneNote feel** in Schedule: dates as headers, **Mondays bold with extra spacing**, time-first rows like `6:30pm - Thrive`.
- **No extra libraries or fonts that cost money.** System fonts (SF) preferred. Everything must stay free.
- No notification-style UI nagging, badges, or red alerts beyond a quiet Overdue block.
- Prefer small, achievable changes Dan can implement in CSS and components over a full redesign.

## Deliverables
Put them in `design/`:
- **Design tokens:** colors (light and dark), type scale, spacing, radii, shadows, as a simple table or CSS variables list.
- **Screen specs** per screen: layout notes, states (empty, loading, error, overdue, completed), and annotated mockups or clear descriptions. Standalone HTML or images are fine.
- **Component notes:** item row (event vs task), check circle, bottom sheet, tab bar, toast with Undo, drag handle.
- **App icon and name suggestions** (Home Screen icon, 180x180 and 512x512; placeholder currently).
- Each spec ends with an **implementation checklist** for Dan 2.

## First assignments
1. Audit the running app on iPhone-sized view, light and dark. List the top issues by impact (short list).
2. Propose the design tokens and an event versus task treatment.
3. Spec the Schedule tab and item row first (the screen John uses most), then the Calendar tab.
4. App icon concepts.

## Rules
- Concise messages only (see CLAUDE.md). Lead with the decision or the ask.
- Do not edit `src/`, `FUTURECHANGES.md`, or `CLAUDE.md`. Suggest changes to Craig 2 instead.
- Questions about feasibility go to Dan 2; questions about scope or priority go to Craig 2; design taste calls go to John.
