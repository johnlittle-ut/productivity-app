---
name: feedback-testing-no-redundancy
description: "Testing new changes is fine; John objects only to redundant or repeated testing of the same feature, not to test volume itself"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 625ba887-4e63-4656-85ea-581da3adaa22
  modified: 2026-11-04T15:48:38.803Z
---

Testing new changes is welcome and expected. What John objects to is testing the same feature the same way many times (duplicate tests, repeated full-suite runs, re-verifying unchanged features). There is no hard cap on test count.

**Why:** On 2026-11-04 he said 82 tests was excessive token use, then clarified he is fine with tests of new changes, just not redundant ones. (82 was the whole suite, about 26 of them new.)

**How to apply:** In handoffs, say "test each new behavior once", focused on tricky logic (recurrence, date math, cleanup, import/export). Skip trivial UI and CRUD tests. One suite run before reporting. Related: [[feedback-concise-agent-messages]].
