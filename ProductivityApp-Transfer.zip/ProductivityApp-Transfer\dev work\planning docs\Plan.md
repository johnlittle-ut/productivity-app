# Plan.md — Personal Calendar / To-Do App

Status: **Phase 1A (front end, local storage) built, M1 to M6 complete as of 2026-11-04; awaiting John's review.** Next: John's feedback, Ava's design specs, then Phase 1B (backend, personal laptop; see `handoffs/003-backend-outline.md`). Living document, expect tweaks.
Owner: John. Planner: Craig 2. Builder: Dan 2. (Roles and workflow are in `CLAUDE.md`.)
Last updated: 2026-11-03 (timezone, overdue section, and list ordering confirmed; **multi-user invite-only access and a Phase 4 shared calendar added**)

---

## 1. Goal and problem

John uses a single long OneNote page as a calendar and to-do list: every date of the year, Mondays in bold, with homework due dates, bills, regular events and special events typed underneath. When something is done he deletes it, and later deletes the past dates.

Regular calendar apps are unusable for him because they send far too many notifications (e.g. 15 for one event) and the alerts block his CarPlay display.

**Goal:** a personal app, used on his iPhone and Windows laptop, that behaves like his OneNote page but with automatic repeats, check-off, clean cleanup, and **minimal, deliberate notifications.**

**Sharing (added 2026-11-03):** John may later let a girlfriend and/or roommates use the app. Each person signs in with their own Google account and gets their **own private calendar, lists and settings.** A **shared calendar** for coordinating with one or more of them is a rough idea for the final phase (Phase 4). The app is **invite-only**, not open to the public.

### Hard constraints
- **$0 recurring cost.** (A very small one-time cost is acceptable only as a last resort.)
- **Developed on Windows.** No Mac, no Xcode, no Apple Developer account.
- **Invite-only** (Google sign-in plus an allow-list John controls). Each person's data is private to them. Not sensitive data, but must not be lost.
- **Works offline,** syncs when back online.
- **Notifications are opt-in per item and one-per-item.** No unprompted permission requests, no tracking, no analytics.

---

## 2. Architecture decisions

| Area | Decision | Notes |
|---|---|---|
| App type | **PWA** installed to iPhone Home Screen (Safari, Share, Add to Home Screen) | Also works in a laptop browser. |
| Frontend | **Vite + React + TypeScript**, `vite-plugin-pwa` for manifest and service worker | Dan 2 may propose Preact or similar if lighter, but must flag it to John first. |
| Backend / sync | **Firebase (Spark free plan):** Authentication (Google provider) + Firestore | John has never used Firebase. Dan 2 must give step-by-step setup instructions. |
| Local-first | Firestore **offline persistence** (IndexedDB) | The app reads and writes locally and syncs automatically. |
| Hosting | **Firebase Hosting (free)** preferred. Source code lives in a private GitHub repo. | Reason: Google sign-in via redirect can break in iOS Home Screen apps when the auth domain differs from the site domain. Hosting on Firebase keeps them the same. Dan 2 must **test sign-in on the real iPhone early** (see Risks). GitHub Pages is the fallback. |
| Backup | Manual **Export / Import JSON** in Settings | Insurance against any free-tier or account problem. |
| Access control | **Invite-only allow-list (decided 2026-11-03, option A).** Allowed people are stored as documents `allowedEmails/{lowercased email}` in Firestore. Rules admit a signed-in user only if their verified email has a document there. John adds or removes people in the Firebase console. | No rules edit or redeploy needed to add a person. Open sign-in (any Google account) was rejected. See section 3.0. |
| Security | Each person can read and write **only their own** `users/{uid}/...` data, and only while on the allow-list. Everything else denied. | Never hard-code a UID or email in app code or rules. |
| Timezone | **Per-user. Automatic by default** (the device's timezone), with an optional **override** in Settings for planning trips (revised 2026-11-04; replaces the earlier "no selector" decision). John's home zone is **America/New_York**. | **Timed events and tasks are anchored to the timezone they were entered in** (`tz` field on the item, with `date` and `startTime` as wall-clock in that zone) and are **displayed in the viewing timezone**. Example: a 9:00 AM event entered under a Central override shows as 10:00 AM after switching back to Eastern. **All-day (untimed) items are floating** (date only, never converted). Recurrence is computed in the item's own timezone, so DST is handled per zone. |
| Notifications (Phase 2) | Web Push to the installed PWA, sent by a free **Cloudflare Worker** on a cron timer | See section 7. |
| Widget (Phase 3) | **Read-only** widget via the free **Scriptable** iOS app | Decided: option A. See section 8. |

### Why a PWA and not a native app
iOS widgets and App Store apps require Apple's $99/year program. PWAs are free and need no Mac. The tradeoff is that interactive widgets are impossible. John accepted this.

---

## 3. Data model (Firestore)

All personal data lives under the signed-in user: `users/{uid}/...` (so every person is already separated). The sections below describe the shape for **one user**; every user gets their own copy.

### 3.0 Access control and multi-user

**Allow-list.** Top-level collection `allowedEmails`. Each document ID is the person's **lowercased Google email**; fields are just `addedAt` and an optional `note` (e.g. "girlfriend"). John creates and deletes these documents by hand in the Firebase console (the console bypasses rules). Using the email as the key means John can invite someone **before** they have ever signed in (their UID is not known until they do).

**Rules summary (Dan 2 writes the actual rules):**
- `users/{uid}/**`: allowed only if the user is signed in, `request.auth.uid == uid`, the email is verified, and `allowedEmails/{their lowercased email}` exists.
- `allowedEmails/{email}`: a signed-in user may `get` **only their own** document (so the app can tell "invited" from "not invited" and show a friendly message). No listing, and **no client writes at all.**
- Everything else: denied.
- Note: the rule's lookup counts as a small Firestore read. That is negligible at this scale (Spark allows 50,000 reads per day), but keep the app from doing needless repeated reads.

**First-time sign-in for an invited user:** the app creates their `settings` document with defaults (timezone from the browser, default reminder 60 minutes, digest 9:00 AM, week starts Monday). Their lists and calendar start empty.

**Not-invited users:** they can complete Google sign-in (Firebase Auth will create an account record), but they see a friendly **"This app is invite-only"** screen showing the email they signed in with, plus text like "Ask John to add this email," and a Sign out button. No raw error codes.

**Reserved for the Phase 4 shared calendar (decision):** do **not** add a `calendarId` field to items now. Personal items live under `users/{uid}/items`. Shared calendar items will later live in a separate collection such as `calendars/{calendarId}/items` with the **same item shape**, and a `calendars/{calendarId}` document holding a member list. Where an item lives tells you which calendar it belongs to, so no migration is needed. The one thing to do now (handoff 002): put **all item reads and writes behind one data-layer module**, so a second data source (a shared calendar) can be merged into the views later without rewriting the screens.

### 3.1 `items` (events and tasks)
One shared collection. Calendar and Daily Schedule are just two views of it.

| Field | Type | Notes |
|---|---|---|
| `id` | string | Auto-generated. |
| `title` | string | Required. |
| `type` | `"event"` or `"task"` | Deadlines (rent due, assignment due 11:59) are **tasks** with a date and time. |
| `date` | string `YYYY-MM-DD` | Required. For repeating items this is the first occurrence. |
| `startTime` | string `HH:mm` or null | Null means all-day or untimed. |
| `endTime` | string `HH:mm` or null | Optional, events only. |
| `notes` | string | Optional longer text (e.g. "pregame at my apartment"). |
| `done` | boolean | Non-repeating items only. |
| `doneAt` | timestamp or null | Used for the 24-hour auto-clear. |
| `repeat` | null or `{ freq: "weekly" \| "monthly" }` | Weekly and monthly only. Optional `until` date is allowed. |
| `completedOccurrences` | map `{ "YYYY-MM-DD": doneAtTimestamp }` | Repeating items only. Check-off applies to one occurrence. |
| `skippedDates` | array of `YYYY-MM-DD` | Repeating items only. "Delete just this one." |
| `reminder` | `{ enabled: bool, minutesBefore: number }` | Default for events: enabled, 60. Default for tasks: off. Adjustable per item. |
| `tz` | IANA timezone string (e.g. `America/Chicago`), timed items only | The zone `date` and `startTime`/`endTime` are expressed in. Set to the **effective timezone at entry** (override if on, else device). Missing on legacy items: stamp once with the user's current effective timezone at load. Keys in `completedOccurrences` and `skippedDates` stay as dates **in the item's own timezone**. |
| `createdAt`, `updatedAt` | timestamp | |

**Event defaults (2026-11-04):** a new event's start defaults to the **next full hour** (in the viewing timezone) and its length is **always 1 hour** (end prefilled, start + 1h). Tapping an empty calendar slot still uses that slot's hour.

**Recurrence rules**
- Weekly: same weekday as `date`. Monthly: same day-of-month as `date`; if the month is shorter (e.g. the 31st), use the **last day** of that month.
- Occurrences are **calculated by the app, never stored.** This is also why there are no "past dates to delete."
- Editing or deleting a repeating item asks: **this occurrence only** or **all occurrences.** (Do not build "this and following" for now.)
- **Delete this occurrence only** = add its date to `skippedDates`.
- **Edit this occurrence only** = add its date to `skippedDates` **and** create a new, non-repeating item with the edited values. The new item carries optional `seriesId` (the parent's id) and `originalDate` (the date it replaced). No override-merging logic. Later edits to the series ("all occurrences") do not change already-detached items.
- Monthly repeats always compute from the **original** day-of-month of `date` (never drift from a previously clamped day).
- **Overdue and repeating tasks:** for a repeating task, only the **latest past occurrence** is considered. If it is unfinished and not skipped it appears in Overdue; if it is done or skipped, nothing shows for that series. Older misses never surface, so a missed monthly bill does not pile up. (Refined by Dan 2, approved by Craig 2, 2026-11-04.)
- **24-hour cleanup of a completed repeating occurrence:** move its date into `skippedDates` instead of deleting its `completedOccurrences` entry, so the occurrence does not reappear as undone or overdue. (Approved 2026-11-04.)
- Quick-add on a date in Daily Schedule creates a **task** (expandable to the full form to change the type).

### 3.2 `shoppingItems`
`id`, `title`, `done`, `doneAt`, `createdAt`, `order` (number, for manual ordering), optional `section` (`"groceries"` or `"general"`; missing means groceries). One list tab with two sections (changed per John's direct request to Dan 2, 2026-11-04).

### 3.3 `todos` (general, not date-specific)
`id`, `title`, `done`, `doneAt`, `createdAt`, `order` (number, for manual ordering). Optional `notes`, optional `dueDate` (`YYYY-MM-DD`), optional `urgent` (boolean, default false).

**Urgency (added 2026-11-04):** a To-Do item is *urgent* if `urgent` is true **or** it has a `dueDate` within the next 7 days (including overdue). Urgent items show a **red exclamation mark** and **auto-sort to the top** (soonest due date first, then manually flagged ones, each group keeping manual order). No mark for items due more than 7 days out or with no date and no flag.

**Ordering rule (both lists):** new items are added at the **bottom** (highest `order`). John can **drag to reorder** any item, which rewrites its `order`. Use a gap-based or fractional order value so one drag only updates one document.

### 3.4 `settings` (single document, **per user**)
`timezone`, `defaultEventReminderMinutes` (60), `digestEnabled` (true), `digestTime` ("09:00"), `weekStartsOn` ("monday"), and later that user's push subscription(s) and widget token. **Nothing in settings is global**; each person has their own.

### 3.5 Completion and cleanup
- Checking an item off sets `done: true` and `doneAt: now` (or records the occurrence in `completedOccurrences`).
- Done items **disappear from normal views right away** and are **permanently deleted 24 hours after `doneAt`.**
- Cleanup runs on the client when the app opens and when it returns to the foreground. (No server is needed for this in Phase 1.)
- Within the 24 hours, an **"Undo"** is available (a small "Recently completed" area or a toast) so an accidental tap is recoverable.
- Manual delete is always available.

---

### 3.6 Versioning and conflict resolution (John's requirement, 2026-11-04)
**Rule: when copies disagree (iPhone, laptop, cloud, an import), the most recently edited version wins, judged by edit date.**
- **Every record** (items, shopping items, to-dos, settings, later group records) has **`updatedAt`**, set to the **time of the edit** (not the time it reaches the server), by the data layer in one place. Backfill legacy records (use `createdAt`, else the import time).
- **Write only the fields that changed** (partial updates), so two devices editing *different* fields of one record both survive. If both changed the **same** field, the later `updatedAt` wins.
- **Reject stale writes:** Firestore rules refuse a write whose `updatedAt` is older than the stored one (and refuse timestamps more than about 5 minutes in the future). A device whose offline edit is rejected re-reads the cloud version, keeps the newer one, and shows a small notice ("A newer version from another device was kept").
- **Deletes are timestamped too:** deleting sets `deletedAt` (and `updatedAt`) instead of removing the record at once; a later edit than the deletion restores it. The app purges records deleted more than 30 days ago. (Completed-item cleanup after 24 hours uses this same path.)
- **Clock skew:** devices' clocks can be wrong. When online, learn the offset from the server and correct timestamps with it before writing.
- **Import JSON** merges by record id: **keep whichever copy has the newer `updatedAt`**; never overwrite a newer record with an older one. Confirm with the user before applying, and show counts (added, updated, skipped as older).
- **Export JSON** always includes `updatedAt` and `deletedAt`.
- Keep the merge logic in **one small, pure function** with focused tests (newer wins, older rejected, different-field merge, delete versus edit, clock skew).

## 4. Screens and behavior

Bottom tab bar with four tabs, plus a Settings screen reached by a gear icon. **Tab order (per John's live-test feedback, reported by Dan 2, 2026-11-04): Calendar, Schedule, To-Do, Shopping.** (Sections 4.4 and 4.5 below keep their original numbering.)

### Global design
- **Phone-only layout** (confirmed by John 2026-11-04): designed for iPhone 15 (393x852) but **flexible across other phone sizes, iPhone and Android** (no foldables). On desktop the app is just the same phone-sized column on a black backdrop, like an emulator. No wide or desktop layouts.
- Follows system light and dark mode.
- **Colors:** events and tasks have clearly different colors (e.g. events blue, tasks orange). Also use a different icon or shape, not color alone, so it stays readable.
- No other categories or tags.
- A floating **"+" button** on Calendar and Daily Schedule opens the Add/Edit form.

### 4.1 Add / Edit item form
Fields: Title, Type (Event or Task toggle), Date, Time (optional), End time (optional, events), Notes, Repeat (None / Weekly / Monthly), Reminder (Off / At time / 15 min / 30 min / 1 hour / 2 hours / morning of / custom). Event default reminder is 1 hour before.

Note: in Phase 1 the reminder fields are **saved but do nothing yet** (notifications arrive in Phase 2). The UI may show them with a small "coming soon" note, or hide them until Phase 2. **Dan 2: hide them until Phase 2, but keep the fields in the data model.**

### 4.2 Calendar tab (time-grid day view, redesigned 2026-11-04)
**Purpose (per John):** an Outlook-style view to see **chunks of the day that are taken up**, not another list of the same items as Schedule. Same underlying data; different presentation.
- **Header and week strip (unchanged):** week range, prev / next / Today, Monday to Sunday strip, today ringed, selected day filled, swipe to change week.
- **Below the strip: a single-day hour grid.** Hour labels down the left, a faint line per hour, scrollable. On open, scroll to the current hour (today) or about 7 AM (other days). A red "now" line on today.
- **Events only by default.** Each event is a **block positioned and sized by start and end time**. Event with no end time: default **1 hour**. Overlapping events sit **side by side**.
- **All-day / untimed events** go in a slim strip above the grid.
- **Tasks:** shown only if the task has **"Show on calendar" on** (new per-task flag, default off, in the task's edit sheet). Flagged tasks with a time appear as a small block at that time (default 30 min, task color and icon); flagged tasks with no time appear in the all-day strip. Check circle still works on them.
- Tap a block to edit. Tap an empty slot to add an **event** starting at that hour. "+" adds on the selected day.
- Dots on the strip reflect what the grid would show (events, plus flagged tasks).
- Data change: item gets optional `showOnCalendar` (boolean, tasks only, default false). Missing means false.
- **Day | Week toggle** (added per John's direct request to Dan 2 during the build). **Day** = the hour grid above. **Week** = seven aligned day columns (about 46 px each, titles truncated), all-day chips, tap to edit. Arrows and swipe move **by day** in Day view and **by week** in Week view.
- Phone-sized layout only (see CLAUDE.md devices decision).

### 4.3 Daily Schedule tab (OneNote style)
Modeled on John's OneNote page:
- A **continuous scrolling list from today forward**, one block per date, with a header like `11/2` (and day name).
- **Mondays are bold,** with extra spacing, replacing the bolded Mondays in OneNote.
- **Every date is shown, even empty ones** (like OneNote), so it is easy to add something to any day. Load further dates as John scrolls (e.g. 60 days at a time).
- Under each date: **timed items in time order first,** then untimed items as a checklist. **Timed items are time-first** (changed per John's live-test feedback, 2026-11-04): a bold, aligned time column, then a dash, then the title, e.g. `6:30pm - Thrive`.
- Each item has a check circle. Checking it off hides it (see 3.5).
- A quick inline "add" on each date (title only, then expand for more details).
- **Overdue section (proposed):** unfinished tasks from past dates appear in an "Overdue" block at the top, so nothing silently disappears the way deleted dates do in OneNote. Events from the past simply drop off. *John to confirm.*
- Past dates are not shown.
- **Swipe right on a task** (tasks only, not events) reveals **"Move to tomorrow"** (tomorrow in the user's timezone; Undo toast). On a repeating task it applies to **that occurrence only**. (John, 2026-11-04.)
- **Search (Schedule tab only):** a magnifier icon in the header; **no persistent search bar**. Tapping it expands a field; it collapses when closed or empty. Matches title and notes of upcoming and overdue items, listing date and time; tapping a result opens it for editing. (John, 2026-11-04.)

### 4.4 Shopping List tab
One tab with two sub-tabs at the top, **Groceries** and **General**, each switching which single list is shown (and where new items are added). Reorder works within a list; the edit sheet moves an item between lists. (Layout changed again per John's direct request to Dan 2, 2026-11-04; replaces the earlier stacked-sections version.) Type to add. Check off with the **check circle only** (tapping the text opens edit/delete, which avoids accidental check-offs). Checked items are cleared after 24 hours. **New items go at the bottom.** John can **drag to reorder** (use a drag handle so scrolling on a phone does not accidentally move items; it must work with touch on iPhone and mouse on laptop).

### 4.5 General To-Do tab
Same behavior as the shopping list, for non-dated tasks: new items at the bottom, drag to reorder, check off, 24-hour clear. Optional notes.

### 4.6 Settings
Per-user: **12 or 24-hour time** (`settings.timeFormat`, default 12), **timezone: "Automatic (device)" by default, with an override picker** (`settings.timezoneOverride`, null = automatic; the effective timezone is still saved to settings for the Phase 2 server), **text size slider** (all text scales from one setting), **default tab on open** (default Schedule), **Appearance** (System / Light / Dark, default System, stored as optional `settings.theme`; added per John's request to Dan 2, 2026-11-04), default reminder, a **"Recently completed" button** (opens the list with Undo; no inline list), **no timezone selector** (the app reads the device timezone automatically and saves it to the user's settings whenever it changes), Export JSON, Import JSON (each person exports only their own data), Sign out, and the signed-in email shown. (Digest time and notification toggles added in Phase 2.)

### 4.7 Sign-in screen
"Sign in with Google" button only. After sign-in, if the account's email is not on the allow-list, show the friendly **"This app is invite-only"** screen described in 3.0 (with the email shown and a Sign out button). Firestore rules enforce this on the server too, so the screen is a courtesy, not the security.

---

## 5. Build phases

### Phase 1: Core app (target: working app John can use daily)

> **Revision 2026-11-04: Phase 1 is split in two.** John must do the backend from his **personal laptop** (tied to his personal Google account), so:
> - **Phase 1A (now): the full front end on a local dev server**, using local IndexedDB storage behind a single data-layer interface and an auth stub. Covers the screens, data model, recurrence, check-off/undo/cleanup, lists, Settings, Export/Import and PWA basics. This is **handoff 002** (`handoffs/002-frontend-local-build.md`), which replaces the old handoffs 002 to 006 in the table below (those rows remain as a description of the scope).
> - **Phase 1B (later, personal laptop): connect the backend.** Firebase project, Google sign-in, invite-only allow-list and rules, swap the local data layer for Firestore, import the local JSON export, deploy to Firebase Hosting, and run the iPhone Home Screen sign-in test. This reuses handoff 001 steps 3, 4, 5, 7.
Handoffs (each small enough for Dan 2 to finish and for John to test):

| # | Handoff | Contents |
|---|---|---|
| 001 | **Project setup and Firebase** (large file) | Repo scaffold (Vite, React, TS, PWA plugin), Firebase project and Hosting setup walkthrough, Google sign-in, **invite-only allow-list and per-user Firestore rules**, friendly "invite-only" screen, tab shell, deploy to a live URL, install on iPhone. Includes the early iPhone sign-in test. Also creates `CHANGELOG.md`. |
| 002 | **Data layer and Add/Edit form** | Types, Firestore reads and writes with offline persistence, recurrence engine (weekly, monthly, month-end clamp), add / edit / delete / this-or-all prompt. |
| 003 | **Daily Schedule tab** | OneNote-style list, Monday emphasis, check-off, undo, 24-hour cleanup, overdue section. |
| 004 | **Calendar tab (week view)** | Phone and laptop layouts. |
| 005 | **Shopping List and General To-Do** | Both lists, new items at bottom, drag-to-reorder, check-off and cleanup. |
| 006 | **Settings, backup and polish** | Export / Import JSON, icons, offline behavior check, error states. |

**Phase 1 is done when:** John can sign in on both devices, add events and tasks (including repeating ones), see them in both views, check them off, have them auto-clear after 24 hours, work offline, and export a backup. Changes made on one device appear on the other.

### Phase 2: Notifications
Detailed plan: `handoffs/005-notifications.md`. Home-laptop steps for every remaining phase: `HOME-CHECKLIST.md`. Backend handoff: `handoffs/003-backend-connect.md`.
- Web Push set-up (service worker, subscription saved to Firestore **under that user**, permission requested **only** when the user taps "Enable notifications" in Settings).
- **Per-item reminders** (default for events: 1 hour before; adjustable).
- **Daily digest at 9:00 AM** (each user's own digest time and timezone) with the day's events and to-dos.
- **Everything is per-user:** each person has their own push subscription(s), settings, and notifications. One server job serves all allowed users.
- Server side: see section 7.

### Phase 3: Widget and polish
- Read-only home screen widget (section 8), with a **separate secret token per user**.
- Optional quick-add text parsing ("Thrive fri 6:30pm").
- Small visual tweaks, anything John wants after real use.

### Phase 4: Interactive tab (groups and shared availability) 
**Designed 2026-11-04 with John.** Supersedes the earlier "shared calendar" idea and the `calendars/{calendarId}` structure in section 3.0. Full spec: `handoffs/004-interactive-tab.md`.
- A fifth tab, **Interactive**. A user can be in **multiple groups**. Expected scale: **under about 30 users**, mostly close friends (fits the free tier).
- A group shows **availability only**: members' **busy blocks, never details**. It mirrors each member's personal calendar (timed events; flagged tasks; untimed events are not busy by default).
- **Group events:** any member adds one; it sends an **invite and notification** to the others, who **accept** (copied onto their personal calendar in a group color) or **decline**.
- **Events always count as busy** (decided 2026-11-04). In the group availability view, tapping one of your **own** busy blocks (visible only to you, with its title) offers **"Remove from group view"**, which sets optional `hideFromGroups` on that event (applies to all groups) so it no longer counts as busy. Hidden events show faded or dashed in your own lane with **"Show in group view"** to undo.
- **Scheduling Assistant (added per John's request to Dan 2, 2026-11-04):** the group event sheet shows per-member busy lanes for the chosen day, the proposed-time band, a "Busy then: ..." status, suggested times when everyone is free, and tap-the-grid to move the start. Busy-only data, no details. Not built: drag-to-select range, multi-day find-a-time.
- **Join** by a **one-time link that expires in 20 minutes**. Any member can invite, rename or leave; no admin roles. **Group settings** include name, members, color, leave, and group notification settings (placeholder until Phase 2).
- **Build order:** front end now against **mock data** (handoff 004). Real backend and invite links come **last**, because testing needs multiple Google accounts.
- **Backend sketch (later):** `groups/{groupId}` with members; `groups/{groupId}/busy/{uid}` with **only intervals** (no titles), written by each user; `groups/{groupId}/events/{id}` with responses; invite tokens redeemed through Firestore rules (one-time, 20-minute expiry). Invitees must already be on the app's allow-list. **Group and member colors are stored as slot numbers 1 to 6** (resolved to theme colors by CSS variables `--g1` to `--g6`), never hex values. **Backend-phase TODO:** group events must be **tz-anchored** (store the creator's `tz`, like personal timed events) so members in different timezones all see the correct local time; accepted copies should keep the group event's `tz`. In the local mock they are wall-clock in the viewer's zone, which is fine for a single-zone test.

---

## 6. Firebase setup notes for Dan 2 (John is new to it)

Dan 2 must walk John through, one small step at a time, with exact clicks and without assuming knowledge:
1. Creating a Firebase project on the **Spark (free)** plan.
2. Enabling Google as a sign-in provider.
3. Creating the Firestore database.
4. Registering the web app and copying the config into the project (config values are not secret, but do not commit service-account keys).
5. Installing Firebase CLI on Windows and `firebase deploy`.
6. Setting up the **invite-only allow-list** (section 3.0): create `allowedEmails/{John's lowercased email}` in the console **first**, then deploy the per-user rules. (If the rules go live before John is on the list, he is locked out.) Also teach John how to add and remove another person later. John should use a **personal** Google account for the Firebase project and for signing in, not a work or school account.
7. Setting a **budget alert** (or confirming the project stays on Spark) so John can never be billed by surprise.

---

## 7. Phase 2 server design (notifications)

**Problem:** iPhone web apps can only receive a notification at a set time if a server sends the push at that time.

**Leading design:** a **Cloudflare Worker** (free tier) with a cron trigger running every 5 minutes.
1. Worker reads Firestore (REST API with a service account kept as a Worker secret) for **each allowed user's** items with reminders due in the next window, and for each user's 9:00 AM digest.
2. Worker sends **Web Push (VAPID)** to **that user's** saved subscription(s). It never sends one person's items to another person.
3. Worker marks reminders as sent (so there is exactly **one** notification per item, never duplicates).
4. Each digest check is done in **that user's own timezone and digest time** so daylight saving does not break it.
5. A single Worker config serves everyone; there is no per-user deployment. Adding a person means adding their email to the allow-list, and they enable notifications on their own phone.

**Alternative:** Firebase scheduled Cloud Functions. Rejected for now because it requires the Blaze (pay-as-you-go) plan with a credit card on file. It would likely stay free at this scale, but John prefers to avoid it. Revisit only if the Worker approach fails.

**Fallback for the digest:** an iOS **Shortcuts personal automation** at 9:00 AM that fetches the day's summary and shows a normal notification. This needs no push at all.

**Known risks**
- Web push on iPhone only works when the app is **installed to the Home Screen** (iOS 16.4 or later).
- iOS web push is somewhat less reliable than native push. Dan 2 should test over several days before John depends on it.
- Notifications should be configured so they are standard single notifications and do not repeat, to protect CarPlay.

---

## 8. Phase 3: widget design (Scriptable)

- **Read-only.** iOS does not allow interactive widgets for PWAs. John cannot check off items from the widget. Tapping it opens the PWA.
- John installs the free **Scriptable** app. Dan 2 writes the widget script (JavaScript) and John pastes it in.
- The script fetches today's events and tasks from a small endpoint (the same Cloudflare Worker) protected by a long **secret token** in the URL. Not sensitive data, but the URL must not be guessable. **Each user has their own token**, which maps to that user only (e.g. a `widgetTokens/{token}` lookup to a UID, written by the app on the user's behalf).
- Shows today's date, timed items in order, then tasks, with the event and task colors.
- Refresh time is controlled by iOS and is not guaranteed to be instant. Set expectations accordingly.

---

## 9. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Google sign-in fails in iOS Home Screen mode | Host on Firebase Hosting (same domain for auth). **Test on the real iPhone in handoff 001** before building anything else. |
| iOS clears web storage | Firestore holds the real copy, plus JSON export. |
| Push notifications are unreliable | Test early in Phase 2. Fall back to the Shortcuts digest. |
| Free-tier changes or account problems | Regular JSON export. Data is small and portable. |
| Accidental deletion or check-off | 24-hour undo window, confirm prompt on delete. |
| Scope creep | New ideas go on the list in section 11, not straight into the build. |
| An invited person's Google account is a work or school (Workspace) account that the admin blocks from outside apps | Prefer personal Google accounts for everyone. Test when the first person is invited. John's own Firebase project and sign-in should also be a personal account. |
| Someone not invited signs in anyway | Rules deny all data; app shows the friendly invite-only screen. They may appear in Firebase Authentication's user list, which is harmless and can be deleted there. |
| John removes someone from the allow-list | They are blocked immediately; their old data remains under their UID until John deletes it in the console (document this in the README). |

---

## 10. Out of scope (for now)
- Interactive widget, native iOS app, App Store.
- Open public sign-up. (Several invited users is **in scope** from Phase 1. A shared calendar is **Phase 4**, not earlier.)
- An in-app admin screen for managing the allow-list (John uses the Firebase console; revisit later if it gets annoying).
- Tags, categories, or source labels beyond event vs task color.
- Recurrence other than weekly and monthly.
- Syncing with Apple Calendar or Google Calendar.
- Analytics of any kind.

---

## 11. Open questions and tweak list
- [ ] **Finalization checklist (do when wrapping up):** make the app **open on the Schedule tab by default** (John's request, 2026-11-04).
- [x] Timezone is **America/New_York**. (Confirmed by John.)
- [x] **Overdue** section for unfinished past tasks. (Confirmed by John.)
- [ ] Confirm the phone layout proposal for the Calendar week view (strip plus selected-day list) after seeing it.
- [x] New shopping and to-do items go at the **bottom**, with drag-to-reorder. (Confirmed by John.)
- [x] Access model: **invite-only allow-list keyed by email** (option A). (Decided by Craig 2, 2026-11-03.)
- [ ] John's personal Google email to seed the allow-list (collected during handoff 001).
- [ ] Phase 4 shared calendar design (later).
- [ ] Where Dan 2's code workspace lives on John's laptop (recommended: outside OneDrive, see handoff 001, step 0).
- [ ] **Candidate changes from John's `FUTURECHANGES.md`** (John-owned, read-only for agents). **Update 2026-11-04: John approved the Recently-completed button, timezone removal and To-Do urgency marks for building; the Interactive tab was built in handoff 004.**:
  - **"Interactive" tab** for roommates, close friends, family, partners; starts as the shared calendar. Last front-end item. This is the Phase 4 shared calendar's UI.
  - **"Recently completed"** in Settings becomes a **button** opening a view, instead of an inline list.
  - **Remove the timezone selector** from the UI. The app should read the device's timezone automatically (so travel needs no manual change). Implication for Phase 2: the **server needs each user's timezone**, so the app should save the detected device timezone to that user's settings whenever it changes.
- [ ] Items John wants later: ___

---

## 12. Next action
Craig 2 writes **handoff 001** as `handoffs/001-project-setup-and-firebase.md` (large, so it is a file). John passes it to Dan 2.
