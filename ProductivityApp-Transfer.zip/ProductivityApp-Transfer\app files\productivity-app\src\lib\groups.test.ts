import { describe, expect, it } from 'vitest'
import { makeItem } from '../data/defaults'
import { toColorSlot, type GroupEvent, type InviteLink } from '../groups/model'
import type { Item, NewItem } from '../types'
import { busyForDay, computeBusy, freeRanges, myBlocks, suggestSlots } from './busy'
import { instantToWall, zonedToInstant } from './tz'
import { acceptedCopy, formatCountdown, linkStatus, planGroupSync } from './groupLogic'

const mk = (input: NewItem): Item => makeItem(input, 1)
const T = '2026-11-04'
const ET = 'America/New_York'

describe('computeBusy', () => {
  it('timed events: start to end, default 1 hour, repeats expanded, skipped dates ignored', () => {
    const thrive = mk({
      title: 'Thrive',
      type: 'event',
      date: '2026-11-06',
      startTime: '18:30',
      endTime: '20:00',
      repeat: { freq: 'weekly' },
      skippedDates: ['2026-11-13'],
    })
    const noEnd = mk({ title: 'b', type: 'event', date: T, startTime: '14:00' })
    const busy = computeBusy([thrive, noEnd], 'me', T, ET, 30)
    expect(busyForDay(busy, T, ET).filter((b) => b.start === 14 * 60).map((b) => b.end)).toEqual([15 * 60]) // 1 hour
    expect(busy.map((b) => instantToWall(b.start, ET)).filter((w) => w.time === '18:30').map((w) => w.date)).toEqual(['2026-11-06', '2026-11-20', '2026-11-27'])
  })

  it('all-day events and plain tasks are not busy; flagged timed tasks are (30 min)', () => {
    const busy = computeBusy(
      [
        mk({ title: 'birthday', type: 'event', date: T }),
        mk({ title: 'task', type: 'task', date: T, startTime: '09:00' }),
        mk({ title: 'flagged', type: 'task', date: T, startTime: '09:00', showOnCalendar: true }),
      ],
      'me',
      T,
      ET,
    )
    expect(busy).toEqual([{ userId: 'me', start: zonedToInstant(T, '09:00', ET), end: zonedToInstant(T, '09:30', ET) }])
  })

  it('output never contains titles or notes', () => {
    const busy = computeBusy([mk({ title: 'Secret', type: 'event', date: T, startTime: '10:00', notes: 'private' })], 'me', T, ET)
    expect(JSON.stringify(busy)).not.toMatch(/Secret|private/)
    expect(Object.keys(busy[0]).sort()).toEqual(['end', 'start', 'userId'])
  })
})

describe('shared free time', () => {
  it('finds gaps where nobody is busy within 7 AM to 11 PM, merging overlaps', () => {
    const busy = [
      { start: 9 * 60, end: 12 * 60 },
      { start: 11 * 60, end: 17 * 60 },
      { start: 22 * 60 + 45, end: 23 * 60 + 30 },
    ]
    expect(freeRanges(busy)).toEqual([
      { start: 7 * 60, end: 9 * 60 },
      { start: 17 * 60, end: 22 * 60 + 45 },
    ])
  })
})

describe('accepted group-event copies stay in sync', () => {
  const ev = (over: Partial<GroupEvent> = {}): GroupEvent => ({
    id: 'e1',
    groupId: 'g1',
    title: 'Game night',
    date: '2026-11-07',
    startTime: '19:00',
    endTime: '21:00',
    notes: '',
    creatorId: 'alex',
    createdAt: 1,
    responses: {},
    ...over,
  })

  it('edit updates the copy, cancel removes it, a vanished event detaches it', () => {
    const copy = mk(acceptedCopy(ev()))
    expect(planGroupSync([copy], [ev()])).toEqual({ removeIds: [], updates: [] })
    expect(planGroupSync([copy], [ev({ startTime: '20:00' })]).updates[0].patch).toMatchObject({ startTime: '20:00' })
    expect(planGroupSync([copy], [ev({ cancelled: true })]).removeIds).toEqual([copy.id])
    expect(planGroupSync([copy], []).updates[0].patch).toEqual({ groupId: undefined, groupEventId: undefined })
  })
})

describe('invite links', () => {
  const link: InviteLink = { token: 't', groupId: 'g', url: '', createdAt: 0, expiresAt: 1_200_000, usedAt: null }

  it('valid until the deadline, then expired; used wins; countdown rounds up', () => {
    expect(linkStatus(link, 1_199_999)).toBe('valid')
    expect(linkStatus(link, 1_200_000)).toBe('expired')
    expect(linkStatus({ ...link, usedAt: 5 }, 10)).toBe('used')
    expect(formatCountdown(1_200_000)).toBe('20:00')
    expect(formatCountdown(500)).toBe('0:01')
  })
})

describe('group color migration', () => {
  it('keeps valid slots, maps old hex colors to the nearest slot, and falls back to slot 1', () => {
    expect([1, 3, 6].map(toColorSlot)).toEqual([1, 3, 6])
    expect(['#8e5bf6', '#16a085', '#e0457b', '#d68a00', '#2f9e44', '#0e86d4'].map(toColorSlot)).toEqual([5, 3, 2, 4, 3, 1])
    expect(toColorSlot('#2f7bf6')).toBe(1) // the old blue
    expect([0, 7, 2.5, 'red', null, undefined].map(toColorSlot)).toEqual([1, 1, 1, 1, 1, 1])
  })
})

describe('scheduling suggestions', () => {
  it('suggests non-overlapping half-hour-aligned slots where everyone is free for the whole duration', () => {
    const busy = [
      { start: 9 * 60, end: 12 * 60 + 15 }, // someone busy 9:00-12:15
      { start: 15 * 60, end: 16 * 60 },
    ]
    const slots = suggestSlots(busy, 90)
    expect(slots[0]).toEqual({ start: 7 * 60, end: 8 * 60 + 30 }) // morning gap fits 90 min
    expect(slots[1]).toEqual({ start: 12 * 60 + 30, end: 14 * 60 }) // first half hour after 12:15
    expect(slots.every((s) => s.end - s.start === 90)).toBe(true)
    expect(suggestSlots([{ start: 7 * 60, end: 23 * 60 }], 60)).toEqual([]) // nothing free
  })
})

describe('hide from groups', () => {
  it('computeBusy skips hidden events, myBlocks still lists them', () => {
    const shown = mk({ title: 'a', type: 'event', date: T, startTime: '10:00' })
    const hidden = mk({ title: 'b', type: 'event', date: T, startTime: '12:00', hideFromGroups: true })
    expect(computeBusy([shown, hidden], 'me', T, ET).map((b) => b.start)).toEqual([zonedToInstant(T, '10:00', ET)])
    expect(myBlocks([shown, hidden], T, ET).map((b) => [b.title, b.hidden])).toEqual([['a', false], ['b', true]])
  })
})
