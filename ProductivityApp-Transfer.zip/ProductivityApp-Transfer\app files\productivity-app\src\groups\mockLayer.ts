// Local mock of the GroupLayer: in-memory state saved to localStorage, seeded with fake friends.
// Replaced by a Firestore implementation in the backend phase.

import { auth } from '../auth/auth'
import type { Listener, Unsubscribe } from '../data/types'
import { browserTimezone, todayIn } from '../lib/dates'
import { linkStatus, parseToken } from '../lib/groupLogic'
import { zonedToInstant } from '../lib/tz'
import { mockBusy } from './mockBusy'
import type { GroupLayer, MockControls } from './layer'
import {
  LINK_TTL_MS,
  type BusyInterval,
  type Group,
  type GroupEvent,
  type InviteLink,
  type Member,
  toColorSlot,
  type RedeemResult,
  type Response,
} from './model'

const STORAGE_KEY = 'productivity-app:mock-groups:v1'

const FRIENDS: Member[] = [
  { id: 'alex', name: 'Alex Rivera', color: 2 },
  { id: 'sam', name: 'Sam Chen', color: 3 },
  { id: 'jordan', name: 'Jordan Blake', color: 4 },
  { id: 'riley', name: 'Riley Park', color: 5 },
]

interface State {
  groups: Group[]
  events: GroupEvent[]
  links: InviteLink[]
  busyMine: BusyInterval[]
}

const uid = () => crypto.randomUUID().slice(0, 8)

/** Older saved state stored colors as hex; move them to numbered slots. */
function migrateState(state: State): State {
  // older saved busy rows were {date, start, end} in minutes; convert to absolute instants (device zone)
  const tz = browserTimezone()
  const busyMine = (state.busyMine as unknown as { userId: string; date?: string; start: number; end: number }[]).map((b) => {
    if (!b.date) return b
    const s = zonedToInstant(b.date, `${String(Math.floor(b.start / 60)).padStart(2, '0')}:${String(b.start % 60).padStart(2, '0')}`, tz)
    return { userId: b.userId, start: s, end: s + (b.end - b.start) * 60_000 }
  })
  return { ...state, busyMine, groups: state.groups.map((g) => ({ ...g, color: toColorSlot(g.color) })) }
}

function nowTodayStr(): string {
  return todayIn(browserTimezone())
}

function addDaysStr(date: string, n: number): string {
  const [y, m, d] = date.split('-').map(Number)
  const dt = new Date(Date.UTC(y, m - 1, d + n))
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}-${String(dt.getUTCDate()).padStart(2, '0')}`
}

export function createMockGroupLayer(
  meId: string = auth.getUserId(),
  opts: { persist?: boolean; seed?: boolean } = {},
): GroupLayer & MockControls {
  const persist = opts.persist ?? true
  const me: Member = { id: meId, name: 'Me', color: 1 }
  const directory: Member[] = [me, ...FRIENDS]
  const byId = (id: string) => directory.find((m) => m.id === id)

  function seedState(): State {
    const today = nowTodayStr()
    const roommates: Group = {
      id: 'g-roommates',
      name: 'Roommates',
      color: 5,
      memberIds: [meId, 'alex', 'sam'],
      createdAt: Date.now(),
    }
    const friends: Group = {
      id: 'g-friends',
      name: 'Friends',
      color: 3,
      memberIds: [meId, 'jordan', 'riley', 'sam'],
      createdAt: Date.now(),
    }
    const invite: GroupEvent = {
      id: 'e-seed-1',
      groupId: roommates.id,
      title: 'Game night',
      date: addDaysStr(today, 3),
      startTime: '19:00',
      endTime: '21:00',
      notes: 'Bring snacks',
      creatorId: 'alex',
      createdAt: Date.now(),
      responses: { [meId]: 'pending', alex: 'accepted', sam: 'pending' },
    }
    const existing: GroupEvent = {
      id: 'e-seed-2',
      groupId: friends.id,
      title: 'Brunch',
      date: addDaysStr(today, 5),
      startTime: '11:00',
      endTime: '12:30',
      notes: '',
      creatorId: 'jordan',
      createdAt: Date.now(),
      responses: { [meId]: 'declined', jordan: 'accepted', riley: 'accepted', sam: 'pending' },
    }
    return { groups: [roommates, friends], events: [invite, existing], links: [], busyMine: [] }
  }

  function load(): State {
    if (persist) {
      try {
        const raw = localStorage.getItem(STORAGE_KEY)
        if (raw) return migrateState(JSON.parse(raw) as State)
      } catch {
        /* fall through to a fresh state */
      }
    }
    return opts.seed === false ? { groups: [], events: [], links: [], busyMine: [] } : seedState()
  }

  let state: State = load()
  if (persist) {
    // write migrated colors back so old hex values do not linger in saved state
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch {
      /* ignore */
    }
  }
  const listeners = new Set<() => void>()

  function commit(next: State) {
    state = next
    if (persist) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
      } catch {
        /* storage unavailable: keep in memory */
      }
    }
    listeners.forEach((l) => l())
  }

  function watch<T>(select: () => T, cb: Listener<T>): Unsubscribe {
    cb(select())
    const l = () => cb(select())
    listeners.add(l)
    return () => listeners.delete(l)
  }

  const myGroups = () =>
    state.groups.filter((g) => g.memberIds.includes(meId)).map((g) => ({ ...g, color: toColorSlot(g.color) }))
  const memoBusy = new Map<string, BusyInterval[]>()
  function friendBusy(id: string): BusyInterval[] {
    const key = `${id}:${nowTodayStr()}`
    let v = memoBusy.get(key)
    if (!v) {
      v = mockBusy(id, nowTodayStr(), browserTimezone())
      memoBusy.set(key, v)
    }
    return v
  }

  const layer: GroupLayer & MockControls = {
    me,

    members: {
      subscribe: (cb) =>
        watch(() => {
          const ids = new Set(myGroups().flatMap((g) => g.memberIds))
          return directory.filter((m) => ids.has(m.id)).map((m) => ({ ...m, color: toColorSlot(m.color) }))
        }, cb),
    },

    groups: {
      subscribe: (cb) => watch(() => myGroups(), cb),
      async create(name, color) {
        const group: Group = { id: `g-${uid()}`, name: name.trim(), color, memberIds: [meId], createdAt: Date.now() }
        commit({ ...state, groups: [...state.groups, group] })
        return group
      },
      async update(groupId, patch) {
        commit({ ...state, groups: state.groups.map((g) => (g.id === groupId ? { ...g, ...patch } : g)) })
      },
      async leave(groupId) {
        commit({
          ...state,
          groups: state.groups.map((g) => (g.id === groupId ? { ...g, memberIds: g.memberIds.filter((m) => m !== meId) } : g)),
        })
      },
    },

    events: {
      subscribeAll: (cb) => watch(() => state.events.filter((e) => myGroups().some((g) => g.id === e.groupId)), cb),
      async create(groupId, input) {
        const group = state.groups.find((g) => g.id === groupId)
        const responses: Record<string, Response> = {}
        for (const m of group?.memberIds ?? []) responses[m] = m === meId ? 'accepted' : 'pending'
        const event: GroupEvent = { ...input, id: `e-${uid()}`, groupId, creatorId: meId, createdAt: Date.now(), responses }
        commit({ ...state, events: [...state.events, event] })
        return event
      },
      async update(eventId, input) {
        commit({ ...state, events: state.events.map((e) => (e.id === eventId ? { ...e, ...input } : e)) })
      },
      async cancel(eventId) {
        commit({ ...state, events: state.events.map((e) => (e.id === eventId ? { ...e, cancelled: true } : e)) })
      },
      async respond(eventId, response) {
        commit({
          ...state,
          events: state.events.map((e) => (e.id === eventId ? { ...e, responses: { ...e.responses, [meId]: response } } : e)),
        })
      },
    },

    busy: {
      subscribe: (groupId, cb) =>
        watch(() => {
          const group = state.groups.find((g) => g.id === groupId)
          if (!group) return []
          return group.memberIds.flatMap((id) => (id === meId ? state.busyMine : friendBusy(id)))
        }, cb),
      async publishMine(intervals) {
        // Only publish when it actually changed, so this cannot loop with subscribers
        if (JSON.stringify(intervals) === JSON.stringify(state.busyMine)) return
        commit({ ...state, busyMine: intervals })
      },
    },

    links: {
      subscribe: (cb) => watch(() => state.links, cb),
      async create(groupId) {
        const token = uid() + uid()
        const now = Date.now()
        const link: InviteLink = {
          token,
          groupId,
          url: `https://app.invalid/join/${token}`,
          createdAt: now,
          expiresAt: now + LINK_TTL_MS,
          usedAt: null,
        }
        commit({ ...state, links: [...state.links, link] })
        return link
      },
      async redeem(text): Promise<RedeemResult> {
        const token = parseToken(text)
        const link = token ? state.links.find((l) => l.token === token) : undefined
        if (!link) return { ok: false, reason: 'invalid' }
        const status = linkStatus(link, Date.now())
        if (status === 'used') return { ok: false, reason: 'used' }
        if (status === 'expired') return { ok: false, reason: 'expired' }
        const group = state.groups.find((g) => g.id === link.groupId)
        if (!group) return { ok: false, reason: 'invalid' }
        if (group.memberIds.includes(meId)) return { ok: false, reason: 'already-member' }
        commit({
          ...state,
          groups: state.groups.map((g) => (g.id === group.id ? { ...g, memberIds: [...g.memberIds, meId] } : g)),
          links: state.links.map((l) => (l.token === token ? { ...l, usedAt: Date.now() } : l)),
        })
        return { ok: true, groupId: group.id }
      },
    },

    // ---------- mock controls (dev section) ----------

    async seed() {
      memoBusy.clear()
      commit({ ...seedState(), busyMine: state.busyMine })
    },

    async simulateJoin(groupId) {
      const group = state.groups.find((g) => g.id === groupId)
      const next = FRIENDS.find((f) => group && !group.memberIds.includes(f.id))
      if (!group || !next) return null
      commit({
        ...state,
        groups: state.groups.map((g) => (g.id === groupId ? { ...g, memberIds: [...g.memberIds, next.id] } : g)),
      })
      return `${next.name} joined ${group.name}.`
    },

    async simulateLeave(groupId) {
      const group = state.groups.find((g) => g.id === groupId)
      const leaving = group?.memberIds.filter((m) => m !== meId).pop()
      if (!group || !leaving) return null
      commit({
        ...state,
        groups: state.groups.map((g) => (g.id === groupId ? { ...g, memberIds: g.memberIds.filter((m) => m !== leaving) } : g)),
      })
      return `${byId(leaving)?.name ?? leaving} left ${group.name}.`
    },

    async simulateIncomingInvite() {
      const group = myGroups().find((g) => g.memberIds.some((m) => m !== meId))
      const creator = group?.memberIds.find((m) => m !== meId)
      if (!group || !creator) return null
      const titles = ['Movie night', 'Pizza run', 'Board games', 'Study session', 'Hike']
      const title = titles[state.events.length % titles.length]
      const responses: Record<string, Response> = {}
      for (const m of group.memberIds) responses[m] = m === creator ? 'accepted' : 'pending'
      const event: GroupEvent = {
        id: `e-${uid()}`,
        groupId: group.id,
        title,
        date: addDaysStr(nowTodayStr(), 2),
        startTime: '18:00',
        endTime: '20:00',
        notes: '',
        creatorId: creator,
        createdAt: Date.now(),
        responses,
      }
      commit({ ...state, events: [...state.events, event] })
      return `${byId(creator)?.name ?? creator} invited you to "${title}" in ${group.name}.`
    },

    async createJoinableGroupLink() {
      const group: Group = {
        id: `g-${uid()}`,
        name: 'Climbing crew',
        color: 2,
        memberIds: ['jordan', 'riley'],
        createdAt: Date.now(),
      }
      commit({ ...state, groups: [...state.groups, group] })
      return layer.links.create(group.id)
    },

    async simulateLinkUsed(token) {
      const link = state.links.find((l) => l.token === token)
      if (!link || link.usedAt !== null) return null
      const group = state.groups.find((g) => g.id === link.groupId)
      const joiner = FRIENDS.find((f) => group && !group.memberIds.includes(f.id))
      if (!group || !joiner) return null
      commit({
        ...state,
        groups: state.groups.map((g) => (g.id === group.id ? { ...g, memberIds: [...g.memberIds, joiner.id] } : g)),
        links: state.links.map((l) => (l.token === token ? { ...l, usedAt: Date.now() } : l)),
      })
      return `${joiner.name} used the link and joined ${group.name}.`
    },
  }

  return layer
}
