// Recurrence engine. Occurrences are calculated, never stored.
// Weekly: same weekday as the anchor date. Monthly: same day-of-month, clamped to the month's last day.

import type { Item } from '../types'
import { addDays, daysInMonth, parseDate } from './dates'

type Recurring = Pick<Item, 'date' | 'repeat' | 'skippedDates'>

/** Whole days from `a` to `b` (b - a). Negative if b is earlier. */
export function diffDays(a: string, b: string): number {
  const pa = parseDate(a)
  const pb = parseDate(b)
  return Math.round((Date.UTC(pb.y, pb.m - 1, pb.d) - Date.UTC(pa.y, pa.m - 1, pa.d)) / 86_400_000)
}

export function occursOn(item: Recurring, date: string): boolean {
  if (date < item.date) return false
  if (item.skippedDates.includes(date)) return false
  const r = item.repeat
  if (!r) return date === item.date
  if (r.until && date > r.until) return false
  if (r.freq === 'weekly') return diffDays(item.date, date) % 7 === 0
  const anchorDay = parseDate(item.date).d
  const { y, m, d } = parseDate(date)
  return d === Math.min(anchorDay, daysInMonth(y, m))
}

/** All occurrence dates of an item within [from, to] inclusive, in order. */
export function occurrenceDates(item: Recurring, from: string, to: string): string[] {
  if (!item.repeat) {
    return item.date >= from && item.date <= to && occursOn(item, item.date) ? [item.date] : []
  }
  const dates: string[] = []
  const start = from > item.date ? from : item.date
  for (let d = start; d <= to; d = addDays(d, 1)) {
    if (occursOn(item, d)) dates.push(d)
  }
  return dates
}
