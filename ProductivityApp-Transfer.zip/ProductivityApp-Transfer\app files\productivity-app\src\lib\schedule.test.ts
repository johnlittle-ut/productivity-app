import { describe, expect, it } from 'vitest'
import { makeItem } from '../data/defaults'
import { planMoveToTomorrow, searchOccurrences } from './schedule'

describe('move to tomorrow + search', () => {
  it('repeating task moves one occurrence only; plain task just changes date', () => {
    const rep = makeItem({ title: 'Rent', type: 'task', date: '2026-11-01', repeat: { freq: 'weekly' } }, 1)
    const p = planMoveToTomorrow(rep, '2026-11-08', '2026-11-09')
    expect(p.patch).toEqual({ skippedDates: ['2026-11-08'] })
    expect(p.copy).not.toHaveProperty('id')
    expect(p.copy).toMatchObject({ date: '2026-11-09', repeat: null, seriesId: rep.id, originalDate: '2026-11-08' })
    const one = makeItem({ title: 'x', type: 'task', date: '2026-11-04' }, 1)
    expect(planMoveToTomorrow(one, '2026-11-04', '2026-11-05')).toMatchObject({ patch: { date: '2026-11-05' }, undoPatch: { date: '2026-11-04' }, copy: null })
  })

  it('search matches title or notes, one hit per item, skips done', () => {
    const a = makeItem({ title: 'Call Mom', type: 'task', date: '2026-11-10', repeat: { freq: 'weekly' } }, 1)
    const b = makeItem({ title: 'x', type: 'task', date: '2026-11-06', notes: 'bring mom flowers' }, 1)
    const c = makeItem({ title: 'mom done', type: 'task', date: '2026-11-06', done: true }, 1)
    expect(searchOccurrences([a, b, c], '2026-11-04', 'MOM').map((o) => o.item.id)).toEqual([b.id, a.id])
    expect(searchOccurrences([a], '2026-11-04', '  ')).toEqual([])
  })
})
