import { useEffect, useState } from 'react'
import { todayIn } from './dates'

/** Today's date in the given timezone; refreshes every minute and when the app returns to the foreground. */
export function useToday(timezone: string): string {
  const [today, setToday] = useState(() => todayIn(timezone))
  useEffect(() => {
    const update = () => setToday(todayIn(timezone))
    update()
    const id = setInterval(update, 60_000)
    document.addEventListener('visibilitychange', update)
    return () => {
      clearInterval(id)
      document.removeEventListener('visibilitychange', update)
    }
  }, [timezone])
  return today
}
