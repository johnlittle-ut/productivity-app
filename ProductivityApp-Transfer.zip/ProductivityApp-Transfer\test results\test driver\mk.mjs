// node mk.mjs W H slider -> writes steps-W-H.json
import fs from 'fs'
const [W, H, slider = '100'] = process.argv.slice(2)
const measure = `(()=>{const W=innerWidth;const bad=[];document.querySelectorAll('.phone *').forEach(e=>{const r=e.getBoundingClientRect();if(r.width&&(r.right>W+1||r.left<-1))bad.push((e.className&&e.className.baseVal===undefined?e.className:e.tagName)+':'+Math.round(r.left)+'-'+Math.round(r.right))});const tabs=[...document.querySelectorAll('.tab')].map(t=>t.scrollWidth>t.clientWidth+1);const tb=document.querySelector('.tabbar');const mn=document.querySelector('.content');return JSON.stringify({docOv:document.documentElement.scrollWidth>W,tabClip:tabs.filter(Boolean).length,tabbarBottom:Math.round(tb.getBoundingClientRect().bottom),H:innerHeight,contentOv:mn.scrollWidth>mn.clientWidth+1,n:bad.length,bad:[...new Set(bad)].slice(0,5)})})()`
const tab = (name) => ({ eval: `[...document.querySelectorAll('.tab')].find(e=>/${name}/.test(e.textContent)).click()` })
const m = (label) => ({ eval: `'${label} '+` + measure })
const steps = [
  { cdp: ['Emulation.setDeviceMetricsOverride', { width: +W, height: +H, deviceScaleFactor: 1, mobile: true }] },
  { wait: 1500 },
  { eval: `(()=>{document.querySelector('[aria-label=Settings]').click();return 1})()` },
  { wait: 200 },
  { eval: `document.documentElement.style.fontSize='${slider}%'` },
  { wait: 300 },
  m('settings'), { shot: `set-${W}-${H}-${slider}` },
  { eval: `document.querySelector('[aria-label=Back]').click()` },
  tab('Calendar'), { wait: 300 }, m('cal-day'), { shot: `cal-${W}-${H}-${slider}` },
  { eval: `[...document.querySelectorAll('button')].find(e=>/^Week$/.test(e.textContent.trim())).click()` }, { wait: 300 }, m('cal-week'), { shot: `week-${W}-${H}-${slider}` },
  tab('Schedule'), { wait: 300 }, m('schedule'),
  { eval: `document.querySelector('.fab').click()` }, { wait: 300 }, m('sheet'), { shot: `sheet-${W}-${H}-${slider}` },
  { eval: `[...document.querySelectorAll('.sheet button')].find(e=>/Cancel|Close/.test(e.textContent))?.click()||document.querySelector('.sheet-head button')?.click()` },
  tab('To-Do'), { wait: 300 }, m('todo'),
  tab('Shopping'), { wait: 300 }, m('shopping'),
  tab('Interactive'), { wait: 300 }, m('interactive'),
  { eval: `document.querySelector('.group-row').click()` }, { wait: 400 }, m('group'), { shot: `group-${W}-${H}-${slider}` },
  { eval: `document.querySelector('.group-bar .small-btn').click()` }, { wait: 300 }, m('group-form'), { shot: `gform-${W}-${H}-${slider}` },
]
fs.writeFileSync(`steps-${W}-${H}-${slider}.json`, JSON.stringify(steps))
