// Developer tools. Rendered only in dev mode (see Settings.tsx), hidden in production builds.

import { useState } from 'react'
import { dataLayer } from '../data'
import { readOnce, runCleanup } from '../data/actions'
import { groupLayer } from '../groups'
import { buildSampleData } from '../dev/sample'
import { DAY_MS } from '../lib/completion'
import { todayIn } from '../lib/dates'
import type { Settings } from '../types'

export function DevSection({ settings }: { settings: Settings }) {
  const [message, setMessage] = useState('')

  async function loadSample() {
    if (!window.confirm('Add sample data to your current data?')) return
    const data = buildSampleData(todayIn(settings.timezone))
    for (const item of data.items) await dataLayer.items.add(item)
    for (const s of data.shopping) await dataLayer.shopping.add(s.title, '', s.section)
    for (const t of data.todos) {
      const entry = await dataLayer.todos.add(t.title, t.notes)
      if (t.dueDate || t.urgent) await dataLayer.todos.update(entry.id, { dueDate: t.dueDate, urgent: t.urgent })
    }
    setMessage('Sample data loaded.')
  }

  async function clearAll() {
    if (!window.confirm('Delete ALL data (items, lists, settings)? This cannot be undone.')) return
    await dataLayer.clearAll()
    setMessage('All data cleared.')
  }

  return (
    <section className="card">
      <h2>Developer</h2>
      <p className="muted small">Only visible while running `npm run dev`.</p>
      <div className="row">
        <button
          className="btn"
          onClick={async () => {
            const n = await runCleanup(DAY_MS + 1000)
            setMessage(`Cleanup as if 24h later: ${n} change${n === 1 ? '' : 's'}.`)
          }}
        >
          Run cleanup as if 24h later
        </button>
        <button className="btn" onClick={loadSample}>
          Load sample data
        </button>
        <button className="btn danger" onClick={clearAll}>
          Clear all data
        </button>
      </div>
      <h3 className="dev-sub">Interactive (mock groups)</h3>
      <div className="row">
        <button
          className="btn"
          onClick={async () => {
            await groupLayer.seed()
            setMessage('Mock groups re-seeded (Roommates, Friends, one pending invite).')
          }}
        >
          Seed mock groups
        </button>
        <button className="btn" onClick={() => void withFirstGroup((id) => groupLayer.simulateJoin(id))}>
          Member joins
        </button>
        <button className="btn" onClick={() => void withFirstGroup((id) => groupLayer.simulateLeave(id))}>
          Member leaves
        </button>
        <button
          className="btn"
          onClick={async () => setMessage((await groupLayer.simulateIncomingInvite()) ?? 'No group with other members.')}
        >
          Incoming invite
        </button>
        <button
          className="btn"
          onClick={async () => {
            const link = await groupLayer.createJoinableGroupLink()
            setMessage(`Paste this in "Join with link": ${link.url}`)
          }}
        >
          Make a join link
        </button>
      </div>
      {message && <p className="small" role="status">{message}</p>}
    </section>
  )

  async function withFirstGroup(run: (groupId: string) => Promise<string | null>) {
    const groups = await readOnce(groupLayer.groups.subscribe)
    if (groups.length === 0) return setMessage('No groups yet. Seed mock groups first.')
    setMessage((await run(groups[0].id)) ?? 'Nothing to change.')
  }
}
