// IndexedDB implementation of the data layer using Dexie.
// Every row carries a `uid`; all queries are scoped to the current user.

import Dexie, { liveQuery, type EntityTable } from 'dexie'
import { EXPORT_VERSION } from '../types'
import type { ExportFile, Item, ListEntry, Settings } from '../types'
import { isPurgeable, mergeRecords } from '../lib/merge'
import { defaultSettings, makeItem, makeListEntry, nextOrder } from './defaults'
import type { DataLayer, ItemStore, ListStore, MergeSummary, SettingsStore } from './types'

type Owned<T> = T & { uid: string }

class AppDb extends Dexie {
  items!: EntityTable<Owned<Item>, 'id'>
  shoppingItems!: EntityTable<Owned<ListEntry>, 'id'>
  todos!: EntityTable<Owned<ListEntry>, 'id'>
  settings!: EntityTable<Owned<Settings>, 'uid'>

  constructor(name: string) {
    super(name)
    this.version(1).stores({
      items: 'id, uid',
      shoppingItems: 'id, uid',
      todos: 'id, uid',
      settings: 'uid',
    })
  }
}

function strip<T>(row: Owned<T>): T {
  const { uid: _uid, ...rest } = row
  void _uid
  return rest as unknown as T
}

/** Rows older than the updatedAt field read as their creation time. */
function withStamp<T extends { createdAt: number; updatedAt?: number }>(r: T): T & { updatedAt: number } {
  return { ...r, updatedAt: r.updatedAt ?? r.createdAt }
}
type Rec = { id: string; createdAt: number; updatedAt: number }
const alive = <T extends { deletedAt?: number | null }>(rows: T[]) => rows.filter((r) => !r.deletedAt)

export function createDexieDataLayer(uid: string, dbName = 'productivity-app'): DataLayer & { close(): void } {
  const db = new AppDb(dbName)

  const items: ItemStore = {
    subscribe(cb) {
      const sub = liveQuery(() => db.items.where('uid').equals(uid).toArray()).subscribe({
        next: (rows) => cb(alive(rows.map(strip).map(withStamp))),
        error: (e) => console.error('items subscription error', e),
      })
      return () => sub.unsubscribe()
    },
    async add(input) {
      const item = makeItem(input)
      await db.items.add({ ...item, uid })
      return item
    },
    async update(id, patch) {
      await db.items.where('id').equals(id).and((r) => r.uid === uid).modify({ ...patch, updatedAt: Date.now() })
    },
    async remove(id) {
      const now = Date.now() // soft delete: hidden everywhere, purged after 30 days
      await db.items.where('id').equals(id).and((r) => r.uid === uid).modify({ deletedAt: now, updatedAt: now })
    },
  }

  function listStore(table: EntityTable<Owned<ListEntry>, 'id'>): ListStore {
    return {
      subscribe(cb) {
        const sub = liveQuery(() => table.where('uid').equals(uid).toArray()).subscribe({
          next: (rows) => cb(alive(rows.map(strip).map(withStamp)).sort((a, b) => a.order - b.order)),
          error: (e) => console.error('list subscription error', e),
        })
        return () => sub.unsubscribe()
      },
      async add(title, notes = '', section) {
        const existing = alive((await table.where('uid').equals(uid).toArray()).map(strip).map(withStamp))
        const entry = { ...makeListEntry(title, notes, nextOrder(existing)), ...(section ? { section } : {}) }
        await table.add({ ...entry, uid })
        return entry
      },
      async update(id, patch) {
        await table.where('id').equals(id).and((r) => r.uid === uid).modify({ ...patch, updatedAt: Date.now() })
      },
      async remove(id) {
        const now = Date.now()
        await table.where('id').equals(id).and((r) => r.uid === uid).modify({ deletedAt: now, updatedAt: now })
      },
    }
  }

  async function readSettings(): Promise<Settings> {
    const row = await db.settings.get(uid)
    if (row) return { ...defaultSettings(), ...strip(row) }
    const fresh = { ...defaultSettings(), updatedAt: Date.now() }
    await db.settings.put({ ...fresh, uid })
    return fresh
  }

  const settings: SettingsStore = {
    get: readSettings,
    subscribe(cb) {
      const sub = liveQuery(async () => {
        const row = await db.settings.get(uid)
        return row ? { ...defaultSettings(), ...strip(row) } : defaultSettings()
      }).subscribe({
        next: cb,
        error: (e) => console.error('settings subscription error', e),
      })
      // make sure a row exists for this user
      void readSettings()
      return () => sub.unsubscribe()
    },
    async update(patch) {
      await readSettings() // make sure the row exists
      await db.settings.update(uid, { ...patch, updatedAt: Date.now() })
    },
  }

  return {
    items,
    shopping: listStore(db.shoppingItems),
    todos: listStore(db.todos),
    settings,

    async exportAll() {
      const [i, s, t, st] = await Promise.all([
        db.items.where('uid').equals(uid).toArray(),
        db.shoppingItems.where('uid').equals(uid).toArray(),
        db.todos.where('uid').equals(uid).toArray(),
        readSettings(),
      ])
      return {
        version: EXPORT_VERSION,
        exportedAt: Date.now(),
        items: i.map(strip).map(withStamp),
        shoppingItems: s.map(strip).map(withStamp),
        todos: t.map(strip).map(withStamp),
        settings: st,
      } satisfies ExportFile
    },

    async importAll(file) {
      await db.transaction('rw', [db.items, db.shoppingItems, db.todos, db.settings], async () => {
        await db.items.where('uid').equals(uid).delete()
        await db.shoppingItems.where('uid').equals(uid).delete()
        await db.todos.where('uid').equals(uid).delete()
        await db.items.bulkAdd(file.items.map((r) => ({ ...r, uid })))
        await db.shoppingItems.bulkAdd(file.shoppingItems.map((r) => ({ ...r, uid })))
        await db.todos.bulkAdd(file.todos.map((r) => ({ ...r, uid })))
        await db.settings.put({ ...defaultSettings(), ...file.settings, uid })
      })
    },

    async importMerge(file) {
      const summary = {} as MergeSummary
      await db.transaction('rw', [db.items, db.shoppingItems, db.todos, db.settings], async () => {
        for (const [key, table] of [
          ['items', db.items],
          ['shoppingItems', db.shoppingItems],
          ['todos', db.todos],
        ] as const) {
          const have = (await (table as EntityTable<Owned<{ id: string; createdAt: number; updatedAt: number }>, 'id'>).where('uid').equals(uid).toArray()).map(strip).map(withStamp)
          const { merged, added, updated, skipped } = mergeRecords(have as Rec[], file[key].map(withStamp) as Rec[])
          summary[key] = { added, updated, skipped }
          const changed = merged.filter((r) => have.find((h) => h.id === r.id) !== r)
          await (table as EntityTable<Owned<{ id: string }>, 'id'>).bulkPut(changed.map((r) => ({ ...r, uid })))
        }
        const mine = await readSettings()
        const incoming = file.settings.updatedAt ?? 0
        if (incoming > (mine.updatedAt ?? 0)) {
          await db.settings.put({ ...defaultSettings(), ...file.settings, uid })
          summary.settings = 'updated'
        } else summary.settings = 'skipped'
      })
      return summary
    },

    async purgeDeleted(now = Date.now()) {
      let purged = 0
      for (const table of [db.items, db.shoppingItems, db.todos] as unknown as EntityTable<Owned<{ id: string; createdAt: number; updatedAt?: number; deletedAt?: number | null }>, 'id'>[]) {
        const rows = await table.where('uid').equals(uid).toArray()
        for (const r of rows) {
          if (isPurgeable(r, now)) {
            await table.delete(r.id)
            purged++
          } else if (r.updatedAt === undefined) await table.update(r.id, { updatedAt: r.createdAt ?? now })
        }
      }
      const s = await db.settings.get(uid)
      if (s && s.updatedAt === undefined) await db.settings.update(uid, { updatedAt: now })
      return purged
    },

    async clearAll() {
      await db.transaction('rw', [db.items, db.shoppingItems, db.todos, db.settings], async () => {
        await db.items.where('uid').equals(uid).delete()
        await db.shoppingItems.where('uid').equals(uid).delete()
        await db.todos.where('uid').equals(uid).delete()
        await db.settings.where('uid').equals(uid).delete()
      })
    },

    close() {
      db.close()
    },
  }
}
