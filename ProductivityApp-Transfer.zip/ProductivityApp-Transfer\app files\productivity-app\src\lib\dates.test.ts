import { describe, expect, it } from 'vitest'
import { addDays, clampedDay, dayOfWeek, daysInMonth, todayIn } from './dates'

describe('todayIn (timezone day logic)', () => {
  const NY = 'America/New_York'

  it('uses the local day, not the UTC day', () => {
    // 03:30Z on Mar 9 is 23:30 EDT on Mar 8 (DST already started Mar 8, 2026)
    expect(todayIn(NY, new Date('2026-03-09T03:30:00Z'))).toBe('2026-03-08')
    expect(todayIn(NY, new Date('2026-03-09T04:30:00Z'))).toBe('2026-03-09')
  })

  it('handles the standard-time side of the spring DST boundary', () => {
    // 04:30Z on Mar 8 is 23:30 EST on Mar 7
    expect(todayIn(NY, new Date('2026-03-08T04:30:00Z'))).toBe('2026-03-07')
  })

  it('handles the fall DST boundary (Nov 1, 2026)', () => {
    expect(todayIn(NY, new Date('2026-11-02T04:30:00Z'))).toBe('2026-11-01') // 23:30 EST
    expect(todayIn(NY, new Date('2026-11-02T05:30:00Z'))).toBe('2026-11-02') // 00:30 EST
  })
})

describe('date arithmetic', () => {
  it('adds days across month, year and leap boundaries', () => {
    expect(addDays('2026-01-31', 1)).toBe('2026-02-01')
    expect(addDays('2026-12-31', 1)).toBe('2027-01-01')
    expect(addDays('2028-02-28', 1)).toBe('2028-02-29')
    expect(addDays('2026-03-01', -1)).toBe('2026-02-28')
  })

  it('is not shifted by DST (spring and fall)', () => {
    expect(addDays('2026-03-07', 1)).toBe('2026-03-08')
    expect(addDays('2026-03-08', 1)).toBe('2026-03-09')
    expect(addDays('2026-10-31', 1)).toBe('2026-11-01')
    expect(addDays('2026-11-01', 1)).toBe('2026-11-02')
  })

  it('computes day of week', () => {
    expect(dayOfWeek('2026-11-02')).toBe(1) // Monday
    expect(dayOfWeek('2026-11-01')).toBe(0) // Sunday
  })

  it('knows month lengths and clamps month-end', () => {
    expect(daysInMonth(2026, 2)).toBe(28)
    expect(daysInMonth(2028, 2)).toBe(29)
    expect(clampedDay(2026, 4, 31)).toBe('2026-04-30')
    expect(clampedDay(2026, 2, 31)).toBe('2026-02-28')
    expect(clampedDay(2026, 5, 31)).toBe('2026-05-31')
  })
})
