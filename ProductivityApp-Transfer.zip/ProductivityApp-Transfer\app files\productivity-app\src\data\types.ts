// The data-layer interface. Screens depend ONLY on this, never on storage.
// The Dexie (IndexedDB) implementation lives in dexieDataLayer.ts.
// A Firestore implementation will implement the same interface later.

import type { MergeCounts } from '../lib/merge'
import type { ExportFile, Item, ListEntry, ListSection, NewItem, Settings } from '../types'

export type Unsubscribe = () => void

/** Called immediately with current data, then again on every change. */
export type Listener<T> = (value: T) => void

export interface ItemStore {
  subscribe(cb: Listener<Item[]>): Unsubscribe
  add(input: NewItem): Promise<Item>
  update(id: string, patch: Partial<Omit<Item, 'id'>>): Promise<void>
  remove(id: string): Promise<void>
}

/** Shared by the shopping list and the general to-do list. */
export interface ListStore {
  subscribe(cb: Listener<ListEntry[]>): Unsubscribe
  /** New entries go at the bottom (highest order). */
  add(title: string, notes?: string, section?: ListSection): Promise<ListEntry>
  update(id: string, patch: Partial<Omit<ListEntry, 'id'>>): Promise<void>
  remove(id: string): Promise<void>
}

export interface SettingsStore {
  get(): Promise<Settings>
  subscribe(cb: Listener<Settings>): Unsubscribe
  update(patch: Partial<Settings>): Promise<void>
}

export type MergeSummary = Record<'items' | 'shoppingItems' | 'todos', MergeCounts> & { settings: 'added' | 'updated' | 'skipped' }

export interface DataLayer {
  items: ItemStore
  shopping: ListStore
  todos: ListStore
  settings: SettingsStore
  /** Everything for the current user, as one versioned file. */
  exportAll(): Promise<ExportFile>
  /** Merges a backup into the current data by id (newest `updatedAt` wins, never overwrites newer with older). */
  importMerge(file: ExportFile): Promise<MergeSummary>
  /** Fills in missing `updatedAt`, then removes records soft-deleted more than 30 days ago. Returns how many were purged. */
  purgeDeleted(now?: number): Promise<number>
  /** Replaces all of the current user's data with the file's contents. */
  importAll(file: ExportFile): Promise<void>
  /** Deletes all of the current user's data (settings reset to defaults). */
  clearAll(): Promise<void>
}
