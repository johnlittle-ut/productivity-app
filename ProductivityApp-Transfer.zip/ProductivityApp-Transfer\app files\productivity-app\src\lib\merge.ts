// Merging records from another copy (a backup file now, the cloud later): newest `updatedAt` wins.

export interface Mergeable {
  id: string
  updatedAt: number
}

export interface MergeCounts {
  added: number
  updated: number
  /** Incoming records that were older than (or the same age as) what is already here. */
  skipped: number
}

export const PURGE_AFTER_MS = 30 * 24 * 60 * 60 * 1000

/**
 * Merge `incoming` into `existing` by id. The record with the newest `updatedAt` wins;
 * on a tie the existing record is kept. Deleted records (tombstones) merge like any other.
 */
export function mergeRecords<T extends Mergeable>(existing: T[], incoming: T[]): { merged: T[] } & MergeCounts {
  const byId = new Map(existing.map((r) => [r.id, r]))
  const counts: MergeCounts = { added: 0, updated: 0, skipped: 0 }
  for (const rec of incoming) {
    const have = byId.get(rec.id)
    if (!have) {
      byId.set(rec.id, rec)
      counts.added++
    } else if (rec.updatedAt > have.updatedAt) {
      byId.set(rec.id, rec)
      counts.updated++
    } else counts.skipped++
  }
  return { merged: [...byId.values()], ...counts }
}

/** Soft-deleted more than 30 days ago: safe to remove for good. */
export function isPurgeable(rec: { deletedAt?: number | null }, now: number): boolean {
  return !!rec.deletedAt && now - rec.deletedAt > PURGE_AFTER_MS
}
