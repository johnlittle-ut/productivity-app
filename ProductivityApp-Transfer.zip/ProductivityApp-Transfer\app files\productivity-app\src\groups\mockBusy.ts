// Realistic fake weekly patterns for the mock friends, so the availability grid has something to show.

import type { BusyInterval } from './model'
import { addDays, dayOfWeek } from '../lib/dates'
import { zonedToInstant } from '../lib/tz'

type Pattern = { days: number[]; start: string; end: string }

const h = (hhmm: string) => {
  const [hh, mm] = hhmm.split(':').map(Number)
  return hh * 60 + mm
}

const WEEKDAYS = [1, 2, 3, 4, 5]

const PATTERNS: Record<string, Pattern[]> = {
  alex: [
    { days: WEEKDAYS, start: '09:00', end: '17:00' }, // work
    { days: [3], start: '19:00', end: '20:30' },
  ],
  sam: [
    { days: [2, 4], start: '10:00', end: '12:00' }, // class
    { days: [1, 3, 5], start: '18:00', end: '19:00' }, // gym
    { days: [6], start: '14:00', end: '16:00' },
  ],
  jordan: [
    { days: WEEKDAYS, start: '08:00', end: '16:00' },
    { days: [2], start: '18:30', end: '20:00' },
  ],
  riley: [
    { days: [1, 2, 3, 4], start: '12:00', end: '15:00' },
    { days: [5], start: '17:00', end: '22:00' },
  ],
}

/** Friends' patterns are wall-clock in `tz` (the device zone); output is absolute instants. */
export function mockBusy(memberId: string, today: string, tz: string, days = 60): BusyInterval[] {
  const patterns = PATTERNS[memberId] ?? []
  const out: BusyInterval[] = []
  for (let i = 0; i < days; i++) {
    const date = addDays(today, i)
    const dow = dayOfWeek(date)
    for (const p of patterns) {
      if (p.days.includes(dow)) {
        const s = zonedToInstant(date, p.start, tz)
        out.push({ userId: memberId, start: s, end: s + (h(p.end) - h(p.start)) * 60_000 })
      }
    }
  }
  return out
}
