// Data model. See Plan.md section 3. Dates are plain 'YYYY-MM-DD', times are 'HH:mm'.

export type ItemType = 'event' | 'task'

export interface Repeat {
  freq: 'weekly' | 'monthly'
  until?: string // 'YYYY-MM-DD', inclusive
}

export interface Reminder {
  enabled: boolean
  minutesBefore: number
}

export interface Item {
  id: string
  title: string
  type: ItemType
  date: string // first occurrence for repeating items
  startTime: string | null
  endTime: string | null
  notes: string
  done: boolean // non-repeating items only
  doneAt: number | null // epoch ms
  repeat: Repeat | null
  completedOccurrences: Record<string, number> // 'YYYY-MM-DD' -> doneAt epoch ms (repeating only)
  skippedDates: string[] // repeating only
  reminder: Reminder // saved but unused until Phase 2
  groupId?: string // set on a personal copy of an accepted group event
  groupEventId?: string
  tz?: string // IANA zone the wall-clock date/startTime/endTime are in (timed items only; all-day items float)
  hideFromGroups?: boolean // events: keep out of every group's availability view (missing = false)
  showOnCalendar?: boolean // tasks only: also show on the Calendar grid (missing = false)
  seriesId?: string // set on an item created by "edit this occurrence only": the parent's id
  originalDate?: string // ...and the date it replaced
  createdAt: number
  updatedAt: number // last edit time; set only by the data layer
  deletedAt?: number | null // soft delete: hidden everywhere, purged after 30 days
}

/** What a caller supplies to create an item; everything else gets defaults. */
export type NewItem = Pick<Item, 'title' | 'type' | 'date'> &
  Partial<Omit<Item, 'id' | 'title' | 'type' | 'date' | 'createdAt' | 'updatedAt' | 'deletedAt'>>

export type ListSection = 'groceries' | 'general'

/** Shopping list entry or general to-do. Only shopping entries use `section` (missing = groceries). */
export interface ListEntry {
  id: string
  title: string
  notes: string
  done: boolean
  doneAt: number | null
  createdAt: number
  updatedAt: number // last edit time; set only by the data layer
  deletedAt?: number | null
  order: number
  section?: ListSection
  dueDate?: string // To-Do only: optional due date (YYYY-MM-DD)
  urgent?: boolean // To-Do only: user-flagged urgent
}

export interface Settings {
  updatedAt?: number // last edit time; set only by the data layer
  timezone: string // the EFFECTIVE zone (override ?? device), saved for later server use
  timezoneOverride?: string | null // null/missing = automatic (device)
  timeFormat?: '12' | '24' // missing = 12
  defaultEventReminderMinutes: number
  digestEnabled: boolean
  digestTime: string
  weekStartsOn: 'monday'
  theme?: 'system' | 'light' | 'dark' // missing = system
  textSize?: number // percent of normal, 85-130 (missing = 100)
  defaultTab?: 'calendar' | 'schedule' | 'todo' | 'shopping' | 'interactive' // missing = schedule
}

export const EXPORT_VERSION = 1

export interface ExportFile {
  version: number
  exportedAt: number
  items: Item[]
  shoppingItems: ListEntry[]
  todos: ListEntry[]
  settings: Settings
}
