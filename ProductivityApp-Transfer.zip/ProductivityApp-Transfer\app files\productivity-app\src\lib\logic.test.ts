import { describe, expect, it } from 'vitest'
import { cleanupPlan, completeOccurrence, DAY_MS, recentlyCompleted, undoOccurrence } from './completion'
import { diffDays, occurrenceDates, occursOn } from './recurrence'
import { occurrencesByDate, overdueOccurrences } from './schedule'
import { formatTime, formatTimeShort, itemText } from './format'
import { makeItem } from '../data/defaults'
import type { Item, NewItem } from '../types'

const mk = (input: NewItem, createdAt = 1): Item => makeItem(input, createdAt)

describe('recurrence', () => {
  it('weekly lands on the same weekday', () => {
    const it_ = mk({ title: 'Thrive', type: 'event', date: '2026-11-06', repeat: { freq: 'weekly' } })
    expect(occurrenceDates(it_, '2026-11-01', '2026-11-30')).toEqual(['2026-11-06', '2026-11-13', '2026-11-20', '2026-11-27'])
    expect(occursOn(it_, '2026-10-30')).toBe(false) // before anchor
  })

  it('weekly is stable across the DST change', () => {
    const it_ = mk({ title: 'x', type: 'event', date: '2026-10-30', repeat: { freq: 'weekly' } })
    expect(occurrenceDates(it_, '2026-10-30', '2026-11-13')).toEqual(['2026-10-30', '2026-11-06', '2026-11-13'])
  })

  it('monthly keeps the day of month and clamps to month end', () => {
    const it_ = mk({ title: 'Storage', type: 'task', date: '2026-01-31', repeat: { freq: 'monthly' } })
    expect(occurrenceDates(it_, '2026-01-01', '2026-06-30')).toEqual([
      '2026-01-31',
      '2026-02-28',
      '2026-03-31',
      '2026-04-30',
      '2026-05-31',
      '2026-06-30',
    ])
  })

  it('monthly on the 29th/30th in February', () => {
    const t29 = mk({ title: 'a', type: 'task', date: '2026-01-29', repeat: { freq: 'monthly' } })
    expect(occursOn(t29, '2026-02-28')).toBe(true) // non-leap
    expect(occursOn(t29, '2027-02-28')).toBe(true)
    expect(occursOn(t29, '2028-02-29')).toBe(true) // leap
    expect(occursOn(t29, '2028-02-28')).toBe(false)
    const t30 = mk({ title: 'b', type: 'task', date: '2026-01-30', repeat: { freq: 'monthly' } })
    expect(occursOn(t30, '2026-02-28')).toBe(true)
  })

  it('respects skippedDates and until', () => {
    const it_ = mk({
      title: 'x',
      type: 'event',
      date: '2026-11-04',
      repeat: { freq: 'weekly', until: '2026-11-18' },
      skippedDates: ['2026-11-11'],
    })
    expect(occurrenceDates(it_, '2026-11-01', '2026-12-31')).toEqual(['2026-11-04', '2026-11-18'])
  })

  it('non-repeating items occur once', () => {
    const it_ = mk({ title: 'x', type: 'event', date: '2026-11-04' })
    expect(occurrenceDates(it_, '2026-11-01', '2026-11-30')).toEqual(['2026-11-04'])
    expect(occurrenceDates(it_, '2026-11-05', '2026-11-30')).toEqual([])
  })

  it('diffDays', () => {
    expect(diffDays('2026-11-04', '2026-11-11')).toBe(7)
    expect(diffDays('2026-03-07', '2026-03-09')).toBe(2) // across DST
    expect(diffDays('2026-11-04', '2026-11-01')).toBe(-3)
  })
})

describe('check-off and undo', () => {
  it('non-repeating: done flag and doneAt', () => {
    const item = mk({ title: 'x', type: 'task', date: '2026-11-04' })
    expect(completeOccurrence(item, '2026-11-04', 500)).toEqual({ done: true, doneAt: 500 })
    expect(undoOccurrence(item, '2026-11-04')).toEqual({ done: false, doneAt: null })
  })

  it('repeating: only that occurrence is completed', () => {
    const item = mk({ title: 'x', type: 'task', date: '2026-11-04', repeat: { freq: 'weekly' } })
    const patch = completeOccurrence(item, '2026-11-11', 500)
    const done = { ...item, ...patch }
    expect(done.completedOccurrences).toEqual({ '2026-11-11': 500 })
    const days = occurrencesByDate([done], '2026-11-04', '2026-11-25')
    expect([...days.keys()]).toEqual(['2026-11-04', '2026-11-18', '2026-11-25']) // 11-11 hidden
    const undone = { ...done, ...undoOccurrence(done, '2026-11-11') }
    expect([...occurrencesByDate([undone], '2026-11-04', '2026-11-25').keys()]).toContain('2026-11-11')
  })
})

describe('24-hour cleanup', () => {
  const now = 10 * DAY_MS

  it('deletes non-repeating items checked off 24h ago, keeps newer', () => {
    const old = { ...mk({ title: 'old', type: 'task', date: '2026-11-01' }), done: true, doneAt: now - DAY_MS }
    const fresh = { ...mk({ title: 'fresh', type: 'task', date: '2026-11-01' }), done: true, doneAt: now - DAY_MS + 1000 }
    const open = mk({ title: 'open', type: 'task', date: '2026-11-01' })
    const plan = cleanupPlan([old, fresh, open], now)
    expect(plan.deleteIds).toEqual([old.id])
    expect(plan.updates).toEqual([])
  })

  it('repeating: expired occurrence is dropped for good (skipped), not shown again', () => {
    const base = mk({ title: 'rent', type: 'task', date: '2026-11-01', repeat: { freq: 'monthly' } })
    const item: Item = { ...base, completedOccurrences: { '2026-11-01': now - DAY_MS - 5, '2026-12-01': now - 1000 } }
    const plan = cleanupPlan([item], now)
    expect(plan.deleteIds).toEqual([])
    expect(plan.updates).toHaveLength(1)
    const after = { ...item, ...plan.updates[0].patch }
    expect(after.completedOccurrences).toEqual({ '2026-12-01': now - 1000 })
    expect(after.skippedDates).toEqual(['2026-11-01'])
    expect(occursOn(after, '2026-11-01')).toBe(false)
  })

  it('recentlyCompleted lists only the last 24h, newest first', () => {
    const a = { ...mk({ title: 'a', type: 'task', date: '2026-11-01' }), done: true, doneAt: now - 1000 }
    const b = { ...mk({ title: 'b', type: 'task', date: '2026-11-01' }), done: true, doneAt: now - 5000 }
    const c = { ...mk({ title: 'c', type: 'task', date: '2026-11-01' }), done: true, doneAt: now - DAY_MS - 1 }
    expect(recentlyCompleted([b, c, a], now).map((r) => r.item.title)).toEqual(['a', 'b'])
  })
})

describe('schedule grouping', () => {
  it('sorts timed items by time, then untimed by creation', () => {
    const items = [
      mk({ title: 'untimed late', type: 'task', date: '2026-11-04' }, 20),
      mk({ title: 'evening', type: 'event', date: '2026-11-04', startTime: '19:00' }, 5),
      mk({ title: 'untimed early', type: 'task', date: '2026-11-04' }, 10),
      mk({ title: 'morning', type: 'event', date: '2026-11-04', startTime: '08:30' }, 6),
    ]
    const day = occurrencesByDate(items, '2026-11-04', '2026-11-04').get('2026-11-04')!
    expect(day.map((o) => o.item.title)).toEqual(['morning', 'evening', 'untimed early', 'untimed late'])
  })

  it('overdue: unfinished past tasks only (no events, no done, no future)', () => {
    const items = [
      mk({ title: 'late task', type: 'task', date: '2026-11-01' }),
      mk({ title: 'past event', type: 'event', date: '2026-11-01' }),
      { ...mk({ title: 'done task', type: 'task', date: '2026-11-01' }), done: true, doneAt: 1 },
      mk({ title: 'today task', type: 'task', date: '2026-11-04' }),
    ]
    expect(overdueOccurrences(items, '2026-11-04').map((o) => o.item.title)).toEqual(['late task'])
  })

  it('overdue: a repeating task shows only its most recent missed occurrence', () => {
    const base = mk({ title: 'weekly', type: 'task', date: '2026-08-01', repeat: { freq: 'weekly' } })
    const missedLatest = overdueOccurrences([base], '2026-11-04').map((o) => o.date)
    expect(missedLatest).toEqual(['2026-10-31'])
    // completing the latest miss clears it; older misses do not resurface
    const done: Item = { ...base, completedOccurrences: { '2026-10-31': 1 } }
    expect(overdueOccurrences([done], '2026-11-04')).toEqual([])
    // ...and it stays cleared after 24h cleanup turns the completion into a skipped date
    const cleaned: Item = { ...base, skippedDates: ['2026-10-31'] }
    expect(overdueOccurrences([cleaned], '2026-11-04')).toEqual([])
  })

  it('overdue: a missed monthly bill does not pile up', () => {
    const rent = mk({ title: 'Rent', type: 'task', date: '2026-01-01', repeat: { freq: 'monthly' } })
    expect(overdueOccurrences([rent], '2026-11-04').map((o) => o.date)).toEqual(['2026-11-01'])
  })
})

describe('format', () => {
  it('formats times and item text', () => {
    expect(formatTime('18:30')).toBe('6:30 PM')
    expect(formatTime('00:05')).toBe('12:05 AM')
    expect(formatTime('12:00')).toBe('12:00 PM')
    expect(formatTime('23:59')).toBe('11:59 PM')
    expect(formatTimeShort('18:30')).toBe('6:30pm')
    expect(formatTimeShort('23:59')).toBe('11:59pm')
    expect(itemText('Thrive', '18:30')).toBe('6:30pm - Thrive')
    expect(itemText('Rent due', null)).toBe('Rent due')
  })
})

import { weekStart } from './dates'
import { longDate, weekRangeLabel } from './format'
import { swipeDirection } from './swipe'

describe('calendar helpers', () => {
  it('weeks start on Monday', () => {
    expect(weekStart('2026-11-04')).toBe('2026-11-02') // Wed -> Mon
    expect(weekStart('2026-11-02')).toBe('2026-11-02') // Mon -> itself
    expect(weekStart('2026-11-08')).toBe('2026-11-02') // Sun -> previous Mon
    expect(weekStart('2026-11-09')).toBe('2026-11-09')
  })

  it('labels week ranges', () => {
    expect(weekRangeLabel('2026-11-02', '2026-11-08')).toBe('Nov 2 – 8')
    expect(weekRangeLabel('2026-10-26', '2026-11-01')).toBe('Oct 26 – Nov 1')
    expect(weekRangeLabel('2026-12-28', '2027-01-03')).toBe('Dec 28, 2026 – Jan 3, 2027')
    expect(longDate('2026-11-04')).toBe('Wednesday, Nov 4')
  })

  it('detects horizontal swipes only', () => {
    expect(swipeDirection(-100, 5)).toBe(-1)
    expect(swipeDirection(100, -10)).toBe(1)
    expect(swipeDirection(30, 0)).toBe(0) // too short
    expect(swipeDirection(80, 90)).toBe(0) // mostly vertical (scrolling)
  })
})

import { expiredEntryIds, needsRebalance, orderForMove, rebalanced, recentEntries } from './order'
import type { ListEntry } from '../types'

const entry = (title: string, order: number, extra: Partial<ListEntry> = {}): ListEntry => ({
  id: title,
  updatedAt: 0,
  title,
  notes: '',
  done: false,
  doneAt: null,
  createdAt: 1,
  order,
  ...extra,
})

describe('list ordering (drag to reorder)', () => {
  const list = [entry('A', 1000), entry('B', 2000), entry('C', 3000), entry('D', 4000)]

  it('moving between neighbours uses the midpoint', () => {
    expect(orderForMove(list, 3, 1)).toBe(1500) // D between A and B
    expect(orderForMove(list, 0, 2)).toBe(3500) // A between C and D
  })

  it('moving to either end goes one gap past the edge', () => {
    expect(orderForMove(list, 3, 0)).toBe(0) // D to top
    expect(orderForMove(list, 0, 3)).toBe(5000) // A to bottom
  })

  it('a one-entry list stays valid', () => {
    expect(orderForMove([entry('A', 5)], 0, 0)).toBe(1000)
  })

  it('detects squeezed neighbours and rebalances in sequence', () => {
    const squeezed = [entry('A', 1000), entry('B', 1000.0000001), entry('C', 2000)]
    expect(needsRebalance(squeezed)).toBe(true)
    expect(needsRebalance(list)).toBe(false)
    expect(rebalanced(squeezed)).toEqual([
      { id: 'A', order: 1000 },
      { id: 'B', order: 2000 },
      { id: 'C', order: 3000 },
    ])
  })

  it('repeated drops never collide in practice', () => {
    let l = [entry('A', 1000), entry('B', 2000)]
    for (let i = 0; i < 30; i++) {
      const mid = (l[0].order + l[1].order) / 2
      l = [l[0], entry(`N${i}`, mid), l[1]].sort((a, b) => a.order - b.order)
    }
    expect(new Set(l.map((e) => e.order)).size).toBe(l.length)
  })
})

describe('list cleanup', () => {
  const now = 10 * DAY_MS
  it('expires entries checked off 24h ago, keeps newer and unchecked', () => {
    const entries = [
      entry('old', 1, { done: true, doneAt: now - DAY_MS }),
      entry('fresh', 2, { done: true, doneAt: now - 1000 }),
      entry('open', 3),
    ]
    expect(expiredEntryIds(entries, now, DAY_MS)).toEqual(['old'])
    expect(recentEntries(entries, now, DAY_MS).map((e) => e.title)).toEqual(['fresh'])
  })
})

import { blockTimes, layoutBlocks } from './gridLayout'
import { minutesNowIn } from './dates'
import { calendarOccurrencesByDate, showsOnCalendar } from './schedule'

describe('calendar grid', () => {
  it('block times: event default 1h, explicit end, task 30m, clamped to the day, untimed = null', () => {
    expect(blockTimes({ type: 'event', startTime: '18:30', endTime: null })).toEqual({ start: 1110, end: 1170 })
    expect(blockTimes({ type: 'event', startTime: '18:30', endTime: '20:00' })).toEqual({ start: 1110, end: 1200 })
    expect(blockTimes({ type: 'event', startTime: '18:30', endTime: '17:00' })).toEqual({ start: 1110, end: 1170 }) // bad end ignored
    expect(blockTimes({ type: 'task', startTime: '23:59', endTime: null })).toEqual({ start: 1439, end: 1440 })
    expect(blockTimes({ type: 'event', startTime: '23:30', endTime: null })).toEqual({ start: 1410, end: 1440 })
    expect(blockTimes({ type: 'event', startTime: null, endTime: null })).toBeNull()
  })

  it('lays out non-overlapping blocks full width', () => {
    const out = layoutBlocks([
      { key: 'a', start: 540, end: 600 },
      { key: 'b', start: 600, end: 660 }, // touching, not overlapping
    ])
    expect(out.map((b) => [b.key, b.col, b.cols])).toEqual([['a', 0, 1], ['b', 0, 1]])
  })

  it('puts overlapping blocks side by side', () => {
    const out = layoutBlocks([
      { key: 'a', start: 540, end: 600 },
      { key: 'b', start: 570, end: 630 },
    ])
    expect(out.map((b) => [b.key, b.col, b.cols])).toEqual([['a', 0, 2], ['b', 1, 2]])
  })

  it('reuses a freed column inside one overlap cluster, and separates clusters', () => {
    const out = layoutBlocks([
      { key: 'a', start: 540, end: 600 },
      { key: 'b', start: 570, end: 630 },
      { key: 'c', start: 600, end: 660 }, // starts as a ends -> reuses column 0
      { key: 'd', start: 900, end: 960 }, // separate cluster, full width
    ])
    const m = Object.fromEntries(out.map((b) => [b.key, [b.col, b.cols]]))
    expect(m).toEqual({ a: [0, 2], b: [1, 2], c: [0, 2], d: [0, 1] })
  })

  it('three-way overlap uses three columns', () => {
    const out = layoutBlocks([
      { key: 'a', start: 600, end: 720 },
      { key: 'b', start: 610, end: 700 },
      { key: 'c', start: 620, end: 690 },
    ])
    expect(out.every((b) => b.cols === 3)).toBe(true)
    expect(new Set(out.map((b) => b.col)).size).toBe(3)
  })

  it('minutesNowIn uses the timezone (DST aware)', () => {
    expect(minutesNowIn('America/New_York', new Date('2026-03-09T03:30:00Z'))).toBe(23 * 60 + 30) // EDT
    expect(minutesNowIn('America/New_York', new Date('2026-03-08T04:30:00Z'))).toBe(23 * 60 + 30) // EST
    expect(minutesNowIn('America/New_York', new Date('2026-11-04T05:05:00Z'))).toBe(5) // 00:05 EST
  })

  it('calendar shows events, and tasks only when flagged', () => {
    const ev = mk({ title: 'Event', type: 'event', date: '2026-11-04' })
    const task = mk({ title: 'Task', type: 'task', date: '2026-11-04' })
    const flagged = mk({ title: 'Flagged', type: 'task', date: '2026-11-04', showOnCalendar: true })
    expect(showsOnCalendar(ev)).toBe(true)
    expect(showsOnCalendar(task)).toBe(false)
    expect(showsOnCalendar(flagged)).toBe(true)
    const day = calendarOccurrencesByDate([ev, task, flagged], '2026-11-04', '2026-11-04').get('2026-11-04')!
    expect(day.map((o) => o.item.title).sort()).toEqual(['Event', 'Flagged'])
  })
})
