import { useState } from 'react'
import type { FormValues, Scope } from '../data/actions'
import { minutesNowIn } from '../lib/dates'
import { toMinutes } from '../lib/gridLayout'
import type { ItemType } from '../types'
import { ChoiceDialog, Sheet } from './Dialogs'

type RepeatChoice = 'none' | 'weekly' | 'monthly'

interface Props {
  mode: 'add' | 'edit'
  initial: FormValues
  /** Effective timezone (for the "next full hour" default). */
  tz: string
  /** True when editing an item that repeats (asks "this occurrence or all"). */
  repeating: boolean
  onSave: (values: FormValues, scope?: Scope) => void
  onDelete?: (scope?: Scope) => void
  onClose: () => void
}

const hhmm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
/** Event default: starts at the next full hour (capped at 11 PM), lasts one hour. */
function nextHourSlot(tz: string): { start: string; end: string } {
  const s = Math.min((Math.floor(minutesNowIn(tz) / 60) + 1) * 60, 23 * 60)
  return { start: hhmm(s), end: hhmm(Math.min(s + 60, 23 * 60 + 59)) }
}

export function ItemForm({ mode, initial, tz, repeating, onSave, onDelete, onClose }: Props) {
  const [title, setTitle] = useState(initial.title)
  const [type, setType] = useState<ItemType>(initial.type)
  const [date, setDate] = useState(initial.date)
  const [slot] = useState(() => nextHourSlot(tz))
  const newEvent = mode === 'add' && initial.type === 'event' && initial.startTime === null
  const [hasTime, setHasTime] = useState(initial.startTime !== null || newEvent)
  const [startTime, setStartTime] = useState(initial.startTime ?? slot.start)
  const [endTime, setEndTime] = useState(initial.endTime ?? (newEvent ? slot.end : ''))

  function changeStart(v: string) {
    // keep the event's length when the start moves
    if (v && startTime && endTime) {
      const end = toMinutes(endTime) + (toMinutes(v) - toMinutes(startTime))
      setEndTime(end > 0 && end < 24 * 60 ? hhmm(end) : endTime)
    }
    setStartTime(v)
  }

  function pickType(t: ItemType) {
    setType(t)
    if (t === 'event' && mode === 'add' && !hasTime) {
      setHasTime(true)
      setStartTime(slot.start)
      setEndTime(slot.end)
    }
  }
  const [repeat, setRepeat] = useState<RepeatChoice>(initial.repeat?.freq ?? 'none')
  const [notes, setNotes] = useState(initial.notes)
  const [showOnCalendar, setShowOnCalendar] = useState(initial.showOnCalendar)
  const [asking, setAsking] = useState<'save' | 'delete' | null>(null)
  const [error, setError] = useState('')

  function buildValues(): FormValues | null {
    if (!title.trim()) {
      setError('Add a title.')
      return null
    }
    if (!date) {
      setError('Pick a date.')
      return null
    }
    if (hasTime && !startTime) {
      setError('Pick a time, or turn off "Has a time".')
      return null
    }
    setError('')
    return {
      title: title.trim(),
      type,
      date,
      startTime: hasTime ? startTime : null,
      endTime: hasTime && type === 'event' && endTime ? endTime : null,
      notes: notes.trim(),
      repeat: repeat === 'none' ? null : { freq: repeat },
      showOnCalendar: type === 'task' && showOnCalendar,
    }
  }

  function save() {
    const values = buildValues()
    if (!values) return
    if (mode === 'edit' && repeating) setAsking('save')
    else onSave(values)
  }

  return (
    <>
      <Sheet
        title={mode === 'add' ? (type === 'event' ? 'New event' : 'New task') : type === 'event' ? 'Edit event' : 'Edit task'}
        onCancel={onClose}
        footer={
          <>
            {error && <p className="error small form-error">{error}</p>}
            <button className="btn primary wide" onClick={save}>
              Save
            </button>
          </>
        }
      >
        <label className="field">
          <span>Title</span>
          <input
            className="input"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            autoFocus={mode === 'add'}
            placeholder="What is it?"
          />
        </label>

        <div className="segmented" role="group" aria-label="Type">
          <button className={type === 'event' ? 'on event' : ''} onClick={() => pickType('event')}>
            Event
          </button>
          <button className={type === 'task' ? 'on task' : ''} onClick={() => setType('task')}>
            Task
          </button>
        </div>

        <label className="field">
          <span>Date</span>
          <input className="input" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </label>

        <label className="toggle">
          <input type="checkbox" checked={hasTime} onChange={(e) => setHasTime(e.target.checked)} />
          <span>Has a time</span>
        </label>

        {hasTime && (
          <div className="two-col">
            <label className="field">
              <span>{type === 'task' ? 'Due at' : 'Starts'}</span>
              <input className="input" type="time" value={startTime} onChange={(e) => changeStart(e.target.value)} />
            </label>
            {type === 'event' && (
              <label className="field">
                <span>Ends (optional)</span>
                <input className="input" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
              </label>
            )}
          </div>
        )}

        {type === 'task' && (
          <label className="toggle">
            <input type="checkbox" checked={showOnCalendar} onChange={(e) => setShowOnCalendar(e.target.checked)} />
            <span>Show on calendar</span>
          </label>
        )}

        <label className="field">
          <span>Repeat</span>
          <select className="input" value={repeat} onChange={(e) => setRepeat(e.target.value as RepeatChoice)}>
            <option value="none">Does not repeat</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
        </label>

        <label className="field">
          <span>Notes</span>
          <textarea className="input" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </label>

        {mode === 'edit' && onDelete && (
          <button className="btn danger wide" onClick={() => setAsking('delete')}>
            Delete
          </button>
        )}
      </Sheet>

      {asking === 'save' && (
        <ChoiceDialog<Scope>
          title="Edit repeating item"
          message="Apply your changes to:"
          choices={[
            { label: 'This occurrence only', value: 'one' },
            { label: 'All occurrences', value: 'all' },
          ]}
          onChoose={(scope) => {
            const values = buildValues()
            setAsking(null)
            if (values) onSave(values, scope)
          }}
          onCancel={() => setAsking(null)}
        />
      )}

      {asking === 'delete' && repeating && (
        <ChoiceDialog<Scope>
          title="Delete repeating item"
          choices={[
            { label: 'Delete this occurrence only', value: 'one', danger: true },
            { label: 'Delete all occurrences', value: 'all', danger: true },
          ]}
          onChoose={(scope) => {
            setAsking(null)
            onDelete?.(scope)
          }}
          onCancel={() => setAsking(null)}
        />
      )}

      {asking === 'delete' && !repeating && (
        <ChoiceDialog<'delete'>
          title="Delete this item?"
          message="This cannot be undone."
          choices={[{ label: 'Delete', value: 'delete', danger: true }]}
          onChoose={() => {
            setAsking(null)
            onDelete?.()
          }}
          onCancel={() => setAsking(null)}
        />
      )}
    </>
  )
}
