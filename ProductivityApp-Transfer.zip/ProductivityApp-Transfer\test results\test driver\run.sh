powershell -c "Get-CimInstance Win32_Process -Filter \"name='msedge.exe'\" | ? {\$_.CommandLine -match 'remote-debugging-port=9333'} | % {Stop-Process -Id \$_.ProcessId -Force}" 2>/dev/null
node mk.mjs $1 $2 $3
echo "== $1x$2 s$3"
node cdp.mjs o "http://localhost:5173/?demo" steps-$1-$2-$3.json 2>&1 | grep "eval -> \"\|EXC" | tr -d '\' | cut -c1-330
