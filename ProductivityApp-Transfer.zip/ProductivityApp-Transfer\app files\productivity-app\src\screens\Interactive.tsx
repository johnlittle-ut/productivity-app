// Interactive tab: groups, pending group-event invitations, create / join.

import { useMemo, useState } from 'react'
import { Avatar } from '../components/Avatar'
import { Sheet } from '../components/Dialogs'
import { acceptInvite, declineInvite } from '../groups/actions'
import { useAllGroupEvents, useGroups, useMembers } from '../groups/hooks'
import { groupLayer } from '../groups/index'
import { GROUP_SLOTS, groupColorVar, type Group, type GroupColor, type Invitation } from '../groups/model'
import { computeBusy } from '../lib/busy'
import { formatTimeShort, shortDate, weekdayName } from '../lib/format'
import { conflictsWithBusy, pendingInvitesFor } from '../lib/groupLogic'
import type { Item } from '../types'
import { GroupScreen } from './GroupScreen'
import { GroupSettings } from './GroupSettings'

type View = { kind: 'list' } | { kind: 'group'; id: string } | { kind: 'settings'; id: string }

function NewGroupSheet({ onClose, onCreated }: { onClose: () => void; onCreated: (g: Group) => void }) {
  const [name, setName] = useState('')
  const [color, setColor] = useState<GroupColor>(1)
  return (
    <Sheet
      title="New group"
      onCancel={onClose}
      footer={
        <button
          className="btn primary wide"
          disabled={!name.trim()}
          onClick={async () => onCreated(await groupLayer.groups.create(name, color))}
        >
          Create group
        </button>
      }
    >
      <label className="field">
        <span>Group name</span>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} autoFocus placeholder="Roommates" />
      </label>
      <div className="field">
        <span>Color</span>
        <div className="swatches" role="group" aria-label="Group color">
          {GROUP_SLOTS.map((c) => (
            <button
              key={c}
              type="button"
              className={`swatch${c === color ? ' on' : ''}`}
              style={{ background: groupColorVar(c) }}
              onClick={() => setColor(c)}
              aria-label={`Color ${c}`}
              aria-pressed={c === color}
            />
          ))}
        </div>
      </div>
    </Sheet>
  )
}

const JOIN_ERRORS = {
  invalid: "That link doesn't look right.",
  expired: 'That link has expired. Ask for a new one.',
  used: 'That link was already used. Ask for a new one.',
  'already-member': "You're already in that group.",
} as const

function JoinSheet({ onClose, onJoined }: { onClose: () => void; onJoined: (groupId: string) => void }) {
  const [text, setText] = useState('')
  const [error, setError] = useState('')
  async function join() {
    const result = await groupLayer.links.redeem(text)
    if (result.ok) onJoined(result.groupId)
    else setError(JOIN_ERRORS[result.reason])
  }
  return (
    <Sheet
      title="Join with link"
      onCancel={onClose}
      footer={
        <>
          {error && <p className="error small form-error">{error}</p>}
          <button className="btn primary wide" disabled={!text.trim()} onClick={() => void join()}>
            Join
          </button>
        </>
      }
    >
      <label className="field">
        <span>Paste the invite link</span>
        <input
          className="input"
          value={text}
          onChange={(e) => {
            setText(e.target.value)
            setError('')
          }}
          autoFocus
          placeholder="https://…/join/…"
        />
      </label>
    </Sheet>
  )
}

function InvitationCard({ inv, busy }: { inv: Invitation; busy: boolean }) {
  const members = useMembers()
  const from = members.find((m) => m.id === inv.event.creatorId)
  const e = inv.event
  return (
    <li className="invite-card" style={{ borderColor: groupColorVar(inv.group.color) }}>
      <div className="invite-top">
        <span className="dot-lg" style={{ background: groupColorVar(inv.group.color) }} />
        <strong>{e.title}</strong>
        <span className="muted small">{inv.group.name}</span>
      </div>
      <p className="small">
        {weekdayName(e.date).slice(0, 3)} {shortDate(e.date)}, {formatTimeShort(e.startTime)} – {formatTimeShort(e.endTime)}
        {from ? ` · from ${from.name.split(' ')[0]}` : ''}
      </p>
      {busy && <p className="small busy-note">You&apos;re busy then</p>}
      <div className="row">
        <button className="btn primary" onClick={() => void acceptInvite(e)}>
          Accept
        </button>
        <button className="btn" onClick={() => void declineInvite(e)}>
          Decline
        </button>
      </div>
    </li>
  )
}

export function Interactive({ items, today, tz }: { items: Item[]; today: string; tz: string }) {
  const groups = useGroups()
  const events = useAllGroupEvents()
  const members = useMembers()
  const [view, setView] = useState<View>({ kind: 'list' })
  const [creating, setCreating] = useState(false)
  const [joining, setJoining] = useState(false)

  const myBusy = useMemo(() => computeBusy(items, groupLayer.me.id, today, tz), [items, today, tz])
  const invites = useMemo(
    () => pendingInvitesFor(events ?? [], groups, groupLayer.me.id, today),
    [events, groups, today],
  )

  const current = view.kind === 'list' ? null : (groups.find((g) => g.id === view.id) ?? null)

  if (view.kind === 'group' && current) {
    return (
      <GroupScreen
        key={current.id}
        group={current}
        items={items}
        today={today}
        tz={tz}
        onBack={() => setView({ kind: 'list' })}
        onSettings={() => setView({ kind: 'settings', id: current.id })}
      />
    )
  }
  if (view.kind === 'settings' && current) {
    return (
      <GroupSettings
        group={current}
        onBack={() => setView({ kind: 'group', id: current.id })}
        onLeft={() => setView({ kind: 'list' })}
      />
    )
  }

  return (
    <div className="interactive">
      {invites.length > 0 && (
        <section className="invites">
          <h2 className="section-title">Invitations</h2>
          <ul className="invite-list">
            {invites.map((inv) => (
              <InvitationCard key={inv.event.id} inv={inv} busy={conflictsWithBusy(inv.event, myBusy, tz)} />
            ))}
          </ul>
        </section>
      )}

      <div className="row group-actions">
        <button className="btn primary" onClick={() => setCreating(true)}>
          New group
        </button>
        <button className="btn" onClick={() => setJoining(true)}>
          Join with link
        </button>
      </div>

      <h2 className="section-title">Your groups</h2>
      {groups.length === 0 ? (
        <p className="muted agenda-empty">No groups yet. Create one or join with a link.</p>
      ) : (
        <ul className="group-list">
          {groups.map((g) => (
            <li key={g.id}>
              <button className="group-row" onClick={() => setView({ kind: 'group', id: g.id })}>
                <span className="dot-lg" style={{ background: groupColorVar(g.color) }} />
                <span className="group-name">{g.name}</span>
                <span className="avatars">
                  {g.memberIds
                    .map((id) => members.find((m) => m.id === id))
                    .filter((m) => !!m)
                    .map((m) => (
                      <Avatar key={m.id} member={m} size={26} />
                    ))}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}

      {creating && (
        <NewGroupSheet
          onClose={() => setCreating(false)}
          onCreated={(g) => {
            setCreating(false)
            setView({ kind: 'group', id: g.id })
          }}
        />
      )}
      {joining && (
        <JoinSheet
          onClose={() => setJoining(false)}
          onJoined={(id) => {
            setJoining(false)
            setView({ kind: 'group', id })
          }}
        />
      )}
    </div>
  )
}
