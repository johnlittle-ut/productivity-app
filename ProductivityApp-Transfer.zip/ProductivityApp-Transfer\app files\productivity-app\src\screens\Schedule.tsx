import { useEffect, useMemo, useRef, useState } from 'react'
import { ItemRow } from '../components/ItemRow'
import { dataLayer } from '../data'
import { addDays, dayOfWeek } from '../lib/dates'
import { shortDate, weekdayName } from '../lib/format'
import { occurrencesByDate, overdueOccurrences, type Occurrence } from '../lib/schedule'
import type { Item } from '../types'

const PAGE_DAYS = 60
const MAX_DAYS = 730

interface Props {
  items: Item[]
  today: string
  tz: string
  onCheck: (occ: Occurrence) => void
  onOpen: (occ: Occurrence) => void
  onMove: (occ: Occurrence) => void
  /** Open the full form on a date, optionally with a title already typed. */
  onAddFull: (date: string, title?: string) => void
}

function QuickAdd({ date, onAddFull }: { date: string; onAddFull: Props['onAddFull'] }) {
  const [open, setOpen] = useState(false)
  const [title, setTitle] = useState('')

  async function submit() {
    const t = title.trim()
    if (!t) return
    await dataLayer.items.add({ title: t, type: 'task', date })
    setTitle('')
    setOpen(false)
  }

  if (!open) {
    return (
      <button className="quick-add-btn" onClick={() => setOpen(true)} aria-label={`Add to ${shortDate(date)}`}>
        + Add
      </button>
    )
  }
  return (
    <div className="quick-add">
      <input
        className="input"
        autoFocus
        value={title}
        placeholder="New task"
        onChange={(e) => setTitle(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') void submit()
          if (e.key === 'Escape') setOpen(false)
        }}
      />
      <button className="btn primary" onClick={() => void submit()}>
        Add
      </button>
      <button
        className="btn"
        onClick={() => {
          onAddFull(date, title.trim())
          setTitle('')
          setOpen(false)
        }}
      >
        More…
      </button>
    </div>
  )
}

export function Schedule({ items, today, tz, onCheck, onOpen, onMove, onAddFull }: Props) {
  const [days, setDays] = useState(PAGE_DAYS)
  const sentinel = useRef<HTMLDivElement>(null)

  const lastDate = addDays(today, days - 1)
  const byDate = useMemo(() => occurrencesByDate(items, today, lastDate, tz), [items, today, lastDate, tz])
  const overdue = useMemo(() => overdueOccurrences(items, today, tz), [items, today, tz])
  const dates = useMemo(() => Array.from({ length: days }, (_, i) => addDays(today, i)), [today, days])

  // Load more dates as the user scrolls
  useEffect(() => {
    const el = sentinel.current
    if (!el || days >= MAX_DAYS) return
    const io = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) setDays((d) => Math.min(d + PAGE_DAYS, MAX_DAYS))
    })
    io.observe(el)
    return () => io.disconnect()
  }, [days])

  return (
    <div className="schedule">
      {overdue.length > 0 && (
        <section className="day overdue">
          <h3 className="day-head">
            <span className="day-date">Overdue</span>
          </h3>
          <ul>
            {overdue.map((occ) => (
              <ItemRow key={occ.key} occ={occ} onCheck={onCheck} onOpen={onOpen} onMove={onMove} showDate />
            ))}
          </ul>
        </section>
      )}

      {dates.map((date) => {
        const occs = byDate.get(date) ?? []
        const isMonday = dayOfWeek(date) === 1
        const isToday = date === today
        return (
          <section key={date} className={`day${isMonday ? ' monday' : ''}${isToday ? ' today' : ''}`}>
            <h3 className="day-head">
              <span className="day-date">{shortDate(date)}</span>
              <span className="day-name">{weekdayName(date)}</span>
              {isToday && <span className="badge">Today</span>}
            </h3>
            {occs.length > 0 && (
              <ul>
                {occs.map((occ) => (
                  <ItemRow key={occ.key} occ={occ} onCheck={onCheck} onOpen={onOpen} onMove={onMove} />
                ))}
              </ul>
            )}
            <QuickAdd date={date} onAddFull={onAddFull} />
          </section>
        )
      })}
      <div ref={sentinel} className="sentinel" aria-hidden="true" />
    </div>
  )
}
