import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { readOnce } from '../data/actions'
import { dataLayer } from '../data'
import { useSubscription } from '../data/hooks'
import type { Listener } from '../data/types'
import { computeBusy } from '../lib/busy'
import { planGroupSync } from '../lib/groupLogic'
import type { Item } from '../types'
import { groupLayer } from './index'
import { groupColorVar, type BusyInterval, type Group, type GroupEvent, type InviteLink, type Member } from './model'

const NO_GROUPS: Group[] = []
const NO_MEMBERS: Member[] = []
const NO_LINKS: InviteLink[] = []
const NO_BUSY: BusyInterval[] = []

const subGroups = (cb: Listener<Group[]>) => groupLayer.groups.subscribe(cb)
const subMembers = (cb: Listener<Member[]>) => groupLayer.members.subscribe(cb)
const subEvents = (cb: Listener<GroupEvent[] | null>) => groupLayer.events.subscribeAll(cb as Listener<GroupEvent[]>)
const subLinks = (cb: Listener<InviteLink[]>) => groupLayer.links.subscribe(cb)

export const useGroups = () => useSubscription(subGroups, NO_GROUPS)
export const useMembers = () => useSubscription(subMembers, NO_MEMBERS)
export const useLinks = () => useSubscription(subLinks, NO_LINKS)
/** Null until the first value arrives. */
export const useAllGroupEvents = () => useSubscription<GroupEvent[] | null>(subEvents, null)

export function useGroupBusy(groupId: string): BusyInterval[] {
  const sub = useCallback((cb: Listener<BusyInterval[]>) => groupLayer.busy.subscribe(groupId, cb), [groupId])
  return useSubscription(sub, NO_BUSY)
}

/** Ticks every `ms` while mounted (for countdowns). */
export function useNow(ms = 1000): number {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), ms)
    return () => clearInterval(id)
  }, [ms])
  return now
}

/** groupId -> color, so personal copies of group events can be tinted in the group color. */
export const GroupColorsContext = createContext<Map<string, string>>(new Map())
export const useGroupColor = (groupId: string | undefined): string | undefined =>
  useContext(GroupColorsContext).get(groupId ?? '')

export function useGroupColorMap(groups: Group[]): Map<string, string> {
  return useMemo(() => new Map(groups.map((g) => [g.id, groupColorVar(g.color)])), [groups])
}

/**
 * Always-on group plumbing (mounted once in App):
 * - publishes my busy intervals (start/end only) from my personal calendar
 * - keeps accepted group-event copies in sync with their group event (edit, cancel)
 */
export function useGroupBackground(items: Item[], today: string, tz: string): void {
  const events = useAllGroupEvents()

  useEffect(() => {
    void groupLayer.busy.publishMine(computeBusy(items, groupLayer.me.id, today, tz))
  }, [items, today, tz])

  useEffect(() => {
    if (!events) return
    const plan = planGroupSync(items, events)
    for (const id of plan.removeIds) void dataLayer.items.remove(id)
    for (const { id, patch } of plan.updates) void dataLayer.items.update(id, patch)
  }, [items, events])
}

export { readOnce }
