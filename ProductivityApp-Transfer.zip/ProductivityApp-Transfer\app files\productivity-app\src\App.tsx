import { useCallback, useEffect, useMemo, useState } from 'react'
import { Toast } from './components/Dialogs'
import { BackIcon, CalendarIcon, SearchIcon, CartIcon, GearIcon, PeopleIcon, ScheduleIcon, TodoIcon } from './components/icons'
import { ItemForm } from './components/ItemForm'
import {
  createItem,
  moveToTomorrow,
  removeOccurrence,
  runCleanup,
  saveEdit,
  setDone,
  type FormValues,
  type Scope,
} from './data/actions'
import { useItems, useSettings, useShopping, useTodos } from './data/hooks'
import { dataLayer } from './data'
import { addDays } from './lib/dates'
import { searchOccurrences } from './lib/schedule'
import { formatTimeShort, setTimeFormat, shortDate, weekdayName } from './lib/format'
import { INTERACTIVE_ENABLED } from './lib/flags'
import { applyTheme } from './lib/theme'
import { useDeviceTimezone } from './lib/useDeviceTimezone'
import type { Occurrence } from './lib/schedule'
import type { ItemType } from './types'
import { useToday } from './lib/useToday'
import { GroupColorsContext, useGroupBackground, useGroupColorMap, useGroups } from './groups/hooks'
import { Calendar, type CalendarView } from './screens/Calendar'
import { Interactive } from './screens/Interactive'
import { ListScreen } from './screens/ListScreen'
import { Schedule } from './screens/Schedule'
import { Settings } from './screens/Settings'

type TabId = 'calendar' | 'schedule' | 'shopping' | 'todo' | 'interactive'

const ALL_TABS: { id: TabId; label: string; icon: () => React.JSX.Element }[] = [
  { id: 'calendar', label: 'Calendar', icon: CalendarIcon },
  { id: 'schedule', label: 'Schedule', icon: ScheduleIcon },
  { id: 'todo', label: 'To-Do', icon: TodoIcon },
  { id: 'shopping', label: 'Shopping', icon: CartIcon },
  { id: 'interactive', label: 'Interactive', icon: PeopleIcon },
]

const TABS = ALL_TABS.filter((t) => INTERACTIVE_ENABLED || t.id !== 'interactive')

const TITLES: Record<TabId, string> = {
  calendar: 'Calendar',
  schedule: 'Daily Schedule',
  shopping: 'Shopping List',
  interactive: 'Interactive',
  todo: 'To-Do',
}

/** 'HH:mm' plus one hour, capped at 23:59 (default length of an event started from an empty slot). */
const plusOneHour = (hhmm: string): string => {
  const [h, m] = hhmm.split(':').map(Number)
  const total = Math.min(h * 60 + m + 60, 23 * 60 + 59)
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`
}

const TAB_KEY = 'productivity-app:default-tab'
const TAB_IDS: TabId[] = ['calendar', 'schedule', 'todo', 'shopping', 'interactive']
function readDefaultTab(): TabId {
  try {
    const v = localStorage.getItem(TAB_KEY) as TabId | null
    if (v && TAB_IDS.includes(v) && (INTERACTIVE_ENABLED || v !== 'interactive')) return v
  } catch {
    /* storage unavailable: use the default */
  }
  return 'schedule'
}
function saveDefaultTab(t: TabId) {
  try {
    localStorage.setItem(TAB_KEY, t)
  } catch {
    /* ignore */
  }
}

type Editor =
  | { mode: 'add'; date: string; title?: string; type?: ItemType; startTime?: string; endTime?: string }
  | { mode: 'edit'; occ: Occurrence }

interface ToastState {
  id: number
  message: string
  undo?: () => void
}

export default function App() {
  const [tab, setTab] = useState<TabId>(readDefaultTab)
  const [query, setQuery] = useState<string | null>(null) // Schedule search: null = collapsed
  const [showSettings, setShowSettings] = useState(false)
  const [editor, setEditor] = useState<Editor | null>(null)
  const [toast, setToast] = useState<ToastState | null>(null)
  // Selected day in the Calendar tab; null means "today". Kept here so it persists across tabs.
  const [calendarDate, setCalendarDate] = useState<string | null>(null)
  const [calendarView, setCalendarView] = useState<CalendarView>('day')

  const items = useItems()
  const shopping = useShopping()
  const todos = useTodos()
  const settings = useSettings()
  const deviceTz = useDeviceTimezone()
  const effTz = settings?.timezoneOverride || deviceTz // override ?? device
  const today = useToday(effTz)
  setTimeFormat(settings?.timeFormat)

  // Apply the chosen theme (System / Light / Dark); also remembered locally so the next launch has no flash
  const theme = settings ? (settings.theme ?? 'system') : null
  useEffect(() => {
    if (theme) applyTheme(theme)
  }, [theme])

  // Text size (one setting scales everything via rem) and remembered default tab
  const textSize = settings?.textSize ?? 100
  const defaultTab = settings?.defaultTab
  useEffect(() => {
    document.documentElement.style.fontSize = `${textSize}%`
  }, [textSize])
  useEffect(() => {
    if (defaultTab) saveDefaultTab(defaultTab)
  }, [defaultTab])

  // Keep the saved timezone equal to the effective one (override ?? device)
  useEffect(() => {
    if (settings && settings.timezone !== effTz) void dataLayer.settings.update({ timezone: effTz })
  }, [settings, effTz])

  // Legacy timed items without a zone: stamp once with the current effective zone
  useEffect(() => {
    if (!settings) return
    for (const it of items) if (it.startTime && !it.tz) void dataLayer.items.update(it.id, { tz: effTz })
  }, [items, settings, effTz])
  const results = useMemo(() => searchOccurrences(items, today, query ?? '', effTz), [items, today, query, effTz])
  const groups = useGroups()
  const groupColors = useGroupColorMap(groups)
  useGroupBackground(items, today, effTz)

  // Auto-clear things checked off 24+ hours ago: on open and when returning to the app.
  useEffect(() => {
    void dataLayer.purgeDeleted()
    void runCleanup()
    const onVisible = () => {
      if (document.visibilityState === 'visible') void runCleanup()
    }
    document.addEventListener('visibilitychange', onVisible)
    return () => document.removeEventListener('visibilitychange', onVisible)
  }, [])

  // Toast auto-dismiss
  useEffect(() => {
    if (!toast) return
    const id = setTimeout(() => setToast(null), 6000)
    return () => clearTimeout(id)
  }, [toast])

  const showToast = useCallback((message: string, undo?: () => void) => {
    setToast({
      id: Date.now(),
      message,
      undo: undo
        ? () => {
            undo()
            setToast(null)
          }
        : undefined,
    })
  }, [])

  const handleCheck = useCallback(
    (occ: Occurrence) => {
      void setDone(occ.item, occ.srcDate, true)
      showToast(`"${occ.item.title}" done`, () => void setDone(occ.item, occ.srcDate, false))
    },
    [showToast],
  )

  const handleMove = useCallback(
    async (occ: Occurrence) => {
      const undo = await moveToTomorrow(occ.item, occ.srcDate, addDays(today, 1), { startTime: occ.startTime, endTime: occ.endTime, tz: effTz })
      showToast(`"${occ.item.title}" moved to tomorrow`, () => void undo())
    },
    [showToast, today, effTz],
  )

  const handleSave = useCallback(
    async (values: FormValues, scope?: Scope) => {
      if (!editor) return
      if (editor.mode === 'add') return void (await createItem({ ...values, tz: values.startTime ? effTz : undefined }), setEditor(null))
      // Keep the item's original zone unless its date, time or repeat changed; re-anchor to the current zone only then.
      const { occ } = editor
      const unchanged =
        !!occ.item.tz &&
        values.date === occ.date &&
        values.startTime === occ.startTime &&
        values.endTime === occ.endTime &&
        values.repeat?.freq === occ.item.repeat?.freq
      if (unchanged) {
        const keep = { ...values, startTime: occ.item.startTime, endTime: occ.item.endTime, tz: occ.item.tz }
        if (!occ.item.repeat) await saveEdit(occ.item, occ.srcDate, { ...keep, date: occ.item.date }, scope)
        else if (scope === 'one') await saveEdit(occ.item, occ.srcDate, { ...keep, date: occ.srcDate }, scope)
        else await saveEdit(occ.item, occ.srcDate, { ...keep, date: occ.item.date }, scope, occ.item.date)
      } else {
        await saveEdit(occ.item, occ.srcDate, { ...values, tz: values.startTime ? effTz : undefined }, scope, occ.date)
      }
      setEditor(null)
    },
    [editor, effTz],
  )

  const handleDelete = useCallback(
    async (scope?: Scope) => {
      if (editor?.mode !== 'edit') return
      await removeOccurrence(editor.occ.item, editor.occ.srcDate, scope)
      setEditor(null)
    },
    [editor],
  )

  const initialValues: FormValues | null = !editor
    ? null
    : editor.mode === 'add'
      ? {
          title: editor.title ?? '',
          type: editor.type ?? 'task',
          date: editor.date,
          startTime: editor.startTime ?? null,
          endTime: editor.endTime ?? null,
          notes: '',
          repeat: null,
          showOnCalendar: false,
        }
      : {
          title: editor.occ.item.title,
          type: editor.occ.item.type,
          date: editor.occ.date,
          startTime: editor.occ.startTime,
          endTime: editor.occ.endTime,
          notes: editor.occ.item.notes,
          repeat: editor.occ.item.repeat,
          showOnCalendar: editor.occ.item.showOnCalendar === true,
        }

  const showFab = !showSettings && (tab === 'schedule' || tab === 'calendar')

  return (
    <GroupColorsContext.Provider value={groupColors}>
    <div className="phone">
      <header className="topbar">
        {showSettings ? (
          <button className="icon-btn" onClick={() => setShowSettings(false)} aria-label="Back">
            <BackIcon />
          </button>
        ) : tab === 'schedule' && query === null ? (
          <button className="icon-btn" onClick={() => setQuery('')} aria-label="Search">
            <SearchIcon />
          </button>
        ) : (
          <span className="icon-btn-spacer" />
        )}
        {!showSettings && tab === 'schedule' && query !== null ? (
          <div className="search-field">
            <input
              className="input"
              autoFocus
              type="search"
              value={query}
              placeholder="Search schedule"
              aria-label="Search schedule"
              onChange={(e) => setQuery(e.target.value)}
              onBlur={() => {
                if (!query) setQuery(null)
              }}
              onKeyDown={(e) => {
                if (e.key === 'Escape') setQuery(null)
              }}
            />
            <button className="link-btn" onClick={() => setQuery(null)}>
              Close
            </button>
          </div>
        ) : (
          <h1>{showSettings ? 'Settings' : TITLES[tab]}</h1>
        )}
        {showSettings ? (
          <span className="icon-btn-spacer" />
        ) : !(tab === 'schedule' && query !== null) ? (
          <button className="icon-btn" onClick={() => setShowSettings(true)} aria-label="Settings">
            <GearIcon />
          </button>
        ) : null}
      </header>

      <main className="content">
        {showSettings ? (
          <Settings onUndone={() => setToast(null)} />
        ) : (
          <>
            {tab === 'calendar' && (
              <Calendar
                items={items}
                today={today}
                timezone={effTz}
                selected={calendarDate ?? today}
                view={calendarView}
                onView={setCalendarView}
                onAddAt={(date, startTime) => setEditor({ mode: 'add', date, type: 'event', startTime, endTime: plusOneHour(startTime) })}
                onSelect={setCalendarDate}
                onCheck={handleCheck}
                onOpen={(occ) => setEditor({ mode: 'edit', occ })}
                onMove={(occ) => void handleMove(occ)}
              />
            )}
            {tab === 'schedule' && query ? (
              results.length === 0 ? (
                <p className="muted">No matches.</p>
              ) : (
                <ul className="search-results">
                  {results.map((occ) => (
                    <li key={occ.key}>
                      <button className="search-result" onClick={() => setEditor({ mode: 'edit', occ })}>
                        {occ.item.title}
                        <small>
                          {weekdayName(occ.date).slice(0, 3)} {shortDate(occ.date)}
                          {occ.startTime ? ` · ${formatTimeShort(occ.startTime)}` : ''}
                          {occ.date < today ? ' · overdue' : ''}
                        </small>
                      </button>
                    </li>
                  ))}
                </ul>
              )
            ) : tab === 'schedule' && (
              <Schedule
                items={items}
                today={today}
                tz={effTz}
                onCheck={handleCheck}
                onOpen={(occ) => setEditor({ mode: 'edit', occ })}
                onMove={(occ) => void handleMove(occ)}
                onAddFull={(date, title) => setEditor({ mode: 'add', date, title })}
              />
            )}
            {tab === 'shopping' && (
              <ListScreen
                kind="shopping"
                entries={shopping}
                addPlaceholder="Add to shopping list"
                emptyText="Your shopping list is empty."
                sectioned
                withNotes={false}
                onToast={showToast}
              />
            )}
            {tab === 'todo' && (
              <ListScreen
                kind="todos"
                entries={todos}
                addPlaceholder="Add a to-do"
                emptyText="Nothing to do. Nice."
                urgency
                today={today}
                withNotes
                onToast={showToast}
              />
            )}
            {tab === 'interactive' && <Interactive items={items} today={today} tz={effTz} />}
          </>
        )}
      </main>

      {showFab && (
        <button
          className="fab"
          onClick={() => setEditor({ mode: 'add', date: tab === 'calendar' ? (calendarDate ?? today) : today })}
          aria-label="Add item"
        >
          +
        </button>
      )}

      {toast && <Toast key={toast.id} message={toast.message} onUndo={toast.undo} />}

      <nav className="tabbar" aria-label="Main">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            className={`tab ${!showSettings && tab === id ? 'active' : ''}`}
            onClick={() => {
              setTab(id)
              setShowSettings(false)
            }}
            aria-current={!showSettings && tab === id ? 'page' : undefined}
          >
            <Icon />
            <span>{label}</span>
          </button>
        ))}
      </nav>

      {editor && initialValues && (
        <ItemForm
          mode={editor.mode}
          tz={effTz}
          initial={initialValues}
          repeating={editor.mode === 'edit' && editor.occ.item.repeat !== null}
          onSave={(values, scope) => void handleSave(values, scope)}
          onDelete={editor.mode === 'edit' ? (scope) => void handleDelete(scope) : undefined}
          onClose={() => setEditor(null)}
        />
      )}
    </div>
    </GroupColorsContext.Provider>
  )
}
