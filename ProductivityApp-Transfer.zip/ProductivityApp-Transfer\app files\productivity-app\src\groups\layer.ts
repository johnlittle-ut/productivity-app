// The GroupLayer interface (Interactive tab). Same subscription style as the personal DataLayer.
// A mock implementation lives in mockLayer.ts; a Firestore one replaces it in the backend phase.
// Real structure later (informational): groups/{groupId} with members; groups/{groupId}/busy/{uid} holding only
// intervals; groups/{groupId}/events/{id} with responses.

import type { Listener, Unsubscribe } from '../data/types'
import type { BusyInterval, Group, GroupColor, GroupEvent, GroupEventInput, InviteLink, Member, RedeemResult, Response } from './model'

export interface GroupLayer {
  /** The signed-in user as a group member. */
  me: Member

  /** Everyone I can see (members of my groups). */
  members: { subscribe(cb: Listener<Member[]>): Unsubscribe }

  groups: {
    /** Groups I am a member of. */
    subscribe(cb: Listener<Group[]>): Unsubscribe
    create(name: string, color: GroupColor): Promise<Group>
    update(groupId: string, patch: Partial<Pick<Group, 'name' | 'color'>>): Promise<void>
    leave(groupId: string): Promise<void>
  }

  events: {
    /** Group events (including cancelled ones, flagged) of all my groups. */
    subscribeAll(cb: Listener<GroupEvent[]>): Unsubscribe
    create(groupId: string, input: GroupEventInput): Promise<GroupEvent>
    /** Creator edits; accepted copies follow. */
    update(eventId: string, input: GroupEventInput): Promise<void>
    cancel(eventId: string): Promise<void>
    respond(eventId: string, response: Exclude<Response, 'pending'>): Promise<void>
  }

  busy: {
    /** Busy intervals of every member of the group, including mine. Start/end only. */
    subscribe(groupId: string, cb: Listener<BusyInterval[]>): Unsubscribe
    /** Publish my own busy intervals (computed from my personal calendar). */
    publishMine(intervals: BusyInterval[]): Promise<void>
  }

  links: {
    subscribe(cb: Listener<InviteLink[]>): Unsubscribe
    /** One-time link, valid 20 minutes. */
    create(groupId: string): Promise<InviteLink>
    redeem(text: string): Promise<RedeemResult>
  }
}

/** Mock-only helpers behind the dev section. Not part of the real interface. */
export interface MockControls {
  seed(): Promise<void>
  simulateJoin(groupId: string): Promise<string | null>
  simulateLeave(groupId: string): Promise<string | null>
  simulateIncomingInvite(): Promise<string | null>
  createJoinableGroupLink(): Promise<InviteLink>
  /** Simulate someone using my link (marks it used and adds a mock member). */
  simulateLinkUsed(token: string): Promise<string | null>
}
