// Auth abstraction. For now a stub that returns a fixed local user.
// Later, real Google sign-in replaces this module with the same shape.

export interface AuthProvider {
  getUserId(): string
  signOut(): Promise<void>
}

export const LOCAL_USER_ID = 'local-user'

export const auth: AuthProvider = {
  getUserId: () => LOCAL_USER_ID,
  signOut: async () => {},
}
