PRODUCTIVITY APP - TRANSFER PACKAGE (made 2026-11-04)

dev work/
  planning docs/   CURRENT masters: CLAUDE.md, Plan.md, CHANGELOG.md, handoffs/, design/, FUTURECHANGES.md,
                   HOME-CHECKLIST.md, MANUAL-CHECKLIST.md, WORKFLOW-SETUP.md (how the Craig 2 / Dan 2 / Ava chats work together)
  agent setup/     claude memory/ (your saved feedback notes) and chat transcript/ (raw session logs; reference only,
                   a new chat cannot resume them - start fresh chats from CLAUDE.md + WORKFLOW-SETUP.md)
app files/
  productivity-app/   full source as of the last commit (no node_modules/dist). Its doc copies (CLAUDE.md, Plan.md,
                      handoffs) are OLDER than "dev work/planning docs"; use those as the masters.
  git bundle/         productivity-app.bundle = the same code WITH full git history
test results/
  latest-test-run.txt (74 tests pass, tsc and oxlint clean), screenshots/ (layout checks 360-430px), test driver/ (Edge CDP scripts)

TO RESTORE ON THE NEW LAPTOP
1. Install Node (LTS) and git.
2. git clone "app files/git bundle/productivity-app.bundle" productivity-app   (or copy app files/productivity-app)
3. cd productivity-app ; npm install ; npm run dev   (open http://localhost:5173/?demo for sample data)
4. Put "dev work/planning docs" next to the project and open your Claude chats there; copy "claude memory" notes into
   the new project's Claude memory folder if you want them.
5. Next phase: backend (Firebase etc.) per Plan.md 3.6 and handoffs/003 - from the personal laptop.
