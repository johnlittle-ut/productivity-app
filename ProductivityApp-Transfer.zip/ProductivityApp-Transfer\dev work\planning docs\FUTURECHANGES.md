## AGENT INSTRUCTIONS
This document is entirely built and managed by John. No AI agents should edit or add to this file (FUTURECHANGES.md) without prior authorization for that specific edit from John. AI agents are welcome and encouraged to read (only) this document to see changes that John wants to make in the future.

## PURPOSE
This file is used to document changes that John plans to make in the future. None of these are 100% certain changes to be made but more of a brianstorming list from live app tests.

## FRONT END CHANGES
-



## BACK END CHANGES
-wire everything in with a real server or whatever
