# Productivity App

Personal calendar / to-do PWA. Designed for iPhone 15 (393 x 852); on desktop it shows as a centered phone-sized frame. See `Plan.md` (spec) and `CLAUDE.md` (roles and rules).

Current state: complete front end (Calendar, Schedule, To-Do, Shopping, Settings) on a local dev server with on-device storage (handoff 002, M1 to M6). No backend yet. See `MANUAL-CHECKLIST.md` for what to try.

## Setup

Node.js is installed without admin rights at `C:\dev\tools\node` (on the user PATH). In a fresh terminal:

```
npm install
npm run dev      # http://localhost:5173 (also on the LAN, see below)
npm test         # Vitest
npm run build    # type check + production build
npm run lint
```

If `node` is not found, add `C:\dev\tools\node` to your user PATH or run `$env:Path += ";C:\dev\tools\node"` in PowerShell.

## Phone preview

`npm run dev` uses `vite --host`, so Vite prints a **Network** URL (for example `http://172.16.44.33:5173/`). Open it in Safari on the iPhone on the same Wi-Fi. A work network or VPN may block this. Home Screen install and offline testing need HTTPS, so they wait for hosting.

## Data layer (where the backend plugs in)

Screens never touch storage. They use the `DataLayer` interface in `src/data/types.ts` (subscription-style: `subscribe` calls back immediately and on every change).

- `src/data/dexieDataLayer.ts`: current implementation (IndexedDB via Dexie). Rows are keyed by user id.
- `src/data/index.ts`: **the one place the implementation is chosen.** To connect Firebase, write a Firestore implementation of `DataLayer` and export it here.
- `src/data/hooks.ts`: React hooks (`useItems`, `useShopping`, `useTodos`, `useSettings`) used by screens.
- `src/auth/auth.ts`: auth stub returning a fixed local user. Real Google sign-in replaces it.
- `src/data/exportFormat.ts`: validation for the versioned Export/Import JSON file (also the migration path into Firestore).

Dates are plain `YYYY-MM-DD` strings and times `HH:mm`; "today" is computed in the user's timezone setting (`src/lib/dates.ts`).

## Developer tools

In `npm run dev` only, Settings shows a Developer section: **Load sample data** and **Clear all data**. It is not included in production builds.

## Demo data and offline check

- `http://localhost:5173/?demo` (dev only) loads the sample data if the app is empty.
- Offline check: `npm run build`, then `npx vite preview --port 4173`. Open it once so the service worker installs, then reload with the network off; the app shell still opens. (localhost counts as secure; a phone needs HTTPS hosting for this.)

## Code map

- `src/lib/`: pure logic with tests (`recurrence`, `schedule`, `completion`, `order`, `dates`, `format`, `swipe`).
- `src/data/actions.ts`: every write the screens make, through the data layer.
- `src/screens/`: Schedule, Calendar, ListScreen (To-Do and Shopping), Settings.
- `src/components/`: ItemForm (bottom sheet), ItemRow, dialogs, icons, ErrorBoundary.
