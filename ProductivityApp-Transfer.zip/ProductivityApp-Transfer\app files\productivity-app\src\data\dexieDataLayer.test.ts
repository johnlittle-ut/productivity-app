import { afterEach, describe, expect, it } from 'vitest'
import { createDexieDataLayer } from './dexieDataLayer'
import { parseExport } from './exportFormat'
import { mergeRecords } from '../lib/merge'
import type { Item, ListEntry } from '../types'

let counter = 0
const open: { close(): void }[] = []
function make(uid = 'u1', dbName = `test-db-${++counter}`) {
  const dl = createDexieDataLayer(uid, dbName)
  open.push(dl)
  return dl
}
afterEach(() => {
  open.splice(0).forEach((d) => d.close())
})

/** Resolve with the first subscription value matching `pred`. */
function waitFor<T>(subscribe: (cb: (v: T) => void) => () => void, pred: (v: T) => boolean): Promise<T> {
  return new Promise((resolve) => {
    let unsub: (() => void) | null = null
    let done = false
    unsub = subscribe((v) => {
      if (!done && pred(v)) {
        done = true
        queueMicrotask(() => unsub?.())
        resolve(v)
      }
    })
  })
}

describe('items', () => {
  it('adds with defaults and notifies subscribers', async () => {
    const dl = make()
    const waiting = waitFor<Item[]>((cb) => dl.items.subscribe(cb), (v) => v.length === 1)
    const added = await dl.items.add({ title: 'Thrive', type: 'event', date: '2026-11-06', startTime: '18:30' })
    const items = await waiting
    expect(items[0].id).toBe(added.id)
    expect(items[0].reminder).toEqual({ enabled: true, minutesBefore: 60 })
    expect(items[0].done).toBe(false)
    expect(items[0]).not.toHaveProperty('uid')
  })

  it('tasks default to no reminder', async () => {
    const dl = make()
    const t = await dl.items.add({ title: 'Rent', type: 'task', date: '2026-12-01' })
    expect(t.reminder.enabled).toBe(false)
  })

  it('updates and deletes', async () => {
    const dl = make()
    const a = await dl.items.add({ title: 'A', type: 'task', date: '2026-11-04' })
    await dl.items.update(a.id, { title: 'B', done: true })
    let items = await waitFor<Item[]>((cb) => dl.items.subscribe(cb), (v) => v[0]?.title === 'B')
    expect(items[0].done).toBe(true)
    await dl.items.remove(a.id)
    items = await waitFor<Item[]>((cb) => dl.items.subscribe(cb), (v) => v.length === 0)
    expect(items).toEqual([])
  })
})

describe('per-user isolation', () => {
  it("one user cannot see another user's data", async () => {
    const name = `shared-db-${++counter}`
    const a = make('alice', name)
    const b = make('bob', name)
    await a.items.add({ title: "Alice's", type: 'task', date: '2026-11-04' })
    await a.shopping.add('Alice milk')
    const bItems = await waitFor<Item[]>((cb) => b.items.subscribe(cb), () => true)
    const bShop = await waitFor<ListEntry[]>((cb) => b.shopping.subscribe(cb), () => true)
    expect(bItems).toEqual([])
    expect(bShop).toEqual([])
    const exportB = await b.exportAll()
    expect(exportB.items).toEqual([])
  })
})

describe('lists', () => {
  it('adds new entries at the bottom, in order', async () => {
    const dl = make()
    await dl.shopping.add('Milk')
    await dl.shopping.add('Eggs')
    await dl.shopping.add('Bread')
    const list = await waitFor<ListEntry[]>((cb) => dl.shopping.subscribe(cb), (v) => v.length === 3)
    expect(list.map((e) => e.title)).toEqual(['Milk', 'Eggs', 'Bread'])
    expect(list[0].order).toBeLessThan(list[1].order)
    expect(list[1].order).toBeLessThan(list[2].order)
  })

  it('reordering updates one entry only', async () => {
    const dl = make()
    const a = await dl.todos.add('A')
    const b = await dl.todos.add('B')
    const c = await dl.todos.add('C')
    // move C between A and B
    await dl.todos.update(c.id, { order: (a.order + b.order) / 2 })
    const list = await waitFor<ListEntry[]>((cb) => dl.todos.subscribe(cb), (v) => v[1]?.title === 'C')
    expect(list.map((e) => e.title)).toEqual(['A', 'C', 'B'])
  })
})

describe('settings', () => {
  it('creates defaults per user and updates them', async () => {
    const dl = make()
    const s = await dl.settings.get()
    expect(s.defaultEventReminderMinutes).toBe(60)
    expect(s.digestTime).toBe('09:00')
    expect(s.weekStartsOn).toBe('monday')
    await dl.settings.update({ timezone: 'America/New_York' })
    expect((await dl.settings.get()).timezone).toBe('America/New_York')
  })
})

describe('export / import / clear', () => {
  it('round-trips everything through a versioned file', async () => {
    const dl = make()
    await dl.items.add({ title: 'Rent', type: 'task', date: '2026-11-01', repeat: { freq: 'monthly' } })
    await dl.shopping.add('Milk')
    await dl.todos.add('Call dentist', 'ask about March')
    await dl.settings.update({ timezone: 'America/New_York' })

    const exported = await dl.exportAll()
    expect(exported.version).toBe(1)

    const parsed = parseExport(JSON.stringify(exported))
    expect(parsed.ok).toBe(true)

    await dl.clearAll()
    expect((await dl.exportAll()).items).toEqual([])

    if (parsed.ok) await dl.importAll(parsed.file)
    const again = await dl.exportAll()
    expect(again.items).toEqual(exported.items)
    expect(again.shoppingItems).toEqual(exported.shoppingItems)
    expect(again.todos).toEqual(exported.todos)
    expect(again.settings.timezone).toBe('America/New_York')
  })

  it('import replaces existing data', async () => {
    const dl = make()
    await dl.items.add({ title: 'Old', type: 'task', date: '2026-11-04' })
    const other = make('u1', `test-db-${++counter}`)
    await other.items.add({ title: 'New', type: 'event', date: '2026-11-05' })
    await dl.importAll(await other.exportAll())
    const items = (await dl.exportAll()).items
    expect(items.map((i) => i.title)).toEqual(['New'])
  })
})

describe('parseExport validation', () => {
  it('rejects garbage with friendly errors', () => {
    expect(parseExport('not json')).toMatchObject({ ok: false })
    expect(parseExport('[]')).toMatchObject({ ok: false })
    expect(parseExport('{"version":1}')).toMatchObject({ ok: false })
    expect(parseExport('{"version":99,"items":[],"shoppingItems":[],"todos":[],"settings":{}}')).toMatchObject({
      ok: false,
    })
    const bad = { version: 1, items: [{ id: 'x' }], shoppingItems: [], todos: [], settings: {} }
    expect(parseExport(JSON.stringify(bad))).toMatchObject({ ok: false })
  })
})

describe('export/import round trip keeps every field', () => {
  it('preserves seriesId, originalDate, skippedDates, completedOccurrences, until, reminder, order and doneAt', async () => {
    const dl = make()

    const series = await dl.items.add({
      title: 'Thrive',
      type: 'event',
      date: '2026-11-06',
      startTime: '18:30',
      endTime: '20:00',
      notes: 'Bring a friend',
      repeat: { freq: 'weekly', until: '2027-01-29' },
      skippedDates: ['2026-11-13', '2026-11-20'],
      completedOccurrences: { '2026-11-06': 1_700_000_000_000 },
      reminder: { enabled: true, minutesBefore: 45 },
    })
    await dl.items.add({
      title: 'Thrive (moved)',
      type: 'event',
      date: '2026-11-14',
      startTime: '19:00',
      seriesId: series.id,
      originalDate: '2026-11-13',
    })
    await dl.items.add({
      title: 'Done task',
      type: 'task',
      date: '2026-11-02',
      done: true,
      doneAt: 1_700_000_123_456,
    })

    const milk = await dl.shopping.add('Milk')
    await dl.shopping.add('Eggs')
    await dl.shopping.update(milk.id, { done: true, doneAt: 1_700_000_999_000, order: 2500.5 })
    await dl.todos.add('Call dentist', 'ask about March')
    await dl.settings.update({
      timezone: 'America/New_York',
      defaultEventReminderMinutes: 30,
      digestEnabled: false,
      digestTime: '08:15',
    })

    const first = await dl.exportAll()
    const parsed = parseExport(JSON.stringify(first))
    expect(parsed.ok).toBe(true)
    if (!parsed.ok) return

    await dl.clearAll()
    await dl.importAll(parsed.file)
    const second = await dl.exportAll()

    const byTitle = <T extends { title: string }>(a: T, b: T) => a.title.localeCompare(b.title)
    expect([...second.items].sort(byTitle)).toEqual([...first.items].sort(byTitle))
    expect([...second.shoppingItems].sort(byTitle)).toEqual([...first.shoppingItems].sort(byTitle))
    expect([...second.todos].sort(byTitle)).toEqual([...first.todos].sort(byTitle))
    expect(second.settings).toEqual(first.settings)

    // spot-check the tricky fields explicitly
    const s = second.items.find((i) => i.title === 'Thrive')!
    expect(s.repeat).toEqual({ freq: 'weekly', until: '2027-01-29' })
    expect(s.skippedDates).toEqual(['2026-11-13', '2026-11-20'])
    expect(s.completedOccurrences).toEqual({ '2026-11-06': 1_700_000_000_000 })
    expect(s.reminder).toEqual({ enabled: true, minutesBefore: 45 })
    const moved = second.items.find((i) => i.title === 'Thrive (moved)')!
    expect(moved.seriesId).toBe(s.id)
    expect(moved.originalDate).toBe('2026-11-13')
    expect(second.shoppingItems.find((e) => e.title === 'Milk')).toMatchObject({
      done: true,
      doneAt: 1_700_000_999_000,
      order: 2500.5,
    })
  })

  it('importing into a different user id works (migration path)', async () => {
    // Models the real migration: export from the local store, import into a different store and user id
    const a = make('local-user')
    await a.items.add({ title: 'Rent', type: 'task', date: '2026-11-01', repeat: { freq: 'monthly' } })
    const file = await a.exportAll()
    const b = make('some-real-uid')
    await b.importAll(file)
    expect((await b.exportAll()).items.map((i) => i.title)).toEqual(['Rent'])
  })
})

describe('shopping sections', () => {
  it('stores the section, defaults old entries to groceries, and round-trips it', async () => {
    const { sectionOf } = await import('../lib/order')
    const dl = make()
    const a = await dl.shopping.add('Milk', '', 'groceries')
    const b = await dl.shopping.add('Light bulbs', '', 'general')
    const legacy = await dl.shopping.add('Old entry') // no section, as in data saved before sections existed
    expect(a.section).toBe('groceries')
    expect(b.section).toBe('general')
    expect(legacy.section).toBeUndefined()
    expect(sectionOf(legacy)).toBe('groceries')

    await dl.shopping.update(b.id, { section: 'groceries' }) // move between lists via edit
    const exported = await dl.exportAll()
    expect(exported.shoppingItems.find((e) => e.title === 'Light bulbs')?.section).toBe('groceries')
    await dl.clearAll()
    await dl.importAll(exported)
    const again = await dl.exportAll()
    expect(again.shoppingItems.map((e) => [e.title, e.section])).toEqual(
      exported.shoppingItems.map((e) => [e.title, e.section]),
    )
  })
})

describe('sync prep: merge, soft delete, purge', () => {
  it('mergeRecords: newest wins, tie keeps existing, counts', () => {
    const a = [{ id: '1', updatedAt: 5, v: 'old' }, { id: '2', updatedAt: 5, v: 'same' }, { id: '3', updatedAt: 9, v: 'newer here' }]
    const b = [{ id: '1', updatedAt: 6, v: 'new' }, { id: '2', updatedAt: 5, v: 'tie' }, { id: '3', updatedAt: 2, v: 'older' }, { id: '4', updatedAt: 1, v: 'added' }]
    const r = mergeRecords(a, b)
    expect([r.added, r.updated, r.skipped]).toEqual([1, 1, 2])
    expect(Object.fromEntries(r.merged.map((x) => [x.id, x.v]))).toEqual({ 1: 'new', 2: 'same', 3: 'newer here', 4: 'added' })
  })

  it('remove soft-deletes (hidden, kept in export), purge removes only after 30 days, import merges without overwriting newer', async () => {
    const dl = make()
    const keep = await dl.items.add({ title: 'keep', type: 'task', date: '2026-11-04' })
    const gone = await dl.items.add({ title: 'gone', type: 'task', date: '2026-11-04' })
    await dl.items.remove(gone.id)
    const seen = await new Promise<Item[]>((res) => dl.items.subscribe(res))
    expect(seen.map((i) => i.title)).toEqual(['keep'])
    const exp = await dl.exportAll()
    expect(exp.items.find((i) => i.id === gone.id)?.deletedAt).toBeTruthy()
    expect(await dl.purgeDeleted(Date.now() + 29 * 86400000)).toBe(0)
    expect(await dl.purgeDeleted(Date.now() + 31 * 86400000)).toBe(1)
    // an older backup copy of "keep" must not overwrite the newer edit; a backup-only record is added
    await dl.items.update(keep.id, { title: 'keep edited' })
    const old = { ...exp, items: [{ ...exp.items.find((i) => i.id === keep.id)!, title: 'keep OLD', updatedAt: 1 }, { ...exp.items[0], id: 'x', title: 'from backup', updatedAt: 1, deletedAt: null }] }
    const sum = await dl.importMerge(old)
    expect(sum.items).toEqual({ added: 1, updated: 0, skipped: 1 })
    const titles = (await dl.exportAll()).items.map((i) => i.title).sort()
    expect(titles).toEqual(['from backup', 'keep edited'])
  })
})
