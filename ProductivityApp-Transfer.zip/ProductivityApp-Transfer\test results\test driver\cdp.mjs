// Tiny Chrome DevTools Protocol driver: node cdp.mjs <outPrefix> <url> [steps.json]
// steps: array of {eval: "js"} | {wait: ms} | {shot: "name"} | {click: "css selector"} | {type: [selector, text]}
import { spawn } from 'node:child_process'
import { readFileSync, writeFileSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const [, , outPrefix, url, stepsFile] = process.argv
const steps = stepsFile ? JSON.parse(readFileSync(stepsFile, 'utf8')) : [{ wait: 1500 }, { shot: 'main' }]
const edge = `${process.env['ProgramFiles(x86)']}\\Microsoft\\Edge\\Application\\msedge.exe`
const port = 9333
const profile = mkdtempSync(join(tmpdir(), 'cdp-'))
const proc = spawn(edge, [
  '--headless=new', '--disable-gpu', `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`,
  '--window-size=900,920', 'about:blank',
], { stdio: 'ignore' })

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
let targets
for (let i = 0; i < 50; i++) {
  try { targets = await (await fetch(`http://127.0.0.1:${port}/json`)).json(); if (targets.find((t) => t.type === 'page')) break } catch {}
  await sleep(200)
}
const page = targets.find((t) => t.type === 'page')
const ws = new WebSocket(page.webSocketDebuggerUrl)
await new Promise((r) => (ws.onopen = r))
let id = 0
const pending = new Map()
const logs = []
ws.onmessage = (m) => {
  const msg = JSON.parse(m.data)
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id) }
  if (msg.method === 'Runtime.consoleAPICalled') logs.push(`${msg.params.type}: ${msg.params.args.map((a) => a.value ?? a.description).join(' ')}`)
  if (msg.method === 'Runtime.exceptionThrown') logs.push(`EXCEPTION: ${msg.params.exceptionDetails.exception?.description ?? msg.params.exceptionDetails.text}`)
}
const send = (method, params = {}) => new Promise((res) => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params })) })
const evalJs = async (expression) => (await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true })).result?.result?.value

await send('Runtime.enable'); await send('Page.enable')
await send('Emulation.setDeviceMetricsOverride', { width: 900, height: 920, deviceScaleFactor: 1, mobile: false })
await send('Page.navigate', { url })
await sleep(1500)
for (const s of steps) {
  if (s.wait) await sleep(s.wait)
  if (s.eval) console.log('eval ->', JSON.stringify(await evalJs(s.eval)))
  if (s.click) console.log('click', s.click, await evalJs(`(()=>{const e=document.querySelector(${JSON.stringify(s.click)});if(!e)return 'NOT FOUND';e.click();return 'ok'})()`))
  if (s.type) {
    const [sel, text] = s.type
    console.log('type', sel, await evalJs(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return 'NOT FOUND';const set=Object.getOwnPropertyDescriptor(e.constructor.prototype,'value').set;set.call(e,${JSON.stringify(text)});e.dispatchEvent(new Event('input',{bubbles:true}));return 'ok'})()`))
  }
  if (s.cdp) { const r = await send(s.cdp[0], s.cdp[1] || {}); console.log('cdp', s.cdp[0], JSON.stringify(r.error ?? 'ok')) }
  if (s.mclick) {
    const [sel, dx, dy] = s.mclick
    const r = await evalJs(`(()=>{const b=document.querySelector(${JSON.stringify(sel)}).getBoundingClientRect();return [b.x+${dx},b.y+${dy}]})()`)
    for (const type of ['mouseMoved','mousePressed','mouseReleased']) await send('Input.dispatchMouseEvent', { type, x: r[0], y: r[1], button: 'left', buttons: type === 'mousePressed' ? 1 : 0, clickCount: 1 })
    await sleep(400)
    console.log('mclick', sel, JSON.stringify(r))
  }
  if (s.drag) {
    const [from, to] = s.drag
    const pos = async (sel) => await evalJs(`(()=>{const r=document.querySelector(${JSON.stringify(sel)}).getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]})()`)
    const [x1, y1] = await pos(from); const [x2, y2] = await pos(to)
    const mouse = (type, x, y) => send('Input.dispatchMouseEvent', { type, x, y, button: 'left', buttons: type === 'mouseReleased' ? 0 : 1, clickCount: 1 })
    await mouse('mouseMoved', x1, y1); await mouse('mousePressed', x1, y1)
    for (let i = 1; i <= 12; i++) { await mouse('mouseMoved', x1, y1 + ((y2 - y1) * i) / 12); await sleep(30) }
    await mouse('mouseReleased', x2, y2); await sleep(400)
    console.log('drag', from, '->', to)
  }
  if (s.shot) {
    const r = await send('Page.captureScreenshot', { format: 'png' })
    writeFileSync(`${outPrefix}-${s.shot}.png`, Buffer.from(r.result.data, 'base64'))
    console.log('shot', s.shot)
  }
}
console.log('console:', logs.slice(0, 20).join('\n'))
ws.close(); proc.kill()
process.exit(0)
