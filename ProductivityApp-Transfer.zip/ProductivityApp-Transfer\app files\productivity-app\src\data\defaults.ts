import { browserTimezone } from '../lib/dates'
import type { Item, ListEntry, NewItem, Settings } from '../types'

export const ORDER_GAP = 1000

export function defaultSettings(): Settings {
  return {
    timezone: browserTimezone(),
    defaultEventReminderMinutes: 60,
    digestEnabled: true,
    digestTime: '09:00',
    weekStartsOn: 'monday',
  }
}

export function makeItem(input: NewItem, now: number = Date.now()): Item {
  return {
    id: crypto.randomUUID(),
    startTime: null,
    endTime: null,
    notes: '',
    done: false,
    doneAt: null,
    repeat: null,
    completedOccurrences: {},
    skippedDates: [],
    // Reminder UI is hidden until Phase 2; the field keeps its defaults.
    reminder:
      input.type === 'event'
        ? { enabled: true, minutesBefore: 60 }
        : { enabled: false, minutesBefore: 0 },
    ...input,
    createdAt: now,
    updatedAt: now,
  }
}

export function makeListEntry(title: string, notes: string, order: number, now: number = Date.now()): ListEntry {
  return { id: crypto.randomUUID(), title, notes, done: false, doneAt: null, createdAt: now, updatedAt: now, order }
}

/** Order value for a new entry placed at the bottom. */
export function nextOrder(existing: ListEntry[]): number {
  return existing.reduce((max, e) => Math.max(max, e.order), 0) + ORDER_GAP
}
