import { describe, expect, it } from 'vitest'
import { makeItem } from '../data/defaults'
import { computeBusy, busyForDay } from './busy'
import { occurrencesByDate } from './schedule'
import { convertWall, zonedToInstant } from './tz'

const ET = 'America/New_York'
const CT = 'America/Chicago'

describe('timezone anchoring', () => {
  it('9:00 entered under Central shows 10:00 when viewed in Eastern; wall time is stored in the item zone', () => {
    expect(convertWall('2026-11-05', '09:00', CT, ET)).toEqual({ date: '2026-11-05', time: '10:00' })
    const ev = makeItem({ title: 'x', type: 'event', date: '2026-11-05', startTime: '09:00', endTime: '10:00', tz: CT }, 1)
    const [occ] = occurrencesByDate([ev], '2026-11-05', '2026-11-05', ET).get('2026-11-05')!
    expect([occ.startTime, occ.endTime, occ.srcDate]).toEqual(['10:00', '11:00', '2026-11-05'])
  })

  it('date rolls over in the viewing zone and recurrence keeps wall time across a DST change', () => {
    // 11:30pm Central Sat Oct 31 = 12:30am Eastern Sun Nov 1 (weekly). Phoenix has no DST, so viewing a Chicago
    // event from there shows the one-hour shift when US DST ends (Nov 1).
    const ev = makeItem({ title: 'x', type: 'event', date: '2026-10-31', startTime: '23:30', tz: CT, repeat: { freq: 'weekly' } }, 1)
    const map = occurrencesByDate([ev], '2026-10-31', '2026-11-14', ET)
    expect([...map.keys()]).toEqual(['2026-11-01', '2026-11-08'])
    expect(map.get('2026-11-01')![0].srcDate).toBe('2026-10-31')
    const phx = occurrencesByDate([ev], '2026-10-31', '2026-11-14', 'America/Phoenix')
    expect(phx.get('2026-10-31')![0].startTime).toBe('21:30') // CDT (UTC-5) vs MST (UTC-7)
    expect(phx.get('2026-11-07')![0].startTime).toBe('22:30') // after CDT ends: CST (UTC-6)
  })

  it('busy output is absolute instants and day slices use the viewing zone', () => {
    const ev = makeItem({ title: 'x', type: 'event', date: '2026-11-05', startTime: '09:00', endTime: '10:00', tz: CT }, 1)
    const busy = computeBusy([ev], 'me', '2026-11-05', ET)
    expect(busy).toEqual([{ userId: 'me', start: zonedToInstant('2026-11-05', '10:00', ET), end: zonedToInstant('2026-11-05', '11:00', ET) }])
    expect(busyForDay(busy, '2026-11-05', ET)).toEqual([{ userId: 'me', start: 600, end: 660 }])
    expect(busyForDay(busy, '2026-11-05', CT)).toEqual([{ userId: 'me', start: 540, end: 600 }])
  })
})
