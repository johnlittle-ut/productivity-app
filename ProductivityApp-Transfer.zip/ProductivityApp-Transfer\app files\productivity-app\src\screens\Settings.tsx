import { useMemo, useRef, useState } from 'react'
import { Sheet } from '../components/Dialogs'
import { dataLayer } from '../data'
import { setDone, setEntryDone } from '../data/actions'
import { parseExport } from '../data/exportFormat'
import { useItems, useSettings, useShopping, useTodos } from '../data/hooks'
import { INTERACTIVE_ENABLED } from '../lib/flags'
import { mergeRecords } from '../lib/merge'
import { DAY_MS, recentlyCompleted } from '../lib/completion'
import { recentEntries } from '../lib/order'
import { browserTimezone, todayIn } from '../lib/dates'
import { itemText, shortDate } from '../lib/format'
import { convertWall } from '../lib/tz'
import type { Item } from '../types'
import { DevSection } from './DevSection'

/** An item's start time on `date` shown in the viewing zone. */
function viewTime(item: Item, date: string, tz: string): string | null {
  return item.startTime && item.tz ? convertWall(date, item.startTime, item.tz, tz).time : item.startTime
}

function zoneList(extra?: string | null): string[] {
  const zones = Intl.supportedValuesOf('timeZone')
  return extra && !zones.includes(extra) ? [extra, ...zones] : zones
}

export function Settings({ onUndone }: { onUndone?: () => void }) {
  const settings = useSettings()
  const items = useItems()
  const shopping = useShopping()
  const todos = useTodos()
  const [openedAt] = useState(() => Date.now())
  const recent = useMemo(() => recentlyCompleted(items, openedAt), [items, openedAt])
  const recentLists = useMemo(
    () => [
      ...recentEntries(shopping, openedAt, DAY_MS).map((entry) => ({ kind: 'shopping' as const, entry })),
      ...recentEntries(todos, openedAt, DAY_MS).map((entry) => ({ kind: 'todos' as const, entry })),
    ],
    [shopping, todos, openedAt],
  )
  const fileInput = useRef<HTMLInputElement>(null)
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null)

  const [showRecent, setShowRecent] = useState(false)

  if (!settings) return <p className="muted">Loading…</p>

  async function exportJson() {
    const file = await dataLayer.exportAll()
    const blob = new Blob([JSON.stringify(file, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `productivity-backup-${todayIn(settings!.timezone)}.json`
    a.click()
    URL.revokeObjectURL(url)
    setMessage({ kind: 'ok', text: 'Backup downloaded.' })
  }

  async function importJson(file: File) {
    const result = parseExport(await file.text())
    if (!result.ok) {
      setMessage({ kind: 'error', text: result.error })
      return
    }
    // Merge by id: the newest edit wins, so an older backup never overwrites newer changes. Show counts first.
    const current = await dataLayer.exportAll()
    const count = (a: { id: string; updatedAt: number }[], b: { id: string; updatedAt: number }[]) => {
      const { added, updated, skipped } = mergeRecords(a, b)
      return { added, updated, skipped }
    }
    const parts = [
      count(current.items, result.file.items),
      count(current.shoppingItems, result.file.shoppingItems),
      count(current.todos, result.file.todos),
    ]
    const sum = (k: 'added' | 'updated' | 'skipped') => parts.reduce((n, p) => n + p[k], 0)
    const text = `${sum('added')} added, ${sum('updated')} updated, ${sum('skipped')} skipped (older than what you have)`
    if (!window.confirm(`Merge this backup into your data?\n\n${text}`)) return
    try {
      await dataLayer.importMerge(result.file)
      setMessage({ kind: 'ok', text: `Backup merged: ${text}.` })
    } catch (e) {
      console.error('Import failed', e)
      setMessage({ kind: 'error', text: 'Could not restore that backup. Your current data was not changed.' })
    }
  }

  return (
    <div className="settings">
      <section className="card">
        <h2>Appearance</h2>
        <div className="segmented three" role="group" aria-label="Appearance">
          {(['system', 'light', 'dark'] as const).map((t) => (
            <button
              key={t}
              className={(settings.theme ?? 'system') === t ? 'on plain' : ''}
              onClick={() => void dataLayer.settings.update({ theme: t })}
            >
              {t === 'system' ? 'System' : t === 'light' ? 'Light' : 'Dark'}
            </button>
          ))}
        </div>
      </section>

      <section className="card">
        <h2>Time</h2>
        <div className="segmented" role="group" aria-label="Time format">
          {(['12', '24'] as const).map((f) => (
            <button
              key={f}
              className={(settings.timeFormat ?? '12') === f ? 'on plain' : ''}
              onClick={() => void dataLayer.settings.update({ timeFormat: f })}
            >
              {f}-hour
            </button>
          ))}
        </div>
        <select
          className="input"
          aria-label="Timezone"
          value={settings.timezoneOverride ?? ''}
          onChange={(e) => void dataLayer.settings.update({ timezoneOverride: e.target.value || null })}
        >
          <option value="">Automatic (device: {browserTimezone()})</option>
          {zoneList(settings.timezoneOverride).map((z) => (
            <option key={z} value={z}>
              {z.replace(/_/g, ' ')}
            </option>
          ))}
        </select>
        <p className="muted small">Timed items keep their own zone and show converted to the zone above.</p>
      </section>

      <section className="card">
        <h2>Text size</h2>
        <input
          type="range"
          className="size-slider"
          min={85}
          max={130}
          step={5}
          value={settings.textSize ?? 100}
          aria-label="Text size"
          onChange={(e) => void dataLayer.settings.update({ textSize: Number(e.target.value) })}
        />
        <p className="muted small">
          {settings.textSize ?? 100}% of normal
          {(settings.textSize ?? 100) !== 100 && (
            <>
              {' · '}
              <button className="link-btn" onClick={() => void dataLayer.settings.update({ textSize: 100 })}>
                Reset
              </button>
            </>
          )}
        </p>
      </section>

      <section className="card">
        <h2>Default tab on open</h2>
        <select
          className="input"
          value={settings.defaultTab ?? 'schedule'}
          aria-label="Default tab on open"
          onChange={(e) => void dataLayer.settings.update({ defaultTab: e.target.value as NonNullable<typeof settings.defaultTab> })}
        >
          <option value="calendar">Calendar</option>
          <option value="schedule">Schedule</option>
          <option value="todo">To-Do</option>
          <option value="shopping">Shopping</option>
          {INTERACTIVE_ENABLED && <option value="interactive">Interactive</option>}
        </select>
      </section>

      <section className="card">
        <button className="btn wide" onClick={() => setShowRecent(true)}>
          Recently completed ({recent.length + recentLists.length})
        </button>
        <p className="muted small recent-hint">Checked-off items are removed after 24 hours. Open this to undo one.</p>
      </section>

      {showRecent && (
        <Sheet title="Recently completed" onCancel={() => setShowRecent(false)}>
          {recent.length === 0 && recentLists.length === 0 ? (
            <p className="muted">Nothing checked off in the last 24 hours.</p>
          ) : (
            <ul className="recent-list">
              {recent.map(({ item, date }) => (
                <li key={`${item.id}:${date}`}>
                  <span>
                    {itemText(item.title, viewTime(item, date, settings.timezone))} <span className="muted small">({shortDate(date)})</span>
                  </span>
                  <button
                    className="link-btn"
                    onClick={() => {
                      void setDone(item, date, false)
                      onUndone?.()
                    }}
                  >
                    Undo
                  </button>
                </li>
              ))}
              {recentLists.map(({ kind, entry }) => (
                <li key={`${kind}:${entry.id}`}>
                  <span>
                    {entry.title} <span className="muted small">({kind === 'shopping' ? 'shopping' : 'to-do'})</span>
                  </span>
                  <button
                    className="link-btn"
                    onClick={() => {
                      void setEntryDone(kind, entry, false)
                      onUndone?.()
                    }}
                  >
                    Undo
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Sheet>
      )}

      <section className="card">
        <h2>Backup</h2>
        <div className="row">
          <button className="btn" onClick={exportJson}>
            Export JSON
          </button>
          <button className="btn" onClick={() => fileInput.current?.click()}>
            Import JSON
          </button>
        </div>
        <input
          ref={fileInput}
          type="file"
          accept="application/json,.json"
          hidden
          onChange={(e) => {
            const f = e.target.files?.[0]
            e.target.value = ''
            if (f) void importJson(f)
          }}
        />
        {message && (
          <p className={message.kind === 'error' ? 'small error' : 'small'} role="status">
            {message.text}
          </p>
        )}
      </section>

      {import.meta.env.DEV && <DevSection settings={settings} />}
    </div>
  )
}
