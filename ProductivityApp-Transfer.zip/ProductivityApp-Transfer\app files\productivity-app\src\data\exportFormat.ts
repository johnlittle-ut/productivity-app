import { EXPORT_VERSION } from '../types'
import type { ExportFile } from '../types'

export type ParseResult = { ok: true; file: ExportFile } | { ok: false; error: string }

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)
const isStr = (v: unknown): v is string => typeof v === 'string'
const DATE = /^\d{4}-\d{2}-\d{2}$/
const TIME = /^\d{2}:\d{2}$/

function validItem(v: unknown): boolean {
  if (!isObj(v)) return false
  return (
    isStr(v.id) &&
    isStr(v.title) &&
    (v.type === 'event' || v.type === 'task') &&
    isStr(v.date) &&
    DATE.test(v.date) &&
    (v.startTime === null || (isStr(v.startTime) && TIME.test(v.startTime))) &&
    (v.endTime === null || (isStr(v.endTime) && TIME.test(v.endTime))) &&
    (v.repeat === null || (isObj(v.repeat) && (v.repeat.freq === 'weekly' || v.repeat.freq === 'monthly'))) &&
    isObj(v.completedOccurrences) &&
    Array.isArray(v.skippedDates)
  )
}

function validEntry(v: unknown): boolean {
  return isObj(v) && isStr(v.id) && isStr(v.title) && typeof v.order === 'number' && typeof v.done === 'boolean'
}

/** Parse and validate the text of an exported JSON file. */
export function parseExport(text: string): ParseResult {
  let data: unknown
  try {
    data = JSON.parse(text)
  } catch {
    return { ok: false, error: 'That file is not valid JSON.' }
  }
  if (!isObj(data)) return { ok: false, error: 'That file is not a backup from this app.' }
  if (typeof data.version !== 'number') return { ok: false, error: 'That file has no version number, so it is not a backup from this app.' }
  if (data.version > EXPORT_VERSION) {
    return { ok: false, error: 'That backup was made by a newer version of the app.' }
  }
  if (!Array.isArray(data.items) || !Array.isArray(data.shoppingItems) || !Array.isArray(data.todos) || !isObj(data.settings)) {
    return { ok: false, error: 'That backup is missing some data.' }
  }
  if (!data.items.every(validItem)) return { ok: false, error: 'Some calendar items in that file are damaged.' }
  if (!data.shoppingItems.every(validEntry) || !data.todos.every(validEntry)) {
    return { ok: false, error: 'Some list entries in that file are damaged.' }
  }
  // Old backups have no updatedAt: fall back to createdAt (or 0)
  const stamp = <T extends object>(r: T): T & { updatedAt: number } => {
    const o = r as { updatedAt?: number; createdAt?: number }
    return { ...r, updatedAt: typeof o.updatedAt === 'number' ? o.updatedAt : (o.createdAt ?? 0) }
  }
  const file = data as unknown as ExportFile
  return {
    ok: true,
    file: {
      ...file,
      items: file.items.map(stamp),
      shoppingItems: file.shoppingItems.map(stamp),
      todos: file.todos.map(stamp),
      settings: { ...file.settings, updatedAt: file.settings.updatedAt ?? 0 },
    },
  }
}
