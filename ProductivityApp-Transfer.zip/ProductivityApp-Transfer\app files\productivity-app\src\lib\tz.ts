// Timezone math with Intl only. Timed items are stored as wall-clock in their own IANA zone (`item.tz`);
// these helpers convert wall-clock <-> absolute instants (epoch ms) and between zones.

import { addDays, parseDate } from './dates'

const dtfs = new Map<string, Intl.DateTimeFormat>()
function formatter(tz: string): Intl.DateTimeFormat {
  let f = dtfs.get(tz)
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: tz,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23',
    })
    dtfs.set(tz, f)
  }
  return f
}

function wallParts(ms: number, tz: string) {
  const p: Record<string, number> = {}
  for (const part of formatter(tz).formatToParts(new Date(ms))) if (part.type !== 'literal') p[part.type] = Number(part.value)
  return p
}

/** Wall-clock in `tz` at instant `ms`, as 'YYYY-MM-DD' and 'HH:mm'. */
export function instantToWall(ms: number, tz: string): { date: string; time: string } {
  const p = wallParts(ms, tz)
  const pad = (n: number) => String(n).padStart(2, '0')
  return { date: `${String(p.year).padStart(4, '0')}-${pad(p.month)}-${pad(p.day)}`, time: `${pad(p.hour)}:${pad(p.minute)}` }
}

/** The instant (epoch ms) at which `tz` shows the wall-clock `date` + `hhmm`. In a DST gap this lands just after it. */
export function zonedToInstant(date: string, hhmm: string, tz: string): number {
  const { y, m, d } = parseDate(date)
  const [h, mi] = hhmm.split(':').map(Number)
  const wallUtc = Date.UTC(y, m - 1, d, h, mi)
  const offset = (t: number) => {
    const p = wallParts(t, tz)
    return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute) - t
  }
  let t = wallUtc - offset(wallUtc)
  t = wallUtc - offset(t)
  return t
}

/** Convert a wall-clock date+time from one zone to another. */
export function convertWall(date: string, hhmm: string, from: string, to: string): { date: string; time: string } {
  return from === to ? { date, time: hhmm } : instantToWall(zonedToInstant(date, hhmm, from), to)
}

/** Instants [start, end) of a calendar day in `tz` (handles 23/25-hour days). */
export function dayBounds(date: string, tz: string): { start: number; end: number } {
  return { start: zonedToInstant(date, '00:00', tz), end: zonedToInstant(addDays(date, 1), '00:00', tz) }
}
