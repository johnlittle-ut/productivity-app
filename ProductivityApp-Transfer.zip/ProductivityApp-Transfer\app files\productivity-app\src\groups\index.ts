// The one place the app picks its group-layer implementation (mock now, Firestore in the backend phase).

import { createMockGroupLayer } from './mockLayer'
import type { GroupLayer, MockControls } from './layer'

export const groupLayer: GroupLayer & MockControls = createMockGroupLayer()
export type { GroupLayer } from './layer'
