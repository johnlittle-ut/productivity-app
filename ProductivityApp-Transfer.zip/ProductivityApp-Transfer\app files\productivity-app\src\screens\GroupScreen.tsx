// One group: an availability grid (one lane per member, busy blocks only), "everyone free" bands, and group events.

import { useEffect, useMemo, useRef, useState } from 'react'
import { Avatar } from '../components/Avatar'
import { ChoiceDialog, Sheet } from '../components/Dialogs'
import { GroupEventForm } from '../components/GroupEventForm'
import { createGroupEvent } from '../groups/actions'
import { useAllGroupEvents, useGroupBusy, useMembers } from '../groups/hooks'
import { groupLayer } from '../groups/index'
import { groupColorVar, type Group, type GroupEvent } from '../groups/model'
import { busyForDay, DAY_END_MIN, DAY_START_MIN, freeRanges, myBlocks, type MyBlock } from '../lib/busy'
import { dataLayer } from '../data'
import type { Item } from '../types'
import { addDays, dayOfWeek, weekStart } from '../lib/dates'
import { formatTimeShort, longDate, weekRangeLabel } from '../lib/format'
import { layoutBlocks, MINUTES_PER_DAY, toMinutes } from '../lib/gridLayout'
import { swipeDirection } from '../lib/swipe'
import { BackIcon, GearIcon } from '../components/icons'

const LETTERS = ['S', 'M', 'T', 'W', 'T', 'F', 'S']
const HOUR_PX = 48
const GRID_PX = (MINUTES_PER_DAY / 60) * HOUR_PX
const HOURS = Array.from({ length: 24 }, (_, h) => h)
const hourLabel = (h: number) => (h === 0 ? '' : h < 12 ? `${h} AM` : h === 12 ? '12 PM' : `${h - 12} PM`)

interface Props {
  group: Group
  items: Item[]
  tz: string
  today: string
  onBack: () => void
  onSettings: () => void
}

const STATUS_LABEL = { accepted: 'Accepted', declined: 'Declined', pending: 'Pending' } as const

function EventDetail({
  event,
  group,
  onEdit,
  onClose,
}: {
  event: GroupEvent
  group: Group
  onEdit: () => void
  onClose: () => void
}) {
  const members = useMembers()
  const [confirming, setConfirming] = useState(false)
  const mine = event.creatorId === groupLayer.me.id
  const nameOf = (id: string) => (id === groupLayer.me.id ? 'You' : (members.find((m) => m.id === id)?.name ?? id))
  return (
    <>
      <Sheet title="Group event" onCancel={onClose}>
        <h2 className="detail-title" style={{ color: groupColorVar(group.color) }}>
          {event.title}
        </h2>
        <p className="muted">
          {longDate(event.date)}, {formatTimeShort(event.startTime)} – {formatTimeShort(event.endTime)}
        </p>
        <p className="small muted">Created by {nameOf(event.creatorId)}</p>
        {event.notes && <p>{event.notes}</p>}
        <h3 className="detail-sub">Responses</h3>
        <ul className="response-list">
          {group.memberIds.map((id) => (
            <li key={id}>
              <span>{nameOf(id)}</span>
              <span className={`status ${event.responses[id] ?? 'pending'}`}>{STATUS_LABEL[event.responses[id] ?? 'pending']}</span>
            </li>
          ))}
        </ul>
        {mine && !event.cancelled && (
          <div className="row detail-actions">
            <button className="btn" onClick={onEdit}>
              Edit
            </button>
            <button className="btn danger" onClick={() => setConfirming(true)}>
              Cancel event
            </button>
          </div>
        )}
      </Sheet>
      {confirming && (
        <ChoiceDialog<'cancel'>
          title="Cancel this event?"
          message="It is removed from everyone's calendar."
          choices={[{ label: 'Cancel event', value: 'cancel', danger: true }]}
          onChoose={async () => {
            await groupLayer.events.cancel(event.id)
            setConfirming(false)
            onClose()
          }}
          onCancel={() => setConfirming(false)}
        />
      )}
    </>
  )
}

export function GroupScreen({ group, items, tz, today, onBack, onSettings }: Props) {
  const [selected, setSelected] = useState(today)
  const members = useMembers()
  const busy = useGroupBusy(group.id)
  const allEvents = useAllGroupEvents()
  const [adding, setAdding] = useState<{ startTime: string } | null>(null)
  const [viewing, setViewing] = useState<string | null>(null)
  const [editing, setEditing] = useState<GroupEvent | null>(null)
  const [mine, setMine] = useState<MyBlock | null>(null)
  const myDay = useMemo(() => myBlocks(items, today, tz).filter((b) => b.date === selected), [items, today, tz, selected])

  const lanes = useMemo(() => group.memberIds.map((id) => members.find((m) => m.id === id)).filter((m) => !!m), [group, members])
  const n = Math.max(lanes.length, 1)

  const start = weekStart(selected)
  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(start, i)), [start])

  const dayBusy = useMemo(() => busyForDay(busy, selected, tz), [busy, selected, tz])
  const free = useMemo(() => freeRanges(dayBusy, DAY_START_MIN, DAY_END_MIN, 30), [dayBusy])

  const dayEvents = useMemo(
    () => (allEvents ?? []).filter((e) => e.groupId === group.id && e.date === selected && !e.cancelled),
    [allEvents, group.id, selected],
  )
  const placed = useMemo(() => {
    const layout = new Map(
      layoutBlocks(dayEvents.map((e) => ({ key: e.id, start: toMinutes(e.startTime), end: toMinutes(e.endTime) }))).map((b) => [b.key, b]),
    )
    return dayEvents.map((e) => ({ e, box: layout.get(e.id)! }))
  }, [dayEvents])
  const viewingEvent = (allEvents ?? []).find((e) => e.id === viewing) ?? null

  const gridRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (gridRef.current) gridRef.current.scrollTop = 7 * HOUR_PX
  }, [selected])

  const touch = useRef<{ x: number; y: number } | null>(null)

  function onGridClick(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect()
    const hour = Math.min(23, Math.max(0, Math.floor((e.clientY - rect.top) / HOUR_PX)))
    setAdding({ startTime: `${String(hour).padStart(2, '0')}:00` })
  }

  const colW = `((100% - var(--gutter-w)) / ${n})`
  const defaultEnd = (startTime: string) => {
    const end = Math.min(toMinutes(startTime) + 60, 23 * 60 + 59)
    return `${String(Math.floor(end / 60)).padStart(2, '0')}:${String(end % 60).padStart(2, '0')}`
  }

  return (
    <div
      className="group-screen"
      onTouchStart={(e) => (touch.current = { x: e.touches[0].clientX, y: e.touches[0].clientY })}
      onTouchEnd={(e) => {
        const t = touch.current
        touch.current = null
        if (!t) return
        const dir = swipeDirection(e.changedTouches[0].clientX - t.x, e.changedTouches[0].clientY - t.y)
        if (dir !== 0) setSelected(addDays(selected, dir === -1 ? 1 : -1))
      }}
    >
      <div className="sub-head">
        <button className="icon-btn" onClick={onBack} aria-label="Back to groups">
          <BackIcon />
        </button>
        <h2 style={{ color: groupColorVar(group.color) }}>{group.name}</h2>
        <button className="icon-btn" onClick={onSettings} aria-label="Group settings">
          <GearIcon />
        </button>
      </div>

      <div className="cal-head">
        <button className="icon-btn" onClick={() => setSelected(addDays(selected, -1))} aria-label="Previous day">
          ‹
        </button>
        <div className="cal-range">{weekRangeLabel(start, addDays(start, 6))}</div>
        <button className="icon-btn" onClick={() => setSelected(addDays(selected, 1))} aria-label="Next day">
          ›
        </button>
        <button className="btn today-btn" onClick={() => setSelected(today)} disabled={selected === today}>
          Today
        </button>
      </div>

      <div className="week-strip" role="tablist" aria-label="Days of the week">
        {days.map((date) => (
          <button
            key={date}
            role="tab"
            aria-selected={date === selected}
            className={`strip-day${date === selected ? ' selected' : ''}${date === today ? ' is-today' : ''}`}
            onClick={() => setSelected(date)}
          >
            <span className="strip-letter">{LETTERS[dayOfWeek(date)]}</span>
            <span className="strip-num">{Number(date.slice(8))}</span>
            <span className="strip-dots" />
          </button>
        ))}
      </div>

      <div className="group-bar">
        <h3 className="agenda-title">{longDate(selected)}</h3>
        <button
          className="btn primary small-btn"
          onClick={() => setAdding({ startTime: '18:00' })}
        >
          Add group event
        </button>
      </div>

      <div className="lane-head" style={{ paddingLeft: 'var(--gutter-w)' }}>
        {lanes.map((m) => (
          <div key={m.id} className="lane-label">
            <Avatar member={m} size={26} />
            <span>{m.id === groupLayer.me.id ? 'You' : m.name.split(' ')[0]}</span>
          </div>
        ))}
      </div>

      <div className="time-grid" ref={gridRef}>
        <div className="grid-body" style={{ height: GRID_PX }} onClick={onGridClick}>
          {HOURS.map((h) => (
            <div key={h} className="hour-row" style={{ top: h * HOUR_PX, height: HOUR_PX }}>
              <span className="hour-label">{hourLabel(h)}</span>
            </div>
          ))}

          {free.map((r) => (
            <div
              key={r.start}
              className="free-band"
              style={{ top: (r.start / 60) * HOUR_PX, height: ((r.end - r.start) / 60) * HOUR_PX }}
            >
              <span>Everyone free</span>
            </div>
          ))}

          {lanes.map((m, i) => (
            <div
              key={m.id}
              className="lane"
              style={{ left: `calc(var(--gutter-w) + ${colW} * ${i})`, width: `calc(${colW})` }}
            >
              {i > 0 && <i className="lane-line" />}
              {m.id === groupLayer.me.id &&
                myDay.map((b) => (
                  <button
                    key={`${b.itemId}-${b.start}`}
                    className={`busy-block mine${b.hidden ? ' hidden-block' : ''}`}
                    style={{
                      top: (b.start / 60) * HOUR_PX,
                      height: Math.max(((b.end - b.start) / 60) * HOUR_PX, 14),
                      background: groupColorVar(m.color),
                    }}
                    onClick={(e) => {
                      e.stopPropagation()
                      setMine(b)
                    }}
                    aria-label={`${b.title}${b.hidden ? ' (hidden from groups)' : ''}`}
                  >
                    {b.title}
                  </button>
                ))}
              {dayBusy
                .filter((b) => b.userId === m.id && m.id !== groupLayer.me.id)
                .map((b) => (
                  <div
                    key={`${b.start}-${b.end}`}
                    className="busy-block"
                    style={{
                      top: (b.start / 60) * HOUR_PX,
                      height: Math.max(((b.end - b.start) / 60) * HOUR_PX, 4),
                      background: groupColorVar(m.color),
                    }}
                    aria-label={`${m.name} busy`}
                  />
                ))}
            </div>
          ))}

          {placed.map(({ e, box }) => {
            const w = `calc((100% - var(--gutter-w)) / ${box.cols})`
            return (
              <button
                key={e.id}
                className="group-event-block"
                style={{
                  top: (box.start / 60) * HOUR_PX,
                  height: Math.max(((box.end - box.start) / 60) * HOUR_PX - 2, 22),
                  width: w,
                  left: `calc(var(--gutter-w) + ${w} * ${box.col})`,
                  borderColor: groupColorVar(group.color),
                  background: `color-mix(in srgb, ${groupColorVar(group.color)} 35%, var(--bg))`,
                }}
                onClick={(ev) => {
                  ev.stopPropagation()
                  setViewing(e.id)
                }}
              >
                <strong>{e.title}</strong>
                <span>
                  {formatTimeShort(e.startTime)} – {formatTimeShort(e.endTime)}
                </span>
              </button>
            )
          })}
        </div>
      </div>

      {mine && (
        <Sheet title={mine.title} onCancel={() => setMine(null)}>
          <p className="muted">
            {formatTimeShort(`${String(Math.floor(mine.start / 60)).padStart(2, '0')}:${String(mine.start % 60).padStart(2, '0')}`)} ·{' '}
            {mine.hidden ? 'Hidden from all your groups.' : 'Group members see this time as busy (no title).'}
            {mine.repeats && ' Applies to every repeat.'}
          </p>
          <button
            className="btn wide"
            onClick={() => {
              void dataLayer.items.update(mine.itemId, { hideFromGroups: !mine.hidden })
              setMine(null)
            }}
          >
            {mine.hidden ? 'Show in group view' : 'Remove from group view'}
          </button>
        </Sheet>
      )}

      {adding && (
        <GroupEventForm
          mode="add"
          lanes={lanes}
          busy={busy}
          meId={groupLayer.me.id}
          tz={tz}
          initial={{ title: '', date: selected, startTime: adding.startTime, endTime: defaultEnd(adding.startTime), notes: '' }}
          onClose={() => setAdding(null)}
          onSave={async (input) => {
            await createGroupEvent(group.id, input)
            setAdding(null)
            setSelected(input.date)
          }}
        />
      )}

      {viewingEvent && !editing && (
        <EventDetail event={viewingEvent} group={group} onClose={() => setViewing(null)} onEdit={() => setEditing(viewingEvent)} />
      )}

      {editing && (
        <GroupEventForm
          mode="edit"
          lanes={lanes}
          busy={busy}
          meId={groupLayer.me.id}
          tz={tz}
          initial={{
            title: editing.title,
            date: editing.date,
            startTime: editing.startTime,
            endTime: editing.endTime,
            notes: editing.notes,
          }}
          onClose={() => setEditing(null)}
          onSave={async (input) => {
            await groupLayer.events.update(editing.id, input)
            setEditing(null)
          }}
        />
      )}
    </div>
  )
}
