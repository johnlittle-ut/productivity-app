# CHANGELOG

Newest entry on top. Maintained by Dan 2 (see `CLAUDE.md`).

## 2026-11-04: Backend prep on the local data layer (Plan.md 3.6, handoff 003 step 4b; via Craig 2)

- **updatedAt everywhere:** items, shopping, to-dos and settings carry `updatedAt`, set only in the Dexie data layer (list `update`/`add`/`remove`, settings `update` is now a partial patch). Legacy rows read as `createdAt` and are backfilled on app open (`purgeDeleted`).
- **Soft delete:** `remove()` sets `deletedAt` + `updatedAt`; subscriptions hide deleted records; records deleted over 30 days ago are purged on app open. The 24h completed-item cleanup uses the same `remove` path.
- **Merge:** pure `mergeRecords` in `lib/merge.ts` (newest `updatedAt` wins, tie keeps existing, returns added/updated/skipped). Import is now a merge by id (`importMerge`), after a confirm showing the counts; settings merge as a whole by `updatedAt`. Exports include `updatedAt`/`deletedAt` (tombstones); old exports still import (`updatedAt` falls back to `createdAt`/0). Replace-all `importAll` kept in the data layer (tests, dev) but no longer used by Settings.
- **Flag:** `VITE_ENABLE_INTERACTIVE` (default on in dev, off in production builds unless `true`) hides the Interactive tab and its Default-tab option (`lib/flags.ts`); tab bar columns now adapt to 4 or 5 tabs.
- Tests (once, 2 new): merge rules; soft delete + 30-day purge + import-merge not overwriting newer. 74 passing; tsc/oxlint clean.

## 2026-11-04: Flexible phone widths 360-430 (John via Craig 2)

- `index.css` only. The phone column is no longer capped at 393px below the desktop breakpoint (full width on 430 phones); desktop stays the 393 x 852 centered frame. Grid hour gutter scales with text size (`2.75rem`) and hour labels no longer wrap ("10 AM" split at 130%). Group screen: date/"Add group event" bar wraps instead of squeezing the button.
- Checked in headless Edge (mobile emulation) at 360x640, 360x800, 375x667, 393x852, 430x700, 430x932, with text size 85%, 100%, 130%: Settings, Calendar Day/Week, Schedule, New task sheet, To-Do, Shopping, Interactive, group grid and New group event sheet. No horizontal overflow, tab bar fits five tabs without clipping, sheets scroll with the Save button pinned. Not tested on real devices.

## 2026-11-04: Interactive tab spacing (John via Craig 2)

- `index.css`: 16px gap below the Invitations section (was 0) and below the New group / Join with link row (was 4px), so the buttons no longer touch the card and "Your groups" is spaced the same with or without invitations. CSS only; measured 16px in headless Edge.

## 2026-11-04: Keep item zone on unchanged save; Recently-completed times in viewing zone (Craig 2 follow-up)

- Saving an edit keeps the item's original `tz` and stored wall-clock unless its date, time or repeat changed; only then it is re-anchored to the current effective zone (`App.tsx` `handleSave`).
- Settings > Recently completed shows start times converted to the viewing zone (`Settings.tsx`).
- No new tests (UI-level logic); tsc and oxlint clean, suite not re-run (no lib changes).

## 2026-11-04: Timezone-anchored items, 12/24h, timezone override, event defaults (John via Craig 2)

- **Anchoring:** timed items carry `tz` (IANA, effective zone at entry); date/start/end are wall-clock in that zone and display converted to the viewing zone (`lib/tz.ts`, Intl only, no new library). All-day items float. `Occurrence` now has view-zone `date`/`startTime`/`endTime` plus `srcDate` (item-zone date: the key for completed/skipped). Recurrence runs in the item's zone; Schedule, Calendar, Overdue, search and move-to-tomorrow bucket by viewing-zone date.
- **Settings:** 12/24-hour (default 12), Timezone "Automatic (device)" or an override (`settings.timezoneOverride`, null = auto); effective zone = override ?? device and is still saved to `settings.timezone`. Legacy timed items without `tz` are stamped once on load with the effective zone.
- **Busy:** `BusyInterval` is now `{userId, start, end}` in epoch ms; `busyForDay` slices to a day in the viewing zone (group grid, scheduling assistant, invite conflict check). Saved mock busy rows are migrated; mock friends' patterns are wall-clock in the device zone.
- **Event defaults:** a new event starts at the next full hour and lasts 1 hour (changing the start keeps the length); empty-slot taps keep their slot.
- **Decisions to confirm:** saving an edit re-anchors the item to the current effective zone (an edit-all of a repeating series from another zone shifts the series anchor accordingly); group events stay wall-clock in the viewer's zone (not zone-anchored), so an accepted copy follows the viewer's zone; "Recently completed" shows item-zone times; `<input type="time">` follows the device locale, not the 12/24 setting.
- Tests (once): Central entry viewed in Eastern, date rollover, recurrence across DST end (Phoenix view), busy instants and day slices (72 passing). Verified in headless Edge: Thrive 6:30pm -> 5:30pm under a Central override, 17:30 in 24h mode.

## 2026-11-04: Swipe to move task, Schedule search, hide events from groups, text size, default tab (John via Craig 2)

- **Swipe right on a task** (Schedule, Overdue, Calendar day list; not events, not grid blocks): "Move to tomorrow" (device-timezone tomorrow) with Undo toast. Repeating task: that occurrence only (skippedDates + one-off copy with `seriesId`/`originalDate`). `planMoveToTomorrow` in `lib/schedule.ts`, `moveToTomorrow` in `data/actions.ts`, pointer-based swipe in `ItemRow`.
- **Search** (Schedule tab only): magnifier in header, expands to a field, collapses on Close/Escape/blur-when-empty. Matches title + notes of upcoming (next 365 days) and overdue, one hit per item, tap opens edit. `searchOccurrences`.
- **Hide from groups**: optional `Item.hideFromGroups`; `computeBusy` skips hidden. Group grid shows my own blocks with titles (`myBlocks`), tap -> "Remove from group view" / "Show in group view" (hidden = dashed/faded). Applies to whole series for repeats. Export compatible (optional field).
- **Settings**: text size slider 85-130% (all CSS font sizes converted px -> rem, scaled from `<html>`; spacing and the time-grid hour heights stay fixed) and "Default tab on open" (default Schedule; mirrored in localStorage so launch has no flash). Both optional `Settings` fields.
- Tests: move-to-tomorrow plan, search, hide-from-groups busy (69 passing). Swipe, search, toast verified in headless Edge with real mouse events; untested on a real iPhone (touch swipe vs. vertical scroll, Calendar day-swipe conflict).

## 2026-11-04: Scheduling assistant for group events; Outlook-style "new event" from an empty slot (John's request)

- **Scheduling assistant** (Outlook's feature) inside the group **New / Edit group event** sheet (`src/components/SchedulingAssistant.tsx`, used by `GroupEventForm`): a compact grid of the chosen day (7 AM to 11 PM) with one lane per member showing their **busy time only**; the proposed start/end as a highlighted band; a status line ("Everyone is free then." or "Busy then: Alex, Sam."); **suggested times** (up to four, half-hour aligned, same length as the event) where everyone is free; tapping a suggestion sets the start and end; tapping the grid moves the start and keeps the length. Changing the date refreshes the lanes. Uses only the published busy intervals, no event details.
- Logic: `suggestSlots` in `src/lib/busy.ts` (one test; suite run once).
- **Empty-slot click** (already opened an add screen in personal Day/Week and the group grid; verified with real mouse clicks): the personal one now behaves like Outlook: the sheet is titled **"New event"** (or "New task" if you switch the type), and the start and a **one-hour end** are prefilled (`App.tsx`, `ItemForm.tsx`). The group grid opens "New group event" at the clicked hour, now with the assistant.
- Not built: drag across the grid to choose a time range, a multi-day "find a time" search, attendee availability for the personal (non-group) event form.
- Not checked on a real iPhone (tap targets in the compact assistant grid).

## 2026-11-04: Black desktop backdrop (John's request via Craig 2)

- The page behind the phone-sized frame on desktop is now solid black in both light and dark themes (`body` background in `src/index.css`); the app inside the frame keeps its theme. The `--bg-outer` variable is no longer used. CSS only; no tests.

## 2026-11-04: Bug fix: old hex group colors still showing (purple dots, backgroundless avatars)

- Cause: saved or in-memory group/member data holding old hex colors produced an invalid `var(--g#…)`, so backgrounds dropped out. My earlier check used a fresh browser profile and missed it.
- Fix: `groupColorVar` now runs every value through `toColorSlot`, so a hex (or anything invalid) can no longer break a color (`model.ts`). `mockLayer.ts` also normalizes group and member colors at read time (`myGroups`, `members.subscribe`) and rewrites the saved mock state once on load so old hex values do not linger.
- Verified with an already-populated profile: seeded the old hex state (`#8e5bf6`, `#16a085`) in localStorage, reloaded in light mode; dots, avatars and the invitation border all resolve to `var(--gN)`, and the stored colors became `[5, 3]`. `tsc` clean; no new tests (the migration test already covers `toColorSlot`).
- If a browser tab was open during the earlier change, a hard refresh also helps.

## 2026-11-04: Off-theme color cleanup: group colors as slots, --good, focus ring (Ava's spec; Craig 2 approved)

- **Group/member colors are now slots 1 to 6** (`GroupColor` in `src/groups/model.ts`) resolved by CSS variables `--g1..--g6` defined per theme in `src/index.css` (light and dark values from `design/color-tokens.md`). Group dots, avatars, group-screen headings, busy blocks, group event blocks, the invitation card border, swatches, and the tint on accepted group events in Schedule/Calendar all use `groupColorVar(slot)`. Data shape change: `Group.color` and `Member.color` are numbers; the GroupLayer `create(name, color)` takes a slot.
- **Migration:** `toColorSlot` maps old hex colors (and the previous palette, including the old "me" blue) to the nearest slot; applied when loading saved mock group state (`mockLayer.ts`). Groups are not part of Export/Import, so exports and imports are unaffected. One test covers the migration; suite run once: 65 passing.
- **Avatar text** uses `--on-group`; the green for "Everyone free" and "Accepted" is now `--good` (no hard-coded `#2f9e44` left); keyboard **focus ring** is `outline: 2px solid var(--accent)` on `:focus-visible` only.
- New variables per theme: `--good`, `--on-group`, `--g1..--g6`. Seed colors: Roommates slot 5, Friends slot 3, "me" slot 1, Alex 2, Sam 3, Jordan 4, Riley 5 (mock data only).
- Checked the group screen in light and dark in headless Edge; `tsc`/`oxlint` clean. Not checked on a real iPhone.

## 2026-11-04: Dark theme tweaked to option R (Espresso + Deep Copper), Ava's spec (John authorized)

- Changed only four dark values in both dark blocks of `src/index.css`: accent `#c47a4c`, event `#6ba89d`, task `#cfab52`, danger `#e5594f`. Background, surface, text, muted, border and on-accent stay as in K. Light (E) unchanged. CSS only; not re-checked on screen, no tests run.

## 2026-11-04: Dark theme changed to option K (Espresso + Copper), Ava's spec (John authorized)

- Replaced the dark values (F, berry) with option K in both dark blocks of `src/index.css`: bg `#14100d`, surface `#201915`, text `#f3e9df`, muted `#a8937f`, border `#33281f`, accent `#e0925f`, on-accent `#1f0e04`, event `#7cc4b8`, task `#e8c35a`, danger `#ff5f56`. Light (E) unchanged. `--bg-outer` (not in the spec) set to `#0a0807`. CSS only; not re-checked on screen, no tests run.

## 2026-11-04: Dark theme changed to option F (Berry + Lime), Ava's spec (John authorized)

- Replaced the dark color values (H, ocean) with option F in both dark blocks of `src/index.css` (system dark and forced `data-theme='dark'`), using Ava's values: bg `#160e14`, surface `#221620`, text `#f8ecf3`, muted `#a98a9b`, border `#35222f`, accent `#f06aa8`, on-accent `#1f0613`, event `#4cc4d1`, task `#c3e24a`, danger `#ff7a4d`. Light theme (E) unchanged.
- `--bg-outer` (desktop backdrop) is not in the spec; I set it to `#0c070b` to match the darker berry.
- Checked in headless Edge: dark Schedule shows pink accent (FAB, Today, active tab), teal events, lime tasks, orange-red Overdue. CSS only; no tests run.

## 2026-11-04: Themed scrollbars (Ava's fix, approved by Craig 2)

- Desktop scrollbars were default white/grey and clashed with the sand theme. Added thin scrollbars colored from `--muted` (both themes), transparent track, hidden arrow buttons (`index.css`), and set `--bg` as the explicit background of the main scroll container and the Calendar time grid so no white track shows. iPhone uses overlay scrollbars, so this only affects the desktop view. CSS only; no tests run.

## 2026-11-04: Appearance setting (System / Light / Dark), John's direct request

- Settings → **Appearance**: System (default, follows the device), Light, Dark. Choice is saved per user in `settings.theme` (optional field, missing = System; export/import compatible) and applied as `data-theme` on `<html>` (`src/lib/theme.ts`, `App.tsx`). It is also remembered in localStorage and applied before the first render, so there is no flash on launch (`main.tsx`).
- CSS: the dark token block now applies only when the user has not forced Light, plus an explicit `data-theme='dark'` block and matching `color-scheme` (`index.css`). Colors unchanged.
- I made it a 3-way picker rather than a two-way switch so "follow my phone" is still possible.
- Verified in headless Edge with the system set to dark: Light forces the sand theme, System returns to dark, value saved. `tsc`/`oxlint` clean; no test added (UI only).

## 2026-11-04: New color theme (Ava's spec, approved by John)

- Source: `design/color-tokens.md`. Light = option E (warm sand, terracotta accent, teal events, mustard tasks); dark = option H (deep ocean, sky-blue accent, turquoise events, persimmon tasks). Used the file values, not the preview PNGs.
- `src/index.css`: replaced the color tokens (light and dark) and added `--on-accent`. Accent is now separate from the event color: FAB, Today badge, selected day, active tab, primary buttons and Day/Week toggle use `--accent` with `--on-accent` text; events stay `--event` (clock icon), tasks `--task` (flag icon).
- Replaced hard-coded colors in components: button/FAB/badge/selected-day/urgent-mark text now `--on-accent`; toast is now the inverse of the page (no blue link); the Calendar now-line uses `--accent` instead of danger. No hard-coded blues or oranges remain outside group/avatar colors.
- PWA: manifest and `theme-color` now use the terracotta/sand colors; placeholder icons recolored to terracotta.
- Left as is: group colors and avatar colors (unchanged per Ava/Craig; the "me" avatar is still the old blue), the green "Everyone free" and "Accepted" colors (not event/task/accent hues), and `--danger` for destructive buttons, errors, the To-Do "!" mark and Overdue.
- Colors only: no logic changed, so the test suite was not re-run. `tsc` clean. Checked light and dark in headless Edge (Schedule, Calendar, To-Do). Not checked on a real iPhone.

## 2026-11-04: Three items from FUTURECHANGES.md (approved by John via Craig 2)

- **Recently completed** is now a single button in Settings ("Recently completed (N)") that opens a sheet with the list and Undo, instead of an inline list. (`Settings.tsx`)
- **Timezone selector removed.** The device timezone is read on launch and whenever the app returns to the foreground (`src/lib/useDeviceTimezone.ts`); all day logic and the Calendar use it, and it is saved to the per-user `settings.timezone` whenever it changes (`App.tsx`).
- **To-Do urgency.** Optional `dueDate` and `urgent` on to-do entries (`types.ts`; export/import compatible). Edit sheet has a due date picker (with Clear) and an Urgent toggle. Urgent = flagged OR due within 7 days (overdue included): shows a red "!" and the due date; urgent items sort to the top (soonest due first, then flagged-only, then the rest), each group keeping manual order. Dragging only reorders within its own group. No mark for items due more than a week out. (`src/lib/urgency.ts`, `ListScreen.tsx`). Sample to-dos now include a due-soon, a flagged and a far-off item.
- One test for the urgency/sort rules (`urgency.test.ts`). Full suite run once: 64 passing; `tsc`/`oxlint` clean. Checked the To-Do screen and edit sheet in headless Edge.
- Not verified: device timezone change while traveling (logic only; no real device).

## 2026-11-04: Interactive follow-up: fewer tests, one gear

- Per the new "Token economy" rule in `CLAUDE.md`: pruned the Interactive tests from 26 to 7 (kept busy intervals, free time, copy sync, link expiry/countdown, accept/decline copy). Deleted `src/groups/mockLayer.test.ts`; trimmed `src/lib/groups.test.ts` and `src/groups/actions.test.ts`. Suite is now 63 tests (was 82), passing.
- Per Craig 2: the app-level Settings gear is hidden on group screens so only the group header's gear shows (`index.css`, CSS only; the app Settings is still reachable from the other tabs).

## 2026-11-04: Interactive tab (groups, availability, group events) on mock data

- Handoff reference: 004 (front end on local mock data, no backend, no new libraries).
- **Fifth tab "Interactive"** (people icon); tab bar is now five equal columns (78px each, 48px tall, above the 44pt minimum).
- **Interactive tab:** Invitations section (group, title, time, who sent it, a "You're busy then" note without naming the conflicting event, Accept / Decline), "Your groups" list (color dot, name, member initials), **New group** (name + color) and **Join with link** (paste a link; friendly messages for invalid, expired, used, already a member).
- **Group screen:** back, group name, gear; day navigation + Mon-Sun strip (same pattern as Calendar); an hour grid with **one lane per member** (initials on top) showing **busy blocks only (no text)**; green **"Everyone free"** bands (7 AM to 11 PM, at least 30 min); group events as labeled blocks in the group color (overlaps side by side); **Add group event** button (also tap an empty slot); tap a group event for title, time, creator, notes and each member's response (Accepted / Declined / Pending); the creator can Edit or Cancel it.
- **Group settings:** editable name, color picker, members list, **Invite someone** (one-time mock link, 20-minute live countdown, Copy, Share when the browser supports it, clear "expired" / "used" states with a New link button), Notifications placeholder (disabled, "coming soon"), **Leave group** with confirm. No admin roles.
- **Privacy rule:** `computeBusy` (`src/lib/busy.ts`) outputs only user id, date, start, end. Rules: timed events busy start to end (no end = 1 hour), repeats expanded with the existing recurrence engine (skipped and completed occurrences ignored), all-day events not busy, tasks not busy unless "Show on calendar" is on and timed (30 min).
- **Architecture:** new `GroupLayer` interface (`src/groups/layer.ts`) with a local mock (`mockLayer.ts`: in-memory state saved to localStorage, seeded fake friends with weekly busy patterns in `mockBusy.ts`). `src/groups/index.ts` is the one place to swap in Firestore later. My own busy intervals are published from my personal calendar by `useGroupBackground` (also keeps accepted copies in sync).
- **Accept** copies the group event onto my personal calendar as an **event** with `groupId` and `groupEventId` (optional fields; export/import compatible), tinted in the group color in Schedule and Calendar. **Decline** records the response only. Edits or cancellation by the creator update or remove accepted copies (`planGroupSync`).
- **Dev section (Settings):** Seed mock groups, Member joins, Member leaves, Incoming invite, Make a join link (prints a link to paste into "Join with link").
- Tests: 82 passing (busy intervals incl. repeats/skips/default 1h/untimed/flagged tasks/privacy of output, free ranges, invite filtering, conflicts, accepted copy, sync, link status/expiry/countdown/parsing, mock layer behavior, accept/decline/create copy behavior). `tsc`, `oxlint` clean. Verified in headless Edge: five tabs on one row, invitation card, group grid with lanes/busy/free band, invite link with countdown, accepting adds a purple "Game night" to the Schedule.
- **Decisions/deviations for Craig 2:** (1) The creator of a group event counts as Accepted and gets a personal copy too. (2) Leaving a group keeps copies I already accepted, as plain events (group tags removed). (3) The group screen shows its own header and gear under the app's top bar, so two gears are visible. (4) Mock state persists in localStorage under `productivity-app:mock-groups:v1`, so it survives reloads but is separate from Export/Import (groups are not exported). (5) Mock friend busy patterns are fixed weekly schedules, not derived from anything real.
- Not verified on a real iPhone: grid scroll vs swipe-by-day in the group screen, Share sheet, tap targets in the lanes.
- Left undone: real invite redemption (Firestore rules, allow-list check), notifications, per-event private toggle (explicitly not built).

## 2026-11-04: Calendar redone as an Outlook-style time grid, with Day and Week views

- Handoff reference: Plan.md 4.2 (via Craig 2), supersedes Addendum A item 3. John added the Day/Week choice directly.
- **Day view:** header (week range, prev/next/Today), Mon-Sun strip (dots now reflect what the grid shows), selected day's hour grid (scrollable, hour labels, faint hour lines). Event **blocks sized by start/end** (no end = 1 hour), **overlaps side by side** (cluster-based columns), all-day/untimed events in a slim strip above the grid, red **now line** on today. Opens scrolled to ~1 hour before now (today) or 7 AM (other days).
- **Week view:** same grid with seven day columns (strip aligned over the columns), all-day events as small chips (max 2 per day, "+N" selects that day), now line on today's column only. Column width on a phone is ~46px, so titles are truncated; tap a block to edit.
- **Toggle:** Day | Week control under the header. Choice is kept in `App` (persists across tabs this session). Arrows and swipe now move **by day in Day view and by week in Week view** (was always by week).
- **Tap an empty slot** (either view) to add an **event** at that hour (opens the sheet with Event selected and the time set). "+" still adds on the selected day.
- **Tasks:** shown on the Calendar only when the new per-task flag **"Show on calendar"** is on (checkbox in the Add/Edit sheet for tasks, default off). Flagged tasks with a time are a 30-minute orange block (check circle in Day view; in Week view tap to edit); flagged tasks with no time go in the all-day area. Data: optional `showOnCalendar?: boolean` on `Item` (missing = false); old data and backups work unchanged; export/import keeps it.
- New: `src/lib/gridLayout.ts` (block times, overlap layout), `minutesNowIn` (timezone-aware, in `dates.ts`), `showsOnCalendar` / `calendarOccurrencesByDate` (`schedule.ts`); rewritten `src/screens/Calendar.tsx`; styles in `index.css`. Sample data now has end times, overlapping events (Thrive + Study group on Friday), an all-day event, an event today, and a flagged task.
- Tests: 56 passing (block times, overlap layout, timezone minutes incl. DST, calendar filter). `tsc`, `oxlint` clean. Verified in headless Edge: day and week renders, overlap widths, slot tap sets 10:00, view persists across tabs.
- Not verified on a real iPhone: scrolling the grid vs. page, swipe by day, tap targets in the narrow week columns.
- Left undone: dragging/resizing blocks (not asked); event end time before start is ignored (falls back to 1 hour).

## 2026-11-04: Shopping sections become top tabs (John's request)

- Handoff reference: none (direct request from John). Refines the entry below.
- Shopping now shows **one list at a time**: the Groceries / General tabs at the top switch which list you see, and the selected tab is also where new items are added. The stacked sections, subheadings and horizontal line are removed.
- Files: `src/screens/ListScreen.tsx` (renders only the selected section; empty message "Nothing on your groceries/general list."; drag context resets per tab), `src/index.css` (removed section styles). Data model unchanged (`section` field, Edit → List still moves an entry).
- Verified in headless Edge: tab switch shows the right items, add on General lands in General, switching back shows Groceries. 49 tests passing, `tsc`/`oxlint` clean.
- Note: the selected tab resets to Groceries when you leave the Shopping tab and come back (not remembered).

## 2026-11-04: Shopping list split into Groceries and General (John's request)

- Handoff reference: none (direct request from John). **Changes the plan:** CLAUDE.md/Plan.md say shopping is "one single list, no separation". Craig 2 informed.
- Shopping tab now has two sections, **Groceries** and **General**, each with a subheading and separated by a horizontal line. Still **one** add line; a Groceries/General picker above it chooses the target section (remembers the last choice while the app is open). New entries go to the bottom of that section.
- Data: optional `section?: 'groceries' | 'general'` on `ListEntry` (`src/types.ts`); missing means groceries, so existing entries and old backups still work (`sectionOf` in `src/lib/order.ts`). `ListStore.add(title, notes?, section?)`. Export/import keeps it (tested). To-Do is unchanged (single list).
- UI (`src/screens/ListScreen.tsx`): drag-to-reorder works **within** a section (one drag context per section). Edit sheet has a List picker to move an entry to the other section (it lands at the bottom there). Empty section shows "Nothing here."
- Sample data now includes entries in both sections. Tests: 49 passing. Verified in headless Edge: add to each section, reorder inside General, move Light bulbs to Groceries via Edit.
- Not built: dragging an entry directly between sections (use Edit to move).

## 2026-11-04: M6 Polish, export/import, offline, checklist

- Handoff reference: 002, milestone M6 (final front-end milestone).
- Export/Import: new round-trip tests (48 tests total) cover every field: `seriesId`, `originalDate`, `skippedDates`, `completedOccurrences`, `repeat.until`, `reminder`, `doneAt`, list `order`/`done`, all settings, and importing into a different user id (the migration path). Import now catches failures and shows a plain message ("Could not restore that backup. Your current data was not changed.") instead of a raw error.
- Error handling: `ErrorBoundary` around the app (friendly "Something went wrong" + Reload; data stays on device).
- PWA/offline: production build produces manifest, service worker (9 precached files) and icons. Verified on the preview server in headless Edge: service worker activates and controls the page, and the app reloads and renders with the network emulated offline. Not verified: Home Screen install and iPhone offline (need HTTPS hosting).
- New `MANUAL-CHECKLIST.md` (project root and OneDrive): short, scannable, each item marked desktop-checked or **iPhone: untested** (swipe, touch drag, keyboard vs sheet, safe areas, LAN access).
- README refreshed (demo data, offline check, code map).
- No console errors or warnings seen during the click-throughs. `tsc`, `oxlint`, build clean.
- Deviations: none. Not built (by instruction): everything in `FUTURECHANGES.md`. Reminder UI still hidden.
- Left undone: real-iPhone verification (John), backend (later handoff).

## 2026-11-04: M5 Shopping List and To-Do tabs

- Handoff reference: 002, milestone M5. Library added with Craig 2's approval: `@dnd-kit/core`, `@dnd-kit/sortable`, `@dnd-kit/utilities`.
- **Tab order changed at John's request:** Calendar, Schedule, **To-Do (3rd), Shopping (4th)**.
- New `src/screens/ListScreen.tsx` shared by both lists: type-to-add bar at the top, **new entries go to the bottom**, check circle checks off (hidden at once, toast with Undo), tap the text to edit (title, plus notes on To-Do) with Delete + confirm, **drag handle** on the right to reorder (pointer + keyboard sensors; drag only starts from the handle, so scrolling is not affected).
- Ordering `src/lib/order.ts`: dropping an entry sets only that one entry's `order` to the midpoint of its new neighbours (one document per drag); one gap past the edge at top/bottom; automatic rebalance if repeated drops squeeze neighbours below 1e-6. Writes in `actions.ts` (`setEntryDone`, `moveEntry`, `storeFor`).
- 24-hour clear now covers both lists (`runCleanup`, also used by the dev "Run cleanup as if 24h later" button). Settings "Recently completed" now includes list entries with Undo. Old placeholder screen removed.
- Tests: 46 passing (added ordering, rebalance, list cleanup). `tsc`, `oxlint` clean. Click-through in headless Edge with a real synthesized mouse drag: add goes to bottom, drag Milk from 1st to 3rd reorders, check-off hides, Undo restores.
- Deviation/decision for Craig 2: shopping entries are checked off with the **circle** (not by tapping the whole row), because tapping the text opens Edit/Delete.
- Not verified: touch drag and swipe on a real iPhone (to be on John's manual checklist in M6).
- Left undone: M6 (polish, PWA checks, manual checklist). `FUTURECHANGES.md` items not built.

## 2026-11-04: M4 Calendar tab (phone layout)

- Handoff reference: 002, milestone M4, per Addendum A.
- New `src/screens/Calendar.tsx`: header with week range ("Nov 2 – 8"), previous/next arrows and a Today button; Monday to Sunday strip (weekday letter, date number, today ringed, selected day filled, up to two dots: blue = event, orange = task); the selected day's agenda below it (untimed items first, then timed items in order with the time in a left gutter; check circles and tap-to-edit work as in the Schedule). Simple list, no hour grid.
- Swipe left/right anywhere on the Calendar changes the week (`src/lib/swipe.ts`; keeps the same weekday). Tapping a strip day selects it.
- Selected day is kept in `App.tsx` so it persists across tabs during the session. The "+" button adds on the selected day.
- New helpers: `weekStart` (Monday) in `dates.ts`; `weekRangeLabel`, `longDate` in `format.ts`; `ItemRow` gained a `timeInGutter` mode. Styles appended to `index.css`.
- Tests: 40 passing (added week start, range labels, swipe detection). `tsc` and `oxlint` clean. Click-through verified in headless Edge (tab open, day select, next week, selection persists across tabs, Today, "+" defaults to selected day). Swipe verified by unit test only, not on a touch device.
- Note: no changes to `FUTURECHANGES.md` (read-only for agents). Its items (Interactive tab, Recently completed as a button instead of a list) are not built.
- Left undone: lists (M5), polish/PWA/manual checklist (M6). Not yet tried on a real iPhone.

## 2026-11-04: M2 Items + M3 Daily Schedule (interactive demo)

- Handoff reference: 002 (milestones M2 and M3, plus Addendum A from Craig 2). Done together at John's request so he gets an interactive demo.
- Recurrence engine `src/lib/recurrence.ts`: weekly, monthly (original day-of-month, clamped to month end, never drifts), `until`, `skippedDates`. Occurrences are calculated, never stored.
- Check-off/undo/cleanup `src/lib/completion.ts`; grouping, sorting and Overdue `src/lib/schedule.ts`; formatting `src/lib/format.ts`; today-in-timezone hook `src/lib/useToday.ts`.
- Writes in `src/data/actions.ts` (all through the data layer): create, edit, delete, check-off, cleanup. Edit/delete "this occurrence only" = push date to `skippedDates` (+ new non-repeating item with `seriesId` and `originalDate` for edits); "all occurrences" edits the series (moving the date moves the series by the same offset).
- Add/Edit form: bottom sheet (90%), title (autofocus on add), Event/Task segmented control (blue/orange), native date and time inputs, "Has a time" toggle, end time (events), Repeat (none/weekly/monthly), notes, sticky Save, Delete in edit mode with confirm or this/all prompt. Reminder UI hidden. Tapping a row opens Edit; the check circle only checks off.
- Daily Schedule tab: scroll from today, every date shown (60 days per page, auto-loads more), header like `11/4 Wednesday`, Mondays bold with a divider and extra spacing, timed items in order then untimed, "Title at 6:30 PM" text, blue clock glyph for events and orange flag for tasks, inline "+ Add" per date (task, title only; "More…" opens the full form), "+" button, Overdue block at top, toast with Undo on check-off, auto-clear cleanup on open/foreground.
- Settings: new "Recently completed" card (Undo for the last 24 hours). Dev section: new "Run cleanup as if 24h later". Dev only: opening `http://localhost:5173/?demo` loads the sample data into an empty app.
- Deviations/decisions to review: (1) **Cleanup of a repeating occurrence** moves its date into `skippedDates` instead of just deleting the completion entry, otherwise the old occurrence would reappear as not done/overdue. (2) **Overdue for repeating tasks** looks only at the latest past occurrence (not "most recent unfinished"), so completing it does not surface older misses. Craig 2 informed. (3) Quick-add on each date always creates a **task**. (4) Fixed a Dexie compound-index warning by filtering on `id` then `uid`.
- Tests: 37 passing (recurrence, month-end clamping, DST, completion, cleanup, overdue, ordering, formatting, data layer, export/import). `tsc`, `oxlint` clean. Verified in headless Edge (screenshots and click-through: check-off, undo, edit sheet, this-occurrence prompt, add sheet).
- Left undone: Calendar tab (M4), lists (M5), polish/PWA checks/manual checklist (M6). Not yet verified on a real iPhone.
- Follow-up (John's feedback, same day): timed items in the Schedule are now **time first**, structured like `6:30pm - Thrive` (bold time in an aligned column, then dash, then title), instead of "Thrive at 6:30 PM". Files: `src/lib/format.ts` (`formatTimeShort`, `itemText`), `src/components/ItemRow.tsx`, `src/index.css`, tests updated (37 passing). This is a deliberate deviation from handoff 002's "Thrive at 6:30 PM" wording; Craig 2 should update the spec.

## 2026-11-04: M1 Foundation

- Handoff reference: 002, milestone M1. Code lives in `C:\dev\productivity-app` (outside OneDrive), committed locally on `main`. Not pushed anywhere.
- Scaffold: Vite 8 + React 19 + TypeScript (strict on) + `vite-plugin-pwa` (manifest, service worker, placeholder icons 192/512/180, iOS meta tags, `viewport-fit=cover`). `npm run dev` runs `vite --host` (LAN reachable). Dev server: http://localhost:5173.
- Libraries added: **Dexie** (IndexedDB wrapper, my pick), `vite-plugin-pwa`, **Vitest**, `fake-indexeddb` (tests only). No others. No Firebase.
- Data layer: `src/data/types.ts` (subscription-style `DataLayer` interface: items, shopping, todos, settings, exportAll/importAll/clearAll), `dexieDataLayer.ts` (IndexedDB, rows scoped by user id), `index.ts` (single place the implementation is chosen), `hooks.ts`. List order is gap-based (new entries at bottom, +1000).
- Auth stub `src/auth/auth.ts`: fixed `local-user`, no-op `signOut`. No sign-in screen.
- Export/Import: versioned (`version: 1`) JSON with items, shopping, todos, settings; import validates and gives friendly errors, confirms before replacing.
- UI: iPhone 15 sized frame (393 wide; centered rounded frame on desktop), top bar with gear, bottom tab bar (Calendar, Schedule, Shopping, To-Do) with safe-area padding, light/dark via system setting, event blue / task orange color tokens. Tabs are placeholders that show stored-item counts to prove data-layer wiring. Settings: timezone picker, Export JSON, Import JSON, and a dev-only Developer section (Load sample data, Clear all data, both confirm).
- Sample data (`src/dev/sample.ts`) reflects the OneNote page, relative to today: rent (monthly 1st), LG&E (monthly), storage unit (monthly on the 31st), module assignments 11:59 PM (weekly), Community groups Wed 7 PM, Thrive Fri 6:30 PM, bonfire, night out with long note, two untimed tasks, one overdue task, shopping and to-dos.
- Tests: 20 Vitest tests passing (timezone and DST day logic, date arithmetic, month-end clamping helper, data layer CRUD and subscriptions, per-user isolation, list ordering, export/import round trip, validation, sample data). `tsc`, `oxlint` and `vite build` clean.
- Deviations: (1) iPhone-only layout per John's decision (no wide layouts). (2) `README.md` written now. (3) `npm audit` reports dev-only warnings in the PWA build tooling (workbox's glob/minimatch); none in app runtime dependencies; not "fixed" to avoid breaking the build.
- Left undone: recurrence engine and Add/Edit form (M2), all real screens (M3 to M5), Settings polish and PWA checks (M6). Reminder UI is hidden by design. GitHub push undecided.

## 2026-11-04: Handoff 002 received; Node installed without admin; scope decisions

- Handoff reference: 002 (front end on a local dev server, no backend).
- Decision by John: build the front end on the work laptop with a localhost server; the backend (Firebase, sign-in, hosting) is done later on his personal laptop.
- Decision by John (mid-session): design the UI for **iPhone 15 screen dimensions (393 x 852)**. On a desktop, the app shows as a centered phone-sized column (phone-emulator look). This **replaces** the seven-column wide Calendar layout and other laptop layouts in handoff 002 and CLAUDE.md. Craig 2 should update Plan.md and the handoff.
- Installed Node.js v26.13.0 (npm 11.20.0) without admin rights: downloaded the official zip, checked its SHA-256 against nodejs.org's published value, unpacked to `C:\dev\tools\node`, added that folder to John's user PATH. Nothing was installed system-wide. npm registry is reachable from this laptop.
- Left undone: scaffold and M1 not started yet. Firebase CLI not installed (deferred per handoff 002). Private GitHub repo and push still undecided.

## 2026-11-03: Project folder set up and revised handoff 001 read

- Handoff reference: 001 (revision 2026-11-03, invite-only multi-user access).
- Created the code workspace at `C:\dev\productivity-app` (outside OneDrive, confirmed by John).
- Copied `CLAUDE.md`, `Plan.md`, `CHANGELOG.md` and `handoffs/` into it. OneDrive copies remain the masters. Re-copied `CLAUDE.md`, `Plan.md` and `handoffs/` after Craig 2's revision.
- Read the revised handoff 001: access is now an email allow-list (`allowedEmails/{lowercased email}`) with private per-user data, not a single hard-coded UID.
- Prerequisite check: Git installed; Node.js LTS and Firebase CLI missing.
- Accounts decided: Firebase owner and main sign-in `johnclittle19@gmail.com`; test account `jlittle.unitedtote@gmail.com` (to be added to the allow-list later, after the blocked-state test). Work email `john.little@unitedtote.com` is not used for the app.
- Tried `winget install OpenJS.NodeJS.LTS` on the work laptop: failed (exit 1602). The installer needs administrator rights and John has no admin login on this laptop.
- John decided to build on his personal laptop at home (no admin rights on the work laptop).
- Future idea recorded (not for now): invite people by QR code inside the app instead of John hand-editing `allowedEmails` in the console. Goal is that random people cannot use the app. To be planned by Craig 2 much later.
- Left undone: no app code yet. Node.js and Firebase CLI are not installed. Next: start handoff 001 on John's personal laptop.

## 2026-11-03: Rename chats to Dan 2 and Craig 2

- Handoff reference: none (direct request from John).
- Renamed "Dan" to "Dan 2" and "Craig" to "Craig 2" throughout:
  - `CLAUDE.md` (17 lines)
  - `Plan.md` (14 lines)
  - `handoffs/001-project-setup-and-firebase.md` (3 lines)
- Created this `CHANGELOG.md`.
- Left undone: handoff 001 has not been started. Waiting on John's answers to Step 0 (code location and how to keep the docs available in the project).
