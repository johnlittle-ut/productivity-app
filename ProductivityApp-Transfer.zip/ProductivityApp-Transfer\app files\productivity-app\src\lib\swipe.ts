/** Horizontal swipe detection: -1 = swiped left (go forward), 1 = swiped right (go back), 0 = not a swipe. */
export function swipeDirection(dx: number, dy: number, minDistance = 60): -1 | 0 | 1 {
  if (Math.abs(dx) < minDistance || Math.abs(dy) > Math.abs(dx) * 0.6) return 0
  return dx < 0 ? -1 : 1
}
