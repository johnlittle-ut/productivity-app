# Handoff 005: Notifications (Phase 2) PLAN

Status: **plan; start after handoff 003 is done** and John has the app installed on his iPhone Home Screen. Written by Craig 2, 2026-11-04. One decision (section C) must be settled with John before building.

## Goal
Quiet, deliberate notifications only: **per-item reminders** (events default **1 hour before**, adjustable; tasks off by default) and **one daily digest at 9:00 AM** in the user's timezone. One notification per item, never duplicates. No permission prompt unless the user taps "Enable notifications".

## What iPhone requires (facts to design around)
- **iOS 16.4 or later**, and the app must be **installed to the Home Screen** (opened from the icon). Safari tabs cannot receive web push.
- Permission can only be requested from a **user tap** inside the installed app.
- **Every push must show a visible notification** (no silent pushes); otherwise iOS cancels the subscription.
- Web push on iPhone needs **no Apple developer account**. Android (Chrome) works the same way and is more reliable.
- Sending a push at a set time needs **a server** (a web app cannot wake itself). Plan: a free **Cloudflare Worker** with a cron trigger (needs a free Cloudflare account, no card). Firebase Cloud Functions would need the Blaze plan, so it is not used.
- Reliability is somewhat lower than native apps. Test over several days.

## A. App side
- Service worker: push and notification-click handlers (tap opens the app on Schedule, today).
- Settings: **"Enable notifications"** button (permission request and subscribe using the VAPID public key), a **"Send test notification"** button, **"Turn off notifications"** (unsubscribe and delete the subscription), digest on/off and time (default 9:00).
- Save each device's push subscription under `users/{uid}/pushSubscriptions/{id}` (per user, per device).
- Unhide the **reminder control** in the Add/Edit sheet (Off, at time, 15 min, 30 min, 1 hour, 2 hours, morning of, custom). Events default to 1 hour before.
- Reminder times use the item's absolute time (tz-anchored events already give exact instants).

## B. Server side (Cloudflare Worker)
- One Worker serves **all allowed users**; secrets: VAPID private key, Firebase service-account key (for reading Firestore). Generate VAPID keys once.
- Cron every 5 minutes: find due reminders and digests, send Web Push to that user's subscriptions only, then record that it was sent (exactly one notification per item).
- Digest: at each user's configured time in **their effective timezone** (handles DST).
- Delete subscriptions the push service reports as expired (HTTP 404/410).
- Watch Cloudflare's free-tier limits, notably the small **CPU time per run**; keep the Worker light.
- Use a WebCrypto-based push library that runs on Workers. Dan: propose the library to John before adding it.

## C. DECISION NEEDED (John, at home): how the server learns what is due
John asked on 2026-11-04 not to commit to an approach yet. Options for Dan 2 to explain in plain terms:
1. **Reminders collection:** the app writes a small `fireAt` record per upcoming reminder (for repeating items, the next occurrences in a rolling window); the Worker asks Firestore only for records due now. Cheapest on reads, more app logic.
2. **Worker scans items:** the Worker reads each user's items every run. Simplest, but uses many reads and could hit free limits as users grow.
3. **Digest via iOS Shortcuts only:** a personal automation at 9:00 AM on John's phone, no server for the digest. Does not cover per-item reminders, and each user must set it up.
Craig 2's recommendation, to be confirmed: option 1, with option 3 as a fallback for the digest only.

## D. Tests and acceptance
- Test the **new logic once**: next-occurrence reminder generation (weekly, monthly, DST), one-notification-only marking, digest time in two timezones.
- Real-world check on John's iPhone over **3 to 7 days**: reminders arrive about 1 hour before events, digest arrives at 9:00, no duplicates, tapping opens the app, turning notifications off stops them.
- If iPhone delivery proves unreliable, report to Craig 2 and John before adding workarounds.

## Not in this handoff
Group-event invite notifications (they come with the groups backend), the widget, quiet hours (John declined), and a native app.
