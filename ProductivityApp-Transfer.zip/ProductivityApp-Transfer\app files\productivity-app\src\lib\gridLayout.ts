// Time-grid helpers for the Calendar day view (Outlook style).

import type { Item } from '../types'

export const MINUTES_PER_DAY = 24 * 60
export const DEFAULT_EVENT_MINUTES = 60
export const TASK_BLOCK_MINUTES = 30

export const toMinutes = (hhmm: string): number => {
  const [h, m] = hhmm.split(':').map(Number)
  return h * 60 + m
}

export interface GridBlock {
  key: string
  start: number // minutes from midnight
  end: number
}

export interface PlacedBlock extends GridBlock {
  col: number // column within its overlap cluster
  cols: number // number of columns in that cluster (width = 1 / cols)
}

/** Start/end minutes for a timed item: events default to 1 hour, flagged tasks to 30 minutes. Clamped to the day. */
export function blockTimes(item: Pick<Item, 'type' | 'startTime' | 'endTime'>): { start: number; end: number } | null {
  if (!item.startTime) return null
  const start = toMinutes(item.startTime)
  let end: number
  if (item.type === 'task') end = start + TASK_BLOCK_MINUTES
  else if (item.endTime && toMinutes(item.endTime) > start) end = toMinutes(item.endTime)
  else end = start + DEFAULT_EVENT_MINUTES
  return { start, end: Math.min(end, MINUTES_PER_DAY) }
}

/** Overlapping blocks are placed side by side; each connected cluster of overlaps shares its column count. */
export function layoutBlocks(blocks: GridBlock[]): PlacedBlock[] {
  const sorted = [...blocks].sort((a, b) => a.start - b.start || b.end - a.end)
  const placed: PlacedBlock[] = []
  let cluster: PlacedBlock[] = []
  let columnEnds: number[] = []
  let clusterEnd = -1

  const flush = () => {
    for (const b of cluster) b.cols = columnEnds.length
    placed.push(...cluster)
    cluster = []
    columnEnds = []
    clusterEnd = -1
  }

  for (const b of sorted) {
    if (cluster.length > 0 && b.start >= clusterEnd) flush()
    let col = columnEnds.findIndex((end) => end <= b.start)
    if (col === -1) {
      col = columnEnds.length
      columnEnds.push(b.end)
    } else {
      columnEnds[col] = b.end
    }
    cluster.push({ ...b, col, cols: 1 })
    clusterEnd = Math.max(clusterEnd, b.end)
  }
  flush()
  return placed
}
