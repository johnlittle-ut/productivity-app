// Group write operations. Personal calendar changes go through the personal data layer.

import { dataLayer } from '../data'
import { readOnce } from '../data/actions'
import { acceptedCopy } from '../lib/groupLogic'
import { groupLayer } from './index'
import type { GroupEvent, GroupEventInput } from './model'

/** Put a copy of the group event on my personal calendar (once), tagged with its group. */
async function ensureCopy(event: GroupEvent): Promise<void> {
  const items = await readOnce(dataLayer.items.subscribe)
  if (items.some((i) => i.groupEventId === event.id)) return
  await dataLayer.items.add(acceptedCopy(event))
}

export async function acceptInvite(event: GroupEvent): Promise<void> {
  await groupLayer.events.respond(event.id, 'accepted')
  await ensureCopy(event)
}

/** Decline only records the response; nothing is copied. */
export async function declineInvite(event: GroupEvent): Promise<void> {
  await groupLayer.events.respond(event.id, 'declined')
}

/** The creator is counted as accepted, so the event also lands on their own calendar. */
export async function createGroupEvent(groupId: string, input: GroupEventInput): Promise<void> {
  const event = await groupLayer.events.create(groupId, input)
  await ensureCopy(event)
}
