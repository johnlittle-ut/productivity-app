import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { ErrorBoundary } from './components/ErrorBoundary'
import { applySavedTheme } from './lib/theme'

applySavedTheme()

if (import.meta.env.DEV) {
  void import('./dev/demo').then((m) => m.maybeLoadDemo())
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
)
