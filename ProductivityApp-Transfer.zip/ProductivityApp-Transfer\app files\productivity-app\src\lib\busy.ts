// Turns a person's personal items into BUSY intervals (start/end only), and finds shared free time.

import type { BusyInterval } from '../groups/model'
import type { Item } from '../types'
import { addDays } from './dates'
import { blockTimes } from './gridLayout'
import { dayBounds, zonedToInstant } from './tz'
import { occurrencesByDate, showsOnCalendar } from './schedule'

export const BUSY_DAYS = 60
export const DAY_START_MIN = 7 * 60
export const DAY_END_MIN = 23 * 60

/**
 * Busy intervals for the next `days` days:
 * - timed events: start to end (no end = 1 hour); repeats expanded, skipped and completed occurrences ignored
 * - all-day (untimed) events: NOT busy
 * - tasks: NOT busy, unless flagged "Show on calendar" and timed (30 minutes, like the Calendar grid)
 * Output carries no titles or notes.
 */
export function computeBusy(items: Item[], userId: string, today: string, tz: string, days = BUSY_DAYS): BusyInterval[] {
  return myBlocks(items, today, tz, days)
    .filter((b) => !b.hidden)
    .map(({ date, start, end }) => {
      const s = zonedToInstant(date, hhmm(start), tz)
      return { userId, start: s, end: s + (end - start) * 60_000 }
    })
    .sort((a, b) => a.start - b.start)
}

const hhmm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`

/** Busy instants sliced to one calendar day in `tz`, as minutes from that day's midnight. */
export function busyForDay(busy: BusyInterval[], date: string, tz: string): { userId: string; start: number; end: number }[] {
  const day = dayBounds(date, tz)
  return busy
    .filter((b) => b.start < day.end && b.end > day.start)
    .map((b) => ({
      userId: b.userId,
      start: Math.round((Math.max(b.start, day.start) - day.start) / 60_000),
      end: Math.round((Math.min(b.end, day.end) - day.start) / 60_000),
    }))
}

/** My own busy blocks WITH titles (shown only to me), including events I hid from groups. */
export interface MyBlock {
  itemId: string
  title: string
  date: string
  start: number
  end: number
  hidden: boolean
  repeats: boolean
}

export function myBlocks(items: Item[], today: string, tz: string, days = BUSY_DAYS): MyBlock[] {
  const byDate = occurrencesByDate(items.filter(showsOnCalendar), today, addDays(today, days - 1), tz)
  const out: MyBlock[] = []
  for (const occs of byDate.values()) {
    for (const occ of occs) {
      const t = blockTimes({ type: occ.item.type, startTime: occ.startTime, endTime: occ.endTime })
      if (t) out.push({ itemId: occ.item.id, title: occ.item.title, date: occ.date, ...t, hidden: occ.item.hideFromGroups === true, repeats: !!occ.item.repeat })
    }
  }
  return out.sort((a, b) => a.date.localeCompare(b.date) || a.start - b.start)
}

export interface Range {
  start: number
  end: number
}

export function mergeRanges(ranges: Range[]): Range[] {
  const sorted = [...ranges].sort((a, b) => a.start - b.start)
  const merged: Range[] = []
  for (const r of sorted) {
    const last = merged[merged.length - 1]
    if (last && r.start <= last.end) last.end = Math.max(last.end, r.end)
    else merged.push({ ...r })
  }
  return merged
}

/** Time ranges (within about 7 AM to 11 PM) where NOBODY is busy, at least `minMinutes` long. */
export function freeRanges(busy: Range[], from = DAY_START_MIN, to = DAY_END_MIN, minMinutes = 30): Range[] {
  const free: Range[] = []
  let cursor = from
  for (const b of mergeRanges(busy)) {
    if (b.end <= from) continue
    if (b.start >= to) break
    if (b.start - cursor >= minMinutes) free.push({ start: cursor, end: b.start })
    cursor = Math.max(cursor, b.end)
  }
  if (to - cursor >= minMinutes) free.push({ start: cursor, end: to })
  return free
}

export function overlaps(a: Range, b: Range): boolean {
  return a.start < b.end && b.start < a.end
}

/** Start times (on the half hour) where everyone is free for `durationMin`, spaced so suggestions do not overlap. */
export function suggestSlots(busy: Range[], durationMin: number, from = DAY_START_MIN, to = DAY_END_MIN, max = 4): Range[] {
  const out: Range[] = []
  for (const free of freeRanges(busy, from, to, durationMin)) {
    let s = Math.ceil(free.start / 30) * 30
    while (s + durationMin <= free.end && out.length < max) {
      out.push({ start: s, end: s + durationMin })
      s += Math.max(durationMin, 60)
    }
  }
  return out
}
