import { useContext, useEffect, useMemo, useRef, useState } from 'react'
import { ItemRow } from '../components/ItemRow'
import { addDays, dayOfWeek, minutesNowIn, weekStart } from '../lib/dates'
import { formatTimeShort, longDate, weekRangeLabel } from '../lib/format'
import { blockTimes, layoutBlocks, MINUTES_PER_DAY } from '../lib/gridLayout'
import { calendarOccurrencesByDate, type Occurrence } from '../lib/schedule'
import { swipeDirection } from '../lib/swipe'
import { GroupColorsContext } from '../groups/hooks'
import type { Item } from '../types'

export type CalendarView = 'day' | 'week'

const LETTERS = ['S', 'M', 'T', 'W', 'T', 'F', 'S']
const HOUR_PX = 56
const MIN_BLOCK_PX = 22
const GRID_PX = (MINUTES_PER_DAY / 60) * HOUR_PX
const HOURS = Array.from({ length: 24 }, (_, h) => h)
const MAX_CHIPS = 2

const hourLabel = (h: number) => (h === 0 ? '' : h < 12 ? `${h} AM` : h === 12 ? '12 PM' : `${h - 12} PM`)

interface Props {
  items: Item[]
  today: string
  timezone: string
  selected: string
  view: CalendarView
  onView: (view: CalendarView) => void
  onSelect: (date: string) => void
  onCheck: (occ: Occurrence) => void
  onOpen: (occ: Occurrence) => void
  onMove: (occ: Occurrence) => void
  /** Tap on an empty slot: add an event starting at this time. */
  onAddAt: (date: string, startTime: string) => void
}

export function Calendar({ items, today, timezone, selected, view, onView, onSelect, onCheck, onOpen, onMove, onAddAt }: Props) {
  const start = weekStart(selected)
  const end = addDays(start, 6)
  const weekDays = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(start, i)), [start])
  const byDate = useMemo(() => calendarOccurrencesByDate(items, start, end, timezone), [items, start, end, timezone])
  const groupColors = useContext(GroupColorsContext)
  const shownDays = view === 'day' ? [selected] : weekDays
  const step = view === 'day' ? 1 : 7

  const [nowMin, setNowMin] = useState(() => minutesNowIn(timezone))
  useEffect(() => {
    const tick = () => setNowMin(minutesNowIn(timezone))
    tick()
    const id = setInterval(tick, 30_000)
    return () => clearInterval(id)
  }, [timezone])

  // Per-day layout of timed blocks (overlaps side by side within each day)
  const dayLayouts = useMemo(
    () =>
      shownDays.map((date) => {
        const occs = byDate.get(date) ?? []
        const timed = occs.filter((o) => o.startTime)
        const blocks = timed.map((o) => ({ key: o.key, ...blockTimes({ type: o.item.type, startTime: o.startTime, endTime: o.endTime })! }))
        const layout = new Map(layoutBlocks(blocks).map((b) => [b.key, b]))
        return {
          date,
          allDay: occs.filter((o) => !o.startTime),
          placed: timed.map((occ) => ({ occ, box: layout.get(occ.key)! })),
        }
      }),
    // eslint-disable-next-line -- shownDays is derived from selected/view/weekDays
    [byDate, selected, view, weekDays],
  )
  const anyAllDay = dayLayouts.some((d) => d.allDay.length > 0)

  // Open scrolled to the current hour (today in view) or about 7 AM
  const gridRef = useRef<HTMLDivElement>(null)
  const todayShown = shownDays.includes(today)
  useEffect(() => {
    const el = gridRef.current
    if (!el) return
    const focusMinutes = todayShown ? Math.max(0, minutesNowIn(timezone) - 60) : 7 * 60
    el.scrollTop = (focusMinutes / 60) * HOUR_PX
  }, [selected, view, todayShown, timezone])

  const touch = useRef<{ x: number; y: number } | null>(null)
  const onTouchStart = (e: React.TouchEvent) => {
    touch.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }
  }
  const onTouchEnd = (e: React.TouchEvent) => {
    const t = touch.current
    touch.current = null
    if (!t) return
    const dir = swipeDirection(e.changedTouches[0].clientX - t.x, e.changedTouches[0].clientY - t.y)
    if (dir !== 0) onSelect(addDays(selected, dir === -1 ? step : -step))
  }

  function onGridClick(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect()
    const hour = Math.min(23, Math.max(0, Math.floor((e.clientY - rect.top) / HOUR_PX)))
    const gutter = parseFloat(getComputedStyle(e.currentTarget).getPropertyValue('--gutter-w')) || 0
    const colW = (rect.width - gutter) / shownDays.length
    const idx = Math.min(shownDays.length - 1, Math.max(0, Math.floor((e.clientX - rect.left - gutter) / colW)))
    onAddAt(shownDays[idx], `${String(hour).padStart(2, '0')}:00`)
  }

  const n = shownDays.length

  return (
    <div className="calendar" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      <div className="cal-head">
        <button
          className="icon-btn"
          onClick={() => onSelect(addDays(selected, -step))}
          aria-label={view === 'day' ? 'Previous day' : 'Previous week'}
        >
          ‹
        </button>
        <div className="cal-range">{weekRangeLabel(start, end)}</div>
        <button
          className="icon-btn"
          onClick={() => onSelect(addDays(selected, step))}
          aria-label={view === 'day' ? 'Next day' : 'Next week'}
        >
          ›
        </button>
        <button className="btn today-btn" onClick={() => onSelect(today)} disabled={selected === today}>
          Today
        </button>
      </div>

      <div className="segmented view-toggle" role="group" aria-label="Calendar view">
        <button className={view === 'day' ? 'on plain' : ''} onClick={() => onView('day')}>
          Day
        </button>
        <button className={view === 'week' ? 'on plain' : ''} onClick={() => onView('week')}>
          Week
        </button>
      </div>

      <div className={`week-strip${view === 'week' ? ' aligned' : ''}`} role="tablist" aria-label="Days of the week">
        {weekDays.map((date) => {
          const occs = byDate.get(date) ?? []
          const hasEvent = occs.some((o) => o.item.type === 'event')
          const hasTask = occs.some((o) => o.item.type === 'task')
          const cls = [
            'strip-day',
            view === 'day' && date === selected ? 'selected' : '',
            date === today ? 'is-today' : '',
            view === 'week' && date === selected ? 'sel-soft' : '',
          ]
            .filter(Boolean)
            .join(' ')
          return (
            <button key={date} className={cls} role="tab" aria-selected={date === selected} onClick={() => onSelect(date)}>
              <span className="strip-letter">{LETTERS[dayOfWeek(date)]}</span>
              <span className="strip-num">{Number(date.slice(8))}</span>
              <span className="strip-dots">
                {hasEvent && <i className="dot event" />}
                {hasTask && <i className="dot task" />}
              </span>
            </button>
          )
        })}
      </div>

      {view === 'day' && <h2 className="agenda-title">{longDate(selected)}</h2>}

      {anyAllDay &&
        (view === 'day' ? (
          <ul className="allday-strip" aria-label="All day">
            {dayLayouts[0].allDay.map((occ) => (
              <ItemRow key={occ.key} occ={occ} onCheck={onCheck} onOpen={onOpen} onMove={onMove} />
            ))}
          </ul>
        ) : (
          <div className="allday-week" aria-label="All day">
            {dayLayouts.map(({ date, allDay }) => (
              <div key={date} className="allday-cell">
                {allDay.slice(0, MAX_CHIPS).map((occ) => (
                  <button key={occ.key} className={`chip ${occ.item.type}`} onClick={() => onOpen(occ)} title={occ.item.title}>
                    {occ.item.title}
                  </button>
                ))}
                {allDay.length > MAX_CHIPS && (
                  <button className="chip more" onClick={() => onSelect(date)}>
                    +{allDay.length - MAX_CHIPS}
                  </button>
                )}
              </div>
            ))}
          </div>
        ))}

      <div className="time-grid" ref={gridRef}>
        <div className={`grid-body${view === 'week' ? ' week' : ''}`} style={{ height: GRID_PX }} onClick={onGridClick}>
          {HOURS.map((h) => (
            <div key={h} className="hour-row" style={{ top: h * HOUR_PX, height: HOUR_PX }}>
              <span className="hour-label">{hourLabel(h)}</span>
            </div>
          ))}

          {view === 'week' &&
            shownDays.map(
              (date, i) =>
                i > 0 && (
                  <i
                    key={date}
                    className="col-line"
                    style={{ left: `calc(var(--gutter-w) + ${i} * (100% - var(--gutter-w)) / ${n})` }}
                  />
                ),
            )}

          {dayLayouts.map(({ date, placed }, dayIdx) =>
            placed.map(({ occ, box }) => {
              const { item } = occ
              const height = Math.max(((box.end - box.start) / 60) * HOUR_PX - 2, MIN_BLOCK_PX)
              const colW = `((100% - var(--gutter-w)) / ${n})`
              const width = `calc(${colW} / ${box.cols} - 1px)`
              return (
                <div
                  key={`${date}:${occ.key}`}
                  className={`grid-block ${item.type}${view === 'week' ? ' compact' : ''}`}
                  style={{
                    top: (box.start / 60) * HOUR_PX + 1,
                    ...(item.groupId && groupColors.get(item.groupId) ? { ['--event' as string]: groupColors.get(item.groupId) } : {}),
                    height,
                    width,
                    left: `calc(var(--gutter-w) + ${colW} * ${dayIdx} + ${colW} / ${box.cols} * ${box.col})`,
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  {item.type === 'task' && view === 'day' && (
                    <button
                      className="check task block-check"
                      onClick={() => onCheck(occ)}
                      aria-label={`Mark "${item.title}" done`}
                    />
                  )}
                  <button className="block-body" onClick={() => onOpen(occ)}>
                    <span className="block-title">{item.title}</span>
                    {view === 'day' && height >= 38 && (
                      <span className="block-time">
                        {formatTimeShort(occ.startTime!)}
                        {occ.endTime && item.type === 'event' ? ` – ${formatTimeShort(occ.endTime)}` : ''}
                      </span>
                    )}
                  </button>
                </div>
              )
            }),
          )}

          {todayShown && (
            <div
              className="now-line"
              style={{
                top: (nowMin / 60) * HOUR_PX,
                left: view === 'day' ? 'var(--gutter-w)' : `calc(var(--gutter-w) + ${shownDays.indexOf(today)} * (100% - var(--gutter-w)) / ${n})`,
                width: view === 'day' ? 'calc(100% - var(--gutter-w))' : `calc((100% - var(--gutter-w)) / ${n})`,
              }}
              aria-label="Current time"
            >
              <i />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
