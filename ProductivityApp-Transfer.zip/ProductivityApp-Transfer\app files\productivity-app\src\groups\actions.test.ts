import { beforeEach, describe, expect, it } from 'vitest'
import { dataLayer } from '../data'
import { readOnce } from '../data/actions'
import { acceptInvite, declineInvite } from './actions'
import { groupLayer } from './index'

const ME = groupLayer.me.id
const myItems = () => readOnce(dataLayer.items.subscribe)
const pendingInvite = async () =>
  (await readOnce(groupLayer.events.subscribeAll)).find((e) => e.responses[ME] === 'pending')!

beforeEach(async () => {
  await dataLayer.clearAll()
  await groupLayer.seed()
})

describe('group invites', () => {
  it('accept copies the event to my calendar (once) tagged with the group; decline copies nothing', async () => {
    const invite = await pendingInvite()
    await acceptInvite(invite)
    await acceptInvite(invite)
    const copies = (await myItems()).filter((i) => i.groupEventId === invite.id)
    expect(copies).toHaveLength(1)
    expect(copies[0]).toMatchObject({ type: 'event', title: invite.title, date: invite.date, groupId: invite.groupId })

    await groupLayer.simulateIncomingInvite()
    const other = await pendingInvite()
    await declineInvite(other)
    expect((await myItems()).some((i) => i.groupEventId === other.id)).toBe(false)
  })
})
