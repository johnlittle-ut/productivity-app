// Write operations the screens use. All storage access goes through the data layer.

import { cleanupPlan, completeOccurrence, DAY_MS, undoOccurrence } from '../lib/completion'
import { addDays } from '../lib/dates'
import { diffDays } from '../lib/recurrence'
import { planMoveToTomorrow } from '../lib/schedule'
import { convertWall } from '../lib/tz'
import { needsRebalance, orderForMove, expiredEntryIds, rebalanced } from '../lib/order'
import type { Item, ItemType, ListEntry, Repeat } from '../types'
import { dataLayer } from './index'
import type { Listener, Unsubscribe } from './types'

export interface FormValues {
  title: string
  type: ItemType
  date: string
  startTime: string | null
  endTime: string | null
  notes: string
  repeat: Repeat | null
  showOnCalendar: boolean
  tz?: string // zone the wall-clock times are in (the effective zone when saved); only for timed items
}

export type Scope = 'one' | 'all'

/** Read the current value of a subscription once. */
export function readOnce<T>(subscribe: (cb: Listener<T>) => Unsubscribe): Promise<T> {
  return new Promise((resolve) => {
    let unsub: Unsubscribe | null = null
    let settled = false
    unsub = subscribe((value) => {
      if (settled) return
      settled = true
      resolve(value)
      queueMicrotask(() => unsub?.())
    })
  })
}

export async function setDone(item: Item, date: string, done: boolean, now: number = Date.now()): Promise<void> {
  await dataLayer.items.update(item.id, done ? completeOccurrence(item, date, now) : undoOccurrence(item, date))
}

export async function createItem(values: FormValues): Promise<void> {
  await dataLayer.items.add(values)
}

/**
 * Save an edit. For a repeating item, `scope` says whether the edit applies to
 * just the occurrence on `occDate` or to the whole series.
 */
export async function saveEdit(item: Item, occDate: string, values: FormValues, scope?: Scope, viewDate: string = occDate): Promise<void> {
  if (!item.repeat) {
    await dataLayer.items.update(item.id, values)
    return
  }
  if (scope === 'one') {
    // Detach: skip this date in the series and create a stand-alone item with the edited values.
    await dataLayer.items.update(item.id, { skippedDates: [...item.skippedDates, occDate] })
    await dataLayer.items.add({ ...values, repeat: null, seriesId: item.id, originalDate: occDate })
    return
  }
  // All occurrences. Moving the date moves the whole series by the same number of days.
  const repeat: Repeat | null = values.repeat
    ? item.repeat.until
      ? { ...values.repeat, until: item.repeat.until }
      : values.repeat
    : null
  // The series is re-anchored to the zone the form was filled in (values.tz): find its first occurrence's date there.
  const base =
    values.tz && item.tz && item.startTime && item.tz !== values.tz
      ? convertWall(item.date, item.startTime, item.tz, values.tz).date
      : item.date
  const date = values.repeat ? addDays(base, diffDays(viewDate, values.date)) : values.date
  await dataLayer.items.update(item.id, { ...values, repeat, date })
}

export async function removeOccurrence(item: Item, occDate: string, scope?: Scope): Promise<void> {
  if (item.repeat && scope === 'one') {
    await dataLayer.items.update(item.id, { skippedDates: [...item.skippedDates, occDate] })
    return
  }
  await dataLayer.items.remove(item.id)
}

/** Delete things checked off 24h+ ago. `offsetMs` shifts "now" forward (dev time-travel). */
export async function runCleanup(offsetMs = 0): Promise<number> {
  const items = await readOnce(dataLayer.items.subscribe)
  const plan = cleanupPlan(items, Date.now() + offsetMs)
  for (const id of plan.deleteIds) await dataLayer.items.remove(id)
  for (const { id, patch } of plan.updates) await dataLayer.items.update(id, patch)
  let count = plan.deleteIds.length + plan.updates.length
  for (const store of [dataLayer.shopping, dataLayer.todos]) {
    const entries = await readOnce(store.subscribe)
    const expired = expiredEntryIds(entries, Date.now() + offsetMs, DAY_MS)
    for (const id of expired) await store.remove(id)
    count += expired.length
  }
  return count
}

// ---------- Shopping list and To-Do lists ----------

export type ListKind = 'shopping' | 'todos'

export const storeFor = (kind: ListKind) => (kind === 'shopping' ? dataLayer.shopping : dataLayer.todos)

export async function setEntryDone(kind: ListKind, entry: ListEntry, done: boolean, now: number = Date.now()): Promise<void> {
  await storeFor(kind).update(entry.id, { done, doneAt: done ? now : null })
}

/**
 * Drag-to-reorder: only the moved entry's `order` changes. `visible` is the list as shown
 * (checked-off entries excluded); `all` includes them, for the rare rebalance.
 */
export async function moveEntry(kind: ListKind, visible: ListEntry[], all: ListEntry[], from: number, to: number): Promise<void> {
  if (from === to) return
  const store = storeFor(kind)
  const order = orderForMove(visible, from, to)
  await store.update(visible[from].id, { order })
  const after = all.map((e) => (e.id === visible[from].id ? { ...e, order } : e))
  if (needsRebalance(after)) {
    for (const { id, order: o } of rebalanced(after)) await store.update(id, { order: o })
  }
}

/** Swipe action: move a task (this occurrence only, if it repeats) to `tomorrow`. Returns an undo function. */
export async function moveToTomorrow(
  item: Item,
  occDate: string,
  tomorrow: string,
  view?: { startTime: string | null; endTime: string | null; tz: string },
): Promise<() => Promise<void>> {
  const plan = planMoveToTomorrow(item, occDate, tomorrow, view)
  await dataLayer.items.update(item.id, plan.patch)
  const created = plan.copy ? await dataLayer.items.add(plan.copy) : null
  return async () => {
    await dataLayer.items.update(item.id, plan.undoPatch)
    if (created) await dataLayer.items.remove(created.id)
  }
}
