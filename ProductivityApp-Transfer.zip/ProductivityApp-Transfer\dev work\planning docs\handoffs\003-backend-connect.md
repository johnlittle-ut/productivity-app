# Handoff 003: Connect the backend (Firebase), from John's personal laptop

From: Craig 2. To: Dan 2. Date: 2026-11-04. Supersedes `003-backend-outline.md` (keep its "Free-tier cost safeguards" section; repeated below).

## Read first
`CLAUDE.md` (rules, token economy, communication style), `Plan.md` (sections 2, 3, 4.7, Phase 4 notes), and `handoffs/001-project-setup-and-firebase.md` steps 3, 4, 5 and 7 (the detailed Firebase, sign-in, allow-list and iPhone-test instructions; they still apply).

**John is new to Firebase.** Walk him through every console step with exact clicks, **one small step at a time**, and wait for him to confirm before the next. Keep messages short.

## Goal
The app on John's iPhone Home Screen, signed in with Google, with data synced through Firestore, locked to invited accounts, hosted on Firebase Hosting, with John's existing data imported. No screen redesign: only the auth and data-layer swap.

## Verification rule (John's request)
**Do not assume John set something up correctly. After every step, verify it** and tell him pass or fail before moving on:
- **Environment:** Node and Git versions, the repo opens, `git log` shows the full history, `npm install` succeeds, the app runs locally, files from the transfer are all present (`src/`, `package.json`, `package-lock.json`, planning docs).
- **Firebase console:** Spark plan (no card), Analytics off, Google provider enabled, Firestore in production mode in the chosen region, Hosting enabled, web app registered.
- **Config:** `.env` has all `VITE_FIREBASE_*` values, is git-ignored, and no secrets are committed (check `git status` and the diff).
- **Allow-list and rules:** John's lowercased email document exists **before** rules deploy; rules deployed; Rules Playground confirms allowed and denied cases.
- **Deploy:** the live URL loads; the service worker registers; the Home Screen install works on the iPhone.
Ask John for a screenshot of a console screen when you cannot check it yourself.

## Steps

**0. Environment (personal laptop).** Clone the repo from the git bundle. Install deps, run the app on the local data layer, run the suite once. Create a **private GitHub repo** under John's personal account and push. Copy planning docs into the repo (`CLAUDE.md`, `Plan.md`, `CHANGELOG.md`, `handoffs/`, `design/`, `MANUAL-CHECKLIST.md`).

**1. Firebase project (Spark plan, no card).** Per handoff 001 step 3: project without Analytics, Google sign-in provider, Firestore in **production mode** (warn John the region is permanent; use `nam5` or `us-east1`), register the web app, put the config in `.env` (`VITE_FIREBASE_*`, git-ignored) plus `.env.example`, enable Hosting (`dist`, single-page app yes, no GitHub auto-deploy). John uses his **personal** Google account.

**2. Allow-list and rules (order matters).** Per handoff 001 step 5 and `Plan.md` 3.0: create `allowedEmails/{John's lowercased email}` in the console **before** deploying rules. Rules: `users/{uid}/**` only for the signed-in, email-verified owner who is on the allow-list; `allowedEmails/{email}` readable (get only) by that email, no client writes; deny everything else. Test with the Rules Playground.

**3. Real auth.** Replace the auth stub: Google sign-in (popup, redirect fallback; auth domain must match the hosted domain), persistent login, friendly **"This app is invite-only"** screen (shows the signed-in email and a Sign out button), create the user's `settings` doc on first sign-in with defaults, Sign out in Settings. No UID or email hard-coded anywhere.

**4. Firestore data layer.** Implement the existing `DataLayer` interface on Firestore under `users/{uid}/...`: offline persistence on, real-time subscriptions, same behavior and export format. Keep the local implementation selectable with an env flag for dev. Make sure **every current field** is in the Firestore shape (including `tz`, `showOnCalendar`, `hideFromGroups`, `seriesId`, `originalDate`, `skippedDates`, `completedOccurrences`, list `order`/`section`/`urgent`/`dueDate`, settings `timeFormat`/`timezoneOverride`/`theme`/text size/default tab) and that `undefined` values are stripped before writing.

**4b. Versioning and conflict resolution (John's requirement).** Implement `Plan.md` section 3.6: `updatedAt` on every record including lists and settings (backfill legacy), edit-time timestamps set in the data layer only, partial-field updates, rules that reject stale or far-future writes, soft deletes with `deletedAt` and a 30-day purge, server clock-offset correction, merge-by-newest on Import, and the "newer version kept" notice. Rules must be written with the allow-list rules from step 2 (update them together). Test the pure merge function once; also prove with two browser sessions that the newer edit wins.

**5. Cost safeguards (John approved).** Reads are the free-tier risk (Spark: roughly 50k reads, 20k writes, 20k deletes per day; verify current numbers). Listen **only** to the visible date range plus open items, never the full history; completed items still auto-delete after 24 hours. (Group busy data is one document per member per group; that is part of the later groups handoff.) Show John the Firebase usage dashboard.

**5b. Interactive tab.** Groups still run on mock data and have no backend yet. In the **hosted/production build, hide the Interactive tab** behind an env flag (default off) so John and friends do not see fake groups; John turns it on when the groups backend exists. Tell John you did this.

**6. Import John's data.** Use Import JSON with the export file John carries from the work laptop (validate, confirm before writing). Verify counts and spot-check items, repeats and lists. Keep the file as a backup.

**7. Deploy and iPhone test.** `firebase deploy` (hosting and rules). Give John the live URL. Run handoff 001 step 7's checklist: opens full screen from the Home Screen icon, **Google sign-in works inside the Home Screen app**, stays signed in after closing, offline open, invite-only screen for a non-listed account, adding then removing an account from the allow-list, and **sync both ways** (edit on laptop, see on iPhone, and reverse; edit in airplane mode, syncs after reconnecting). If sign-in fails in Home Screen mode, **stop and report** with exact errors; do not improvise.

**8. Docs.** README: run with either data layer, deploy, add or remove a person (console clicks, lowercase email), where the usage dashboard is. CHANGELOG entry. Short report to Craig 2.

## Do NOT do
Notifications, push, Cloudflare, widget (Phase 2 and 3). Groups backend. Blaze plan or any card. New libraries without asking. Whole-file rewrites (see CLAUDE.md).

## Tests
Test the new behavior once: allow-list and rules (Playground), a data-layer round trip on Firestore, import. No redundant suites.

## Definition of done
John signs in on his iPhone Home Screen app, his data is there and syncs with the laptop, a non-invited account is blocked, the hosted URL is recorded in the README, and the changelog is updated.
