---
name: feedback-concise-agent-messages
description: "John wants all agent messages, to him and between agents, to be short and contain only the context needed for the task"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 625ba887-4e63-4656-85ea-581da3adaa22
  modified: 2026-11-04T15:07:55.365Z
---

Keep every message concise: replies to John and agent-to-agent messages (Craig 2, Dan 2, Ava). Give only the context necessary for the task. No recaps, no restating the plan, no re-explaining decisions the recipient already has.

**Why:** John stopped a tool call on 2026-11-04 because my message to Dan 2 was longer than needed. He is watching the inter-agent traffic and wants it lean.

**How to apply:** Lead with the decision or ask. A routine acknowledgement is one or two lines. Point to a file instead of copying its contents. Milestone reports: built, tests, deviations, questions.
