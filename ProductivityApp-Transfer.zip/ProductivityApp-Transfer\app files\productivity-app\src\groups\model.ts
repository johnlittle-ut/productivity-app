// Interactive tab model (groups share AVAILABILITY only, never event details).

/** Group and member colors are numbered slots; --g1..--g6 in index.css give each slot its color per theme. */
export type GroupColor = 1 | 2 | 3 | 4 | 5 | 6
export const GROUP_SLOTS: readonly GroupColor[] = [1, 2, 3, 4, 5, 6]

/** CSS value for a slot, e.g. `var(--g3)`. */
export const groupColorVar = (slot: unknown): string => `var(--g${toColorSlot(slot)})`

// Reference colors used to move older saved hex colors to the nearest slot.
const MIGRATION_REFS: [string, GroupColor][] = [
  // old palette
  ['#8e5bf6', 5], ['#16a085', 3], ['#e0457b', 2], ['#d68a00', 4], ['#2f9e44', 3], ['#0e86d4', 1], ['#2f7bf6', 1],
  // light slots
  ['#4f7390', 1], ['#a85a54', 2], ['#6b7d4a', 3], ['#8c6d20', 4], ['#85607e', 5], ['#7d7468', 6],
  // dark slots
  ['#7d8794', 1], ['#b9756f', 2], ['#8a9a6b', 3], ['#b89a5a', 4], ['#9a7494', 5], ['#a39a8c', 6],
]

const rgb = (hex: string): [number, number, number] => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)) as [number, number, number]

/** Accepts a slot number or an old hex string and returns a valid slot (1 to 6). */
export function toColorSlot(value: unknown): GroupColor {
  if (typeof value === 'number' && Number.isInteger(value) && value >= 1 && value <= 6) return value as GroupColor
  if (typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value)) {
    const [r, g, b] = rgb(value)
    let best: GroupColor = 1
    let bestDist = Infinity
    for (const [ref, slot] of MIGRATION_REFS) {
      const [rr, gg, bb] = rgb(ref)
      const d = (r - rr) ** 2 + (g - gg) ** 2 + (b - bb) ** 2
      if (d < bestDist) {
        bestDist = d
        best = slot
      }
    }
    return best
  }
  return 1
}

export interface Member {
  id: string
  name: string
  color: GroupColor
}

export interface Group {
  id: string
  name: string
  color: GroupColor
  memberIds: string[]
  createdAt: number
}

export type Response = 'pending' | 'accepted' | 'declined'

export interface GroupEventInput {
  title: string
  date: string
  startTime: string
  endTime: string
  notes: string
}

export interface GroupEvent extends GroupEventInput {
  id: string
  groupId: string
  creatorId: string
  createdAt: number
  cancelled?: boolean
  responses: Record<string, Response> // memberId -> response
}

export interface Invitation {
  event: GroupEvent
  group: Group
}

/** The ONLY thing published about a person's personal calendar: when they are busy. No titles, no notes. */
export interface BusyInterval {
  userId: string
  start: number // absolute instant, epoch ms (timezone-free)
  end: number
}

export const LINK_TTL_MS = 20 * 60 * 1000

export interface InviteLink {
  token: string
  groupId: string
  url: string
  createdAt: number
  expiresAt: number
  usedAt: number | null
}

export type RedeemResult =
  | { ok: true; groupId: string }
  | { ok: false; reason: 'invalid' | 'expired' | 'used' | 'already-member' }

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  return (parts.length === 1 ? parts[0].slice(0, 2) : parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}
