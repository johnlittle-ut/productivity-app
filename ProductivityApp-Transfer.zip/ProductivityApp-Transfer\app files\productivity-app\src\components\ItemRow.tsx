import { useRef, useState } from 'react'
import { useGroupColor } from '../groups/hooks'
import { formatTimeShort, shortDate, weekdayName } from '../lib/format'
import type { Occurrence } from '../lib/schedule'

function TypeGlyph({ type }: { type: 'event' | 'task' }) {
  // Different shape as well as color: event = clock, task = flag
  return (
    <svg
      className={`glyph ${type}`}
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-label={type}
    >
      {type === 'event' ? (
        <>
          <circle cx="12" cy="12" r="9" />
          <path d="M12 7v5l3 2" />
        </>
      ) : (
        <>
          <path d="M5 21V4" />
          <path d="M5 4h13l-3 4.5 3 4.5H5" />
        </>
      )}
    </svg>
  )
}

interface Props {
  occ: Occurrence
  onCheck: (occ: Occurrence) => void
  onOpen: (occ: Occurrence) => void
  /** Show the occurrence's date (used in the Overdue block). */
  showDate?: boolean
  /** Calendar agenda style: the time sits in a left gutter instead of inline. */
  timeInGutter?: boolean
  /** Tasks only: swipe right to move to tomorrow. */
  onMove?: (occ: Occurrence) => void
}

const SWIPE_COMMIT = 90

export function ItemRow({ occ, onCheck, onOpen, showDate, timeInGutter, onMove }: Props) {
  const { item } = occ
  const canMove = !!onMove && item.type === 'task' && !occ.done
  const [dx, setDx] = useState(0)
  const drag = useRef<{ x: number; y: number; active: boolean } | null>(null)
  const swiped = useRef(false)
  const onPointerDown = (e: React.PointerEvent) => {
    swiped.current = false
    drag.current = { x: e.clientX, y: e.clientY, active: false }
  }
  const onPointerMove = (e: React.PointerEvent) => {
    const d = drag.current
    if (!d) return
    const mx = e.clientX - d.x
    const my = e.clientY - d.y
    if (!d.active) {
      if (mx > 12 && mx > Math.abs(my) * 1.5) {
        d.active = true
        e.currentTarget.setPointerCapture(e.pointerId)
      } else return
    }
    setDx(Math.max(0, Math.min(mx, 140)))
  }
  const onPointerUp = () => {
    const d = drag.current
    drag.current = null
    if (!d?.active) return
    swiped.current = true
    if (dx >= SWIPE_COMMIT) onMove?.(occ)
    setDx(0)
  }
  const inlineTime = !timeInGutter && occ.startTime
  const groupColor = useGroupColor(item.groupId)
  const row = (
    <li className="item-row" style={groupColor ? ({ '--event': groupColor } as React.CSSProperties) : undefined}>
      {timeInGutter && (
        <span className="gutter">{occ.startTime ? formatTimeShort(occ.startTime) : ''}</span>
      )}
      <button
        className={`check ${item.type}`}
        onClick={() => onCheck(occ)}
        aria-label={`Mark "${item.title}" done`}
      />
      <button className="item-body" onClick={() => onOpen(occ)}>
        <span className="item-title">
          <TypeGlyph type={item.type} />
          {inlineTime && (
            <>
              <span className="item-time">{formatTimeShort(occ.startTime!)}</span>
              <span className="item-dash">-</span>
            </>
          )}
          <span className="item-name">{item.title}</span>
          {item.repeat && <span className="repeat-mark" title="Repeats"> ↻</span>}
        </span>
        {showDate && (
          <span className="item-sub overdue-date">
            Due {weekdayName(occ.date).slice(0, 3)} {shortDate(occ.date)}
          </span>
        )}
        {item.notes && <span className="item-sub">{item.notes}</span>}
      </button>
    </li>
  )
  if (!canMove) return row
  return (
    <li className="swipe-wrap">
      <span className="swipe-action" aria-hidden="true">
        Move to tomorrow
      </span>
      <div
        className="swipe-row"
        style={{ transform: `translateX(${dx}px)`, transition: dx === 0 ? 'transform 0.15s' : 'none' }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={() => {
          drag.current = null
          setDx(0)
        }}
        onClickCapture={(e) => {
          if (swiped.current) {
            e.stopPropagation()
            e.preventDefault()
            swiped.current = false
          }
        }}
        onTouchEnd={(e) => {
          if (swiped.current) e.stopPropagation()
        }}
      >
        <ul className="swipe-inner">{row}</ul>
      </div>
    </li>
  )
}
