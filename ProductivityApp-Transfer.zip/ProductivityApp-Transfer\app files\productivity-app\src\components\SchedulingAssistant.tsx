// Outlook-style "Scheduling Assistant" for a group event: each member's busy time for the chosen day,
// the proposed time as a band, who it clashes with, and suggested times when everyone is free.

import type { BusyInterval, Member } from '../groups/model'
import { groupColorVar } from '../groups/model'
import { busyForDay, DAY_END_MIN, DAY_START_MIN, overlaps, suggestSlots } from '../lib/busy'
import { formatTimeShort } from '../lib/format'
import { toMinutes } from '../lib/gridLayout'
import { Avatar } from './Avatar'

const HOUR_PX = 14
const GRID_PX = ((DAY_END_MIN - DAY_START_MIN) / 60) * HOUR_PX
const hhmm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
const hourLabel = (h: number) => (h < 12 ? `${h}a` : h === 12 ? '12p' : `${h - 12}p`)

interface Props {
  lanes: Member[]
  busy: BusyInterval[]
  date: string
  startTime: string
  endTime: string
  meId: string
  tz: string
  onChange: (startTime: string, endTime: string) => void
}

export function SchedulingAssistant({ lanes, busy, date, startTime, endTime, meId, tz, onChange }: Props) {
  const dayBusy = busyForDay(busy, date, tz)
  const start = startTime ? toMinutes(startTime) : 18 * 60
  const end = endTime && toMinutes(endTime) > start ? toMinutes(endTime) : start + 60
  const duration = end - start
  const proposed = { start, end }
  const clashing = lanes.filter((m) => dayBusy.some((b) => b.userId === m.id && overlaps(b, proposed)))
  const suggestions = suggestSlots(dayBusy, duration)
  const n = Math.max(lanes.length, 1)
  const hours = Array.from({ length: (DAY_END_MIN - DAY_START_MIN) / 60 + 1 }, (_, i) => DAY_START_MIN / 60 + i)
  const clampStart = (s: number) => Math.max(DAY_START_MIN, Math.min(s, 24 * 60 - 30 - 1))

  function pick(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect()
    const raw = DAY_START_MIN + ((e.clientY - rect.top) / HOUR_PX) * 60
    const s = clampStart(Math.round(raw / 30) * 30)
    onChange(hhmm(s), hhmm(Math.min(s + duration, 23 * 60 + 59)))
  }

  return (
    <section className="assist" aria-label="Scheduling assistant">
      <h3 className="detail-sub">Scheduling assistant</h3>

      <div className="assist-lanes-head">
        {lanes.map((m) => (
          <span key={m.id} className="assist-lane-name">
            <Avatar member={m} size={22} />
            <span>{m.id === meId ? 'You' : m.name.split(' ')[0]}</span>
          </span>
        ))}
      </div>

      <div className="assist-grid" style={{ height: GRID_PX }} onClick={pick} role="presentation">
        {hours.map((h, i) => (
          <div key={h} className="assist-hour" style={{ top: i * HOUR_PX }}>
            {i % 2 === 0 && <span>{hourLabel(h)}</span>}
          </div>
        ))}
        {lanes.map((m, i) => (
          <div
            key={m.id}
            className="assist-lane"
            style={{ left: `calc(var(--assist-gutter) + (100% - var(--assist-gutter)) / ${n} * ${i})`, width: `calc((100% - var(--assist-gutter)) / ${n})` }}
          >
            {dayBusy
              .filter((b) => b.userId === m.id && b.end > DAY_START_MIN)
              .map((b) => (
                <i
                  key={`${b.start}-${b.end}`}
                  className="assist-busy"
                  style={{
                    top: ((Math.max(b.start, DAY_START_MIN) - DAY_START_MIN) / 60) * HOUR_PX,
                    height: ((Math.min(b.end, DAY_END_MIN) - Math.max(b.start, DAY_START_MIN)) / 60) * HOUR_PX,
                    background: groupColorVar(m.color),
                  }}
                />
              ))}
          </div>
        ))}
        <div
          className="assist-proposed"
          style={{
            top: ((Math.max(start, DAY_START_MIN) - DAY_START_MIN) / 60) * HOUR_PX,
            height: Math.max(((Math.min(end, DAY_END_MIN) - Math.max(start, DAY_START_MIN)) / 60) * HOUR_PX, 4),
          }}
        />
      </div>

      <p className={`assist-status ${clashing.length ? 'clash' : 'free'}`} role="status">
        {clashing.length === 0
          ? 'Everyone is free then.'
          : `Busy then: ${clashing.map((m) => (m.id === meId ? 'You' : m.name.split(' ')[0])).join(', ')}.`}
      </p>

      <div className="assist-suggest">
        <span className="small muted">Suggested times</span>
        {suggestions.length === 0 ? (
          <span className="small muted">No time this day works for everyone.</span>
        ) : (
          <div className="chip-row">
            {suggestions.map((s) => (
              <button
                key={s.start}
                type="button"
                className={`suggest-chip${s.start === start && s.end === end ? ' on' : ''}`}
                onClick={() => onChange(hhmm(s.start), hhmm(s.end))}
              >
                {formatTimeShort(hhmm(s.start))} – {formatTimeShort(hhmm(s.end))}
              </button>
            ))}
          </div>
        )}
      </div>
      <p className="small muted">Tap the grid to move the start time.</p>
    </section>
  )
}
