import { useState } from 'react'
import { Avatar } from '../components/Avatar'
import { ChoiceDialog } from '../components/Dialogs'
import { BackIcon } from '../components/icons'
import { useLinks, useMembers, useNow } from '../groups/hooks'
import { groupLayer } from '../groups/index'
import { GROUP_SLOTS, groupColorVar, type Group, type InviteLink } from '../groups/model'
import { formatCountdown, linkStatus, remainingMs } from '../lib/groupLogic'

interface Props {
  group: Group
  onBack: () => void
  onLeft: () => void
}

function InvitePanel({ link, onNew }: { link: InviteLink; onNew: () => void }) {
  const now = useNow(1000)
  const status = linkStatus(link, now)
  const [note, setNote] = useState('')
  const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'

  async function copy() {
    try {
      await navigator.clipboard.writeText(link.url)
      setNote('Link copied.')
    } catch {
      setNote('Could not copy. Select the link and copy it manually.')
    }
  }

  async function share() {
    try {
      await navigator.share({ title: 'Join my group', url: link.url })
    } catch {
      /* cancelled */
    }
  }

  if (status === 'used') {
    return (
      <div className="invite-panel">
        <p>This link was already used.</p>
        <button className="btn" onClick={onNew}>
          New link
        </button>
      </div>
    )
  }
  if (status === 'expired') {
    return (
      <div className="invite-panel">
        <p>This link expired.</p>
        <button className="btn" onClick={onNew}>
          New link
        </button>
      </div>
    )
  }
  return (
    <div className="invite-panel">
      <input className="input" readOnly value={link.url} onFocus={(e) => e.currentTarget.select()} aria-label="Invite link" />
      <div className="row">
        <button className="btn primary" onClick={copy}>
          Copy
        </button>
        {canShare && (
          <button className="btn" onClick={share}>
            Share
          </button>
        )}
      </div>
      <p className="small muted">
        One-time link. Expires in <strong>{formatCountdown(remainingMs(link, now))}</strong>.
      </p>
      {note && <p className="small">{note}</p>}
    </div>
  )
}

export function GroupSettings({ group, onBack, onLeft }: Props) {
  const members = useMembers()
  const links = useLinks()
  const [name, setName] = useState(group.name)
  const [token, setToken] = useState<string | null>(null)
  const [leaving, setLeaving] = useState(false)
  const link = links.find((l) => l.token === token)


  async function saveName() {
    const t = name.trim()
    if (t && t !== group.name) await groupLayer.groups.update(group.id, { name: t })
    else setName(group.name)
  }

  async function invite() {
    const l = await groupLayer.links.create(group.id)
    setToken(l.token)
  }

  const people = group.memberIds.map((id) => members.find((m) => m.id === id)).filter((m) => !!m)

  return (
    <div className="group-settings">
      <div className="sub-head">
        <button className="icon-btn" onClick={onBack} aria-label="Back to group">
          <BackIcon />
        </button>
        <h2>Group settings</h2>
        <span className="icon-btn-spacer" />
      </div>

      <section className="card">
        <h2>Name</h2>
        <input
          className="input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          onBlur={() => void saveName()}
          onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
          aria-label="Group name"
        />
      </section>

      <section className="card">
        <h2>Color</h2>
        <div className="swatches" role="group" aria-label="Group color">
          {GROUP_SLOTS.map((c) => (
            <button
              key={c}
              className={`swatch${c === group.color ? ' on' : ''}`}
              style={{ background: groupColorVar(c) }}
              onClick={() => void groupLayer.groups.update(group.id, { color: c })}
              aria-label={`Color ${c}`}
              aria-pressed={c === group.color}
            />
          ))}
        </div>
        <p className="small muted">Used for this group's events on your calendar.</p>
      </section>

      <section className="card">
        <h2>Members ({people.length})</h2>
        <ul className="member-list">
          {people.map((m) => (
            <li key={m.id}>
              <Avatar member={m} />
              <span>{m.id === groupLayer.me.id ? `${m.name} (you)` : m.name}</span>
            </li>
          ))}
        </ul>
        <button className="btn wide" onClick={() => void invite()}>
          Invite someone
        </button>
        {link && <InvitePanel link={link} onNew={() => void invite()} />}
      </section>

      <section className="card">
        <h2>Notifications</h2>
        <label className="toggle disabled">
          <input type="checkbox" disabled />
          <span>Group notifications (coming soon)</span>
        </label>
      </section>

      <button className="btn danger wide" onClick={() => setLeaving(true)}>
        Leave group
      </button>

      {leaving && (
        <ChoiceDialog<'leave'>
          title={`Leave ${group.name}?`}
          message="You will stop seeing this group. Events you accepted stay on your calendar."
          choices={[{ label: 'Leave group', value: 'leave', danger: true }]}
          onChoose={async () => {
            await groupLayer.groups.leave(group.id)
            setLeaving(false)
            onLeft()
          }}
          onCancel={() => setLeaving(false)}
        />
      )}
    </div>
  )
}
