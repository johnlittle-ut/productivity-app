// Dev-only sample data modeled on John's OneNote page. Dates are relative to "today".

import { addDays, clampedDay, dayOfWeek, parseDate, toDateString } from '../lib/dates'
import type { NewItem } from '../types'

export interface SampleData {
  items: NewItem[]
  shopping: { title: string; section: 'groceries' | 'general' }[]
  todos: { title: string; notes?: string; dueDate?: string; urgent?: boolean }[]
}

/** First date on or after `from` that falls on `weekday` (0 = Sun ... 6 = Sat). */
function nextWeekday(from: string, weekday: number): string {
  return addDays(from, (weekday - dayOfWeek(from) + 7) % 7)
}

export function buildSampleData(today: string): SampleData {
  const { y, m } = parseDate(today)
  const monthStart = toDateString(y, m, 1)

  return {
    items: [
      { title: 'Rent due', type: 'task', date: monthStart, repeat: { freq: 'monthly' } },
      { title: 'LG&E bill due', type: 'task', date: clampedDay(y, m, 15), repeat: { freq: 'monthly' } },
      // 31st: demonstrates month-end clamping (first occurrence Jan 31, repeats on last day of shorter months)
      { title: 'Storage unit payment', type: 'task', date: toDateString(y, 1, 31), repeat: { freq: 'monthly' } },
      {
        title: 'Module assignments due',
        type: 'task',
        date: nextWeekday(today, 0),
        startTime: '23:59',
        showOnCalendar: true,
        repeat: { freq: 'weekly' },
      },
      {
        title: 'Community groups',
        type: 'event',
        date: nextWeekday(monthStart, 3),
        startTime: '19:00',
        endTime: '20:30',
        repeat: { freq: 'weekly' },
      },
      {
        title: 'Thrive',
        type: 'event',
        date: nextWeekday(monthStart, 5),
        startTime: '18:30',
        endTime: '20:00',
        repeat: { freq: 'weekly' },
      },
      {
        title: "Men's bonfire (church)",
        type: 'event',
        date: addDays(today, 3),
        startTime: '19:00',
        notes: 'Bring a chair.',
      },
      {
        title: 'Night out with friends',
        type: 'event',
        date: addDays(today, 5),
        startTime: '21:00',
        notes:
          'Pregame at my apartment around 8:30. Everyone is meeting at the bar by 9:00, so leave a few minutes early to find parking downtown.',
      },
      { title: 'Follow up with Trevor on seeing his new place', type: 'task', date: addDays(today, 2) },
      { title: 'Make sure apartment is tip top shape for hosting', type: 'task', date: addDays(today, 4) },
      // Calendar grid demo: an event overlapping Thrive, an all-day event, one today
      { title: 'Study group', type: 'event', date: nextWeekday(monthStart, 5), startTime: '19:00', endTime: '20:00' },
      { title: "Roommate's birthday", type: 'event', date: addDays(today, 1) },
      { title: 'Lunch with Alex', type: 'event', date: today, startTime: '12:00', endTime: '13:00' },
      // Overdue, unfinished
      { title: 'Submit expense report', type: 'task', date: addDays(today, -3) },
    ],
    shopping: [
      { title: 'Milk', section: 'groceries' },
      { title: 'Eggs', section: 'groceries' },
      { title: 'Coffee filters', section: 'groceries' },
      { title: 'Paper towels', section: 'general' },
      { title: 'Light bulbs', section: 'general' },
      { title: 'Laundry detergent', section: 'general' },
    ],
    todos: [
      { title: 'Renew car registration', dueDate: addDays(today, 3) },
      { title: 'Call the dentist', notes: 'Ask about the March cleaning slot.' },
      { title: 'Organize closet' },
      { title: 'Book flights for spring break', urgent: true },
      { title: 'File taxes', dueDate: addDays(today, 40) },
    ],
  }
}
