// Check-off, undo and the 24-hour cleanup. Pure functions; data-layer writes live in data/actions.ts.

import type { Item } from '../types'

export const DAY_MS = 24 * 60 * 60 * 1000

/** Patch that marks one occurrence done (a repeating item records just that date). */
export function completeOccurrence(item: Item, date: string, now: number): Partial<Item> {
  if (item.repeat) return { completedOccurrences: { ...item.completedOccurrences, [date]: now } }
  return { done: true, doneAt: now }
}

export function undoOccurrence(item: Item, date: string): Partial<Item> {
  if (item.repeat) {
    const { [date]: _removed, ...rest } = item.completedOccurrences
    void _removed
    return { completedOccurrences: rest }
  }
  return { done: false, doneAt: null }
}

export interface CleanupPlan {
  deleteIds: string[]
  updates: { id: string; patch: Partial<Item> }[]
}

/**
 * Anything checked off 24 hours ago or more is permanently removed.
 * - Non-repeating items are deleted.
 * - For repeating items, the finished occurrence is dropped for good by moving its date
 *   into skippedDates (so it does not reappear as "not done").
 */
export function cleanupPlan(items: Item[], now: number): CleanupPlan {
  const cutoff = now - DAY_MS
  const plan: CleanupPlan = { deleteIds: [], updates: [] }
  for (const item of items) {
    if (!item.repeat) {
      if (item.done && item.doneAt !== null && item.doneAt <= cutoff) plan.deleteIds.push(item.id)
      continue
    }
    const expired = Object.entries(item.completedOccurrences).filter(([, at]) => at <= cutoff)
    if (expired.length === 0) continue
    const expiredDates = expired.map(([date]) => date)
    const remaining = Object.fromEntries(
      Object.entries(item.completedOccurrences).filter(([date]) => !expiredDates.includes(date)),
    )
    plan.updates.push({
      id: item.id,
      patch: { completedOccurrences: remaining, skippedDates: [...item.skippedDates, ...expiredDates] },
    })
  }
  return plan
}

export interface RecentlyCompleted {
  item: Item
  date: string
  doneAt: number
}

/** Occurrences checked off within the last 24 hours, newest first (for the Undo area). */
export function recentlyCompleted(items: Item[], now: number): RecentlyCompleted[] {
  const cutoff = now - DAY_MS
  const out: RecentlyCompleted[] = []
  for (const item of items) {
    if (!item.repeat) {
      if (item.done && item.doneAt !== null && item.doneAt > cutoff) out.push({ item, date: item.date, doneAt: item.doneAt })
      continue
    }
    for (const [date, at] of Object.entries(item.completedOccurrences)) {
      if (at > cutoff) out.push({ item, date, doneAt: at })
    }
  }
  return out.sort((a, b) => b.doneAt - a.doneAt)
}
