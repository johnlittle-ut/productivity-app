# Ava: color tokens (chosen by John 2026-11-04)

Light = option E (Terracotta + Teal). Dark = option R (Espresso + Deep Copper), chosen by John 2026-11-04 (earlier H, F, K). Same espresso background as K, darker/softer accent, event, task and danger colors. Not yet sent to Craig 2 or Dan 2; John decides when.

## CSS variables

```css
:root {
  --bg: #fbf5ee;
  --surface: #f2e8dc;
  --text: #2a1d17;
  --muted: #7a6555;       /* darkened from #85705f for 4.5:1 text contrast */
  --border: #e8dac9;
  --accent: #c2512f;      /* FAB, Today pill, selected day, active tab */
  --on-accent: #ffffff;
  --event: #137a7f;       /* deep teal + clock icon */
  --task: #a67500;        /* darker mustard (was #c99a1a, only 2.4:1) + flag icon */
  --danger: #a8281f;      /* Overdue only */
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #14100d;
    --surface: #201915;
    --text: #f3e9df;
    --muted: #a8937f;
    --border: #33281f;
    --accent: #c47a4c;      /* deep copper */
    --on-accent: #1f0e04;
    --event: #6ba89d;       /* muted seafoam */
    --task: #cfab52;        /* muted honey */
    --danger: #e5594f;
  }
}
```

## Group / avatar palette (proposed, not yet sent; replaces the bright blue/pink/teal/purple/gold)
Used for group dots, avatar circles and the invitation card border in Interactive. Avatar initials: `--on-group` (dark `#14100d`, light `#ffffff`).

| Slot | Dark | Light |
|---|---|---|
| 1 slate | #7d8794 | #4f7390 |
| 2 clay-rose | #b9756f | #a85a54 |
| 3 sage | #8a9a6b | #6b7d4a |
| 4 ochre | #b89a5a | #8c6d20 |
| 5 plum | #9a7494 | #85607e |
| 6 stone | #a39a8c | #7d7468 |

Light values checked: white initials on each pass 4.5:1 or better (ochre darkened from #9a7a2c for that). Dark values pass vs `--bg`.

**Implementation note (audit of src, 2026-11-04):** these hard-coded colors are still bright and off-theme:
- `groups/model.ts` `GROUP_COLORS` (6 hex values) and `groups/mockLayer.ts` member colors (`#e0457b`, `#16a085`, `#d68a00`, `#8e5bf6`, and "me" `#2f7bf6`). Light and dark need different values, so store a **slot (1 to 6)** and resolve it with CSS variables `--g1..--g6` (defined per mode in `index.css`), not a hex in data. Needs Dan 2 (data shape) via Craig 2.
- `.free-band` and `.status.accepted` use `#2f9e44` green: replace with `--good` (dark `#8a9a6b`, light `#5f7040`).
- `.avatar { color:#fff }`: use `--on-group` (dark `#14100d`, light `#ffffff`).

Also: Overdue red in dark `#d1604f` (less neon); keyboard focus ring should be `outline: 2px solid var(--accent)` on `:focus-visible` only (the white box around the active tab is the browser default).
See `harmonized-colors.png`.

## Notes
- Accent is no longer the same color as events (the old blue did both jobs).
- Dark K is the dark counterpart of light E: same hue families (copper/terracotta accent, teal-family events, yellow-gold tasks).
- Group colors (Interactive tab) still need their own palette that avoids the event/task/accent colors.
- Contrast checked vs --bg (2026-11-04): all text and icon colors pass (text 3:1+ for icons, 4.5:1+ for text). Light accent/white button text is 4.65:1. Tinted event/task blocks (color at ~15% alpha) not separately checked.
