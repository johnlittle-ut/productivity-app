# HOME-CHECKLIST.md: what to do on the personal laptop

For John. Written by Craig 2, 2026-11-04. Short on purpose; details live in the handoffs.

## Before you leave work
- [ ] Ask Dan 2 to run `git bundle create productivity-app.bundle --all` in the repo.
- [ ] Use Settings > **Export JSON** in the app (your real data, if any).
- [ ] Copy to a USB drive or personal cloud: the bundle, the export file, and the planning files (`CLAUDE.md`, `Plan.md`, `CHANGELOG.md`, `HOME-CHECKLIST.md`, `MANUAL-CHECKLIST.md`, folders `handoffs/` and `design/`).

## At home: setup (about 30 minutes)
1. Install **Node.js (LTS)**, **Git**, **VS Code** and the **Claude Code extension**.
2. Have ready: your **personal Google account** (for Firebase) and a **personal GitHub account**.
3. Put the planning files in a project folder; clone the code from the bundle into it.
4. Open the folder in VS Code and start **two new chats**: **Dan 2** (coder) and **Craig 2** (planner). Chats from the work laptop do not carry over; the files do.
5. In each chat, say: "Read CLAUDE.md, Plan.md and HOME-CHECKLIST.md." Tell Dan 2: "Do handoffs/003-backend-connect.md."

## Phase 1B: backend (Dan 2 guides you click by click)
Doc: `handoffs/003-backend-connect.md`. In short: Firebase project (free plan, no card) > Google sign-in > put your email on the invite list **first** > security rules > replace local data with Firestore > import your export > deploy > install on iPhone.
**On the iPhone:** open the hosted link in **Safari**, Share > **Add to Home Screen**, open it from the icon, sign in with Google, confirm your data is there. Then check sync both ways with the laptop.
**To invite a friend later:** add their lowercased Google email to the invite list in the Firebase console (Dan 2 shows you how), then send them the link and tell them to Add to Home Screen.
**Your choice to confirm:** the Interactive tab is hidden in the hosted app until the groups backend exists (flag in the handoff).

## Phase 2: notifications
Doc: `handoffs/005-notifications.md`. Needs a free **Cloudflare account** (no card). You must make **one decision** with Dan 2 first: how the server finds what's due (section C of that doc). Then in the app: Settings > **Enable notifications**, send a test, and watch it for a few days. Requires iOS 16.4+ and the app opened from the Home Screen icon.

## Phase 3: widget (read-only, Scriptable)
Plan in `Plan.md` section 8. You install the free **Scriptable** app; Dan 2 writes the script; your own secret link feeds it. Not interactive (no check-off). Craig 2 writes the handoff when you reach this.

## Phase 4: real groups
Plan in `Plan.md` Phase 4. Needs a **second Google account to test**. Backend items: per-group member lists, one busy document per member, group events with invites and accept or decline, one-time 20-minute invite links, and **group events anchored to a timezone**. Craig 2 writes the handoff when you reach this.

## Decisions still ahead of you
- Notification approach (Phase 2, section C).
- Whether to show the Interactive tab before real groups work.
- Native iPhone app: **decided against** for now (costs $99 a year; see Plan.md out of scope).

## If something breaks
Stop and tell Craig 2 the exact message you see (screenshot). Your data also lives in the Export JSON file, so keep one recent copy.
