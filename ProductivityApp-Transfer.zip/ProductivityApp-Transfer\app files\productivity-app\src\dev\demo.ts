// Dev-only: opening the app with `?demo` loads the sample data if the app is empty.

import { dataLayer } from '../data'
import { readOnce } from '../data/actions'
import { todayIn } from '../lib/dates'
import { buildSampleData } from './sample'

export async function maybeLoadDemo(): Promise<void> {
  if (!new URLSearchParams(location.search).has('demo')) return
  const existing = await readOnce(dataLayer.items.subscribe)
  if (existing.length > 0) return
  const settings = await dataLayer.settings.get()
  const data = buildSampleData(todayIn(settings.timezone))
  for (const item of data.items) await dataLayer.items.add(item)
  for (const s of data.shopping) await dataLayer.shopping.add(s.title, '', s.section)
  for (const t of data.todos) {
    const entry = await dataLayer.todos.add(t.title, t.notes)
    if (t.dueDate || t.urgent) await dataLayer.todos.update(entry.id, { dueDate: t.dueDate, urgent: t.urgent })
  }
}
