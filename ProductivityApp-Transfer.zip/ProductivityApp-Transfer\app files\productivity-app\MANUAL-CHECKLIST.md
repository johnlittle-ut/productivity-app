# Manual checklist (John)

Start: `npm run dev`, open http://localhost:5173/?demo (loads sample data if empty).
Legend: **[desktop]** = already checked by Dan 2 in a desktop browser, re-check if you like. **[iPhone: untested]** = never run on a real device, please check.

## Items and Schedule
- [ ] Add an **event** with a time (+ button). Shows as `6:30pm - Title` with a blue clock. [desktop]
- [ ] Add a **task** with no time. Shows in the checklist with an orange flag. [desktop]
- [ ] Add a **weekly** and a **monthly** repeating item. They appear on every matching date. [desktop]
- [ ] Monthly on the 31st lands on the last day of shorter months (sample "Storage unit payment"). [desktop]
- [ ] Edit a repeating item → **This occurrence only** changes just that date; **All occurrences** changes all. [desktop]
- [ ] Delete a repeating item → one vs all works; a normal delete asks to confirm. [desktop]
- [ ] Mondays are bold with a divider; every date is shown even when empty; scrolling loads more dates. [desktop]
- [ ] Overdue block shows unfinished past tasks only (past events do not). [desktop]

## Check-off, undo, 24-hour clear
- [ ] Check off an item: it disappears and a toast offers Undo. [desktop]
- [ ] Settings → Recently completed shows it with Undo. [desktop]
- [ ] Settings → Developer → "Run cleanup as if 24h later" removes it for good. [desktop]
- [ ] Checking off one repeating occurrence leaves the other occurrences. [desktop]

## Calendar tab
- [ ] Day / Week toggle works; hour grid shows event blocks by start/end; overlapping events sit side by side; red now-line on today. [desktop]
- [ ] Prev / next / Today work (by day in Day view, by week in Week view); selected day and view stay when switching tabs. [desktop]
- [ ] Tap an empty slot: new event at that hour. A task shows on the grid only with "Show on calendar" on. [desktop]
- [ ] **Swipe left/right** on the Calendar moves the day/week; the hour grid still scrolls up and down. [iPhone: untested]
- [ ] Week view columns are readable and tappable on the phone. [iPhone: untested]

## To-Do and Shopping
- [ ] New entries go to the bottom. [desktop]
- [ ] **Drag the ⋮⋮ handle** to reorder; page still scrolls normally when you swipe elsewhere. [desktop mouse tested; iPhone touch: untested]
- [ ] Circle checks off (hides, Undo toast); tap the text to edit/delete; To-Do has notes. [desktop]
- [ ] Shopping: the Groceries / General tabs switch lists; new items go to the selected tab; Edit → List moves an item. [desktop]

## Backup and data
- [ ] Settings → Export JSON downloads a file. Clear all data → Import JSON restores everything. [desktop]
- [ ] Import of a wrong/damaged file shows a plain-language error. [desktop]
- [ ] Reload the page: data is still there. [desktop]

## Look and feel
- [ ] Dark and light mode both look right (switch your system setting). [desktop dark tested]
- [ ] Add/Edit sheet: **keyboard does not hide Save**, native date/time pickers open. [iPhone: untested]
- [ ] Bottom tab bar and sheets clear the **home indicator / notch** (safe areas). [iPhone: untested]
- [ ] Open from the iPhone: Safari → the "Network" address `npm run dev` prints (same Wi-Fi; may be blocked on a work network or VPN). [iPhone: untested]

## Not testable yet (needs hosting over HTTPS)
- Add to Home Screen, full-screen launch, offline on the iPhone. (Offline reload was verified on desktop with the production build.)

## Interactive tab (mock data)
Use Settings → Developer → "Seed mock groups" to reset. Everything here is fake data on this device.
- [ ] Five tabs fit in one row; the Interactive tab opens. [desktop]
- [ ] A pending invite card shows group, title, time, sender, and "You're busy then" when it overlaps your events. [desktop]
- [ ] Accept: the event appears on Schedule and Calendar in the group color, and the invite disappears. Decline: nothing is added. [desktop]
- [ ] Open a group: one lane per member, busy blocks have no text, green "Everyone free" band appears. [desktop]
- [ ] Add group event (button or tap an empty slot); it shows in the group color; tap it for responses; edit and cancel as creator. [desktop]
- [ ] Group settings: rename, pick color, Invite someone shows a link with a 20:00 countdown; Copy works; after expiry or use it says so. [desktop]
- [ ] Join with link: paste a link from Settings → Developer → "Make a join link"; reusing it gives a friendly message. [desktop]
- [ ] Leave group asks to confirm. [desktop]
- [ ] Share button opens the iPhone share sheet. [iPhone: untested]
- [ ] Lane grid scrolls smoothly and swiping changes the day without fighting the scroll. [iPhone: untested]
