// Shared screen for the Shopping List and the To-Do list: type to add (new entries go to the bottom),
// drag the handle to reorder, circle to check off (hidden, then deleted after 24 hours), tap text to edit.
// The shopping list has two sections (Groceries / General) with one add line and a picker.

import {
  closestCenter,
  DndContext,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core'
import { SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { useState } from 'react'
import { ChoiceDialog, Sheet } from '../components/Dialogs'
import { moveEntry, setEntryDone, storeFor, type ListKind } from '../data/actions'
import { ORDER_GAP } from '../data/defaults'
import { shortDate, weekdayName } from '../lib/format'
import { sectionOf, SHOPPING_SECTIONS } from '../lib/order'
import { isUrgent, sortTodos, urgencyGroup } from '../lib/urgency'
import type { ListEntry, ListSection } from '../types'

interface Props {
  kind: ListKind
  entries: ListEntry[]
  addPlaceholder: string
  emptyText: string
  withNotes: boolean
  /** Show Groceries / General sections (shopping list). */
  sectioned?: boolean
  /** To-Do only: urgency marks, due dates and urgent-first sorting (needs today). */
  urgency?: boolean
  today?: string
  onToast: (message: string, undo?: () => void) => void
}

function SectionPicker({ value, onChange, label }: { value: ListSection; onChange: (s: ListSection) => void; label: string }) {
  return (
    <div className="segmented section-picker" role="group" aria-label={label}>
      {SHOPPING_SECTIONS.map((s) => (
        <button key={s.id} className={value === s.id ? 'on plain' : ''} onClick={() => onChange(s.id)} type="button">
          {s.label}
        </button>
      ))}
    </div>
  )
}

function Row({
  entry,
  today,
  onCheck,
  onEdit,
}: {
  entry: ListEntry
  today?: string
  onCheck: (e: ListEntry) => void
  onEdit: (e: ListEntry) => void
}) {
  const urgent = today ? isUrgent(entry, today) : false
  const { attributes, listeners, setNodeRef, setActivatorNodeRef, transform, transition, isDragging } = useSortable({
    id: entry.id,
  })
  const style = {
    transform: CSS.Translate.toString(transform ? { ...transform, x: 0 } : null),
    transition,
  }
  return (
    <li ref={setNodeRef} style={style} className={`list-row${isDragging ? ' dragging' : ''}`}>
      <button className="check todo" onClick={() => onCheck(entry)} aria-label={`Mark "${entry.title}" done`} />
      <button className="item-body" onClick={() => onEdit(entry)}>
        <span className="item-title">
          {urgent && (
            <span className="urgent-mark" aria-label="Urgent" title="Urgent">
              !
            </span>
          )}
          <span className="item-name">{entry.title}</span>
        </span>
        {entry.dueDate && (
          <span className={`item-sub`}>
            Due {weekdayName(entry.dueDate).slice(0, 3)} {shortDate(entry.dueDate)}
          </span>
        )}
        {entry.notes && <span className="item-sub">{entry.notes}</span>}
      </button>
      <button
        ref={setActivatorNodeRef}
        className="drag-handle"
        aria-label={`Reorder "${entry.title}"`}
        {...attributes}
        {...listeners}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <circle cx="9" cy="6" r="1.7" />
          <circle cx="15" cy="6" r="1.7" />
          <circle cx="9" cy="12" r="1.7" />
          <circle cx="15" cy="12" r="1.7" />
          <circle cx="9" cy="18" r="1.7" />
          <circle cx="15" cy="18" r="1.7" />
        </svg>
      </button>
    </li>
  )
}

/** One drag-sortable group of entries. */
function SortableGroup({
  entries,
  today,
  onCheck,
  onEdit,
  onReorder,
}: {
  entries: ListEntry[]
  today?: string
  onCheck: (e: ListEntry) => void
  onEdit: (e: ListEntry) => void
  onReorder: (group: ListEntry[], from: number, to: number) => void
}) {
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  )
  function onDragEnd({ active, over }: DragEndEvent) {
    if (!over || active.id === over.id) return
    const from = entries.findIndex((e) => e.id === active.id)
    const to = entries.findIndex((e) => e.id === over.id)
    if (from >= 0 && to >= 0) onReorder(entries, from, to)
  }
  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
      <SortableContext items={entries.map((e) => e.id)} strategy={verticalListSortingStrategy}>
        <ul className="list">
          {entries.map((entry) => (
            <Row key={entry.id} entry={entry} today={today} onCheck={onCheck} onEdit={onEdit} />
          ))}
        </ul>
      </SortableContext>
    </DndContext>
  )
}

function EntryEditor({
  entry,
  withNotes,
  sectioned,
  withUrgency,
  onSave,
  onDelete,
  onClose,
}: {
  entry: ListEntry
  withNotes: boolean
  sectioned: boolean
  withUrgency: boolean
  onSave: (patch: Partial<ListEntry>) => void
  onDelete: () => void
  onClose: () => void
}) {
  const [title, setTitle] = useState(entry.title)
  const [notes, setNotes] = useState(entry.notes)
  const [section, setSection] = useState<ListSection>(sectionOf(entry))
  const [dueDate, setDueDate] = useState(entry.dueDate ?? '')
  const [urgent, setUrgent] = useState(entry.urgent === true)
  const [confirming, setConfirming] = useState(false)

  function save() {
    const patch: Partial<ListEntry> = { title: title.trim() }
    if (withNotes) patch.notes = notes.trim()
    if (sectioned) patch.section = section
    if (withUrgency) {
      patch.dueDate = dueDate || undefined
      patch.urgent = urgent
    }
    onSave(patch)
  }

  return (
    <>
      <Sheet
        title="Edit"
        onCancel={onClose}
        footer={
          <button className="btn primary wide" disabled={!title.trim()} onClick={save}>
            Save
          </button>
        }
      >
        <label className="field">
          <span>Title</span>
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
        </label>
        {sectioned && (
          <div className="field">
            <span>List</span>
            <SectionPicker value={section} onChange={setSection} label="List" />
          </div>
        )}
        {withUrgency && (
          <>
            <label className="field">
              <span>Due date (optional)</span>
              <div className="row">
                <input className="input" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
                {dueDate && (
                  <button className="btn" type="button" onClick={() => setDueDate("")}>
                    Clear
                  </button>
                )}
              </div>
            </label>
            <label className="toggle">
              <input type="checkbox" checked={urgent} onChange={(e) => setUrgent(e.target.checked)} />
              <span>Urgent</span>
            </label>
          </>
        )}
        {withNotes && (
          <label className="field">
            <span>Notes</span>
            <textarea className="input" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </label>
        )}
        <button className="btn danger wide" onClick={() => setConfirming(true)}>
          Delete
        </button>
      </Sheet>
      {confirming && (
        <ChoiceDialog<'delete'>
          title="Delete this entry?"
          message="This cannot be undone."
          choices={[{ label: 'Delete', value: 'delete', danger: true }]}
          onChoose={onDelete}
          onCancel={() => setConfirming(false)}
        />
      )}
    </>
  )
}

export function ListScreen({
  kind,
  entries,
  addPlaceholder,
  emptyText,
  withNotes,
  sectioned = false,
  urgency = false,
  today = '',
  onToast,
}: Props) {
  const [text, setText] = useState('')
  const [addTo, setAddTo] = useState<ListSection>('groceries')
  const [editing, setEditing] = useState<ListEntry | null>(null)
  const visible = entries.filter((e) => !e.done)
  // Shopping: the tab you are on (Groceries / General) is both the list you see and where new items go.
  const shown = sectioned
    ? visible.filter((e) => sectionOf(e) === addTo)
    : urgency
      ? sortTodos(visible, today)
      : visible
  const sectionLabel = SHOPPING_SECTIONS.find((s) => s.id === addTo)?.label.toLowerCase()

  async function add() {
    const title = text.trim()
    if (!title) return
    setText('')
    await storeFor(kind).add(title, '', sectioned ? addTo : undefined)
  }

  function check(entry: ListEntry) {
    void setEntryDone(kind, entry, true)
    onToast(`"${entry.title}" done`, () => void setEntryDone(kind, entry, false))
  }

  const reorder = (group: ListEntry[], from: number, to: number) => {
    if (!urgency) return void moveEntry(kind, group, entries, from, to)
    // Urgency groups are fixed by due date and flag, so a drag only reorders within its own group
    const g = urgencyGroup(group[from], today)
    if (urgencyGroup(group[to], today) !== g) return
    const sub = group.filter((e) => urgencyGroup(e, today) === g)
    void moveEntry(kind, sub, entries, sub.indexOf(group[from]), sub.indexOf(group[to]))
  }

  return (
    <div className="list-screen">
      <form
        className="add-bar"
        onSubmit={(e) => {
          e.preventDefault()
          void add()
        }}
      >
        {sectioned && (
          <div className="add-section">
            <SectionPicker value={addTo} onChange={setAddTo} label="Shopping list" />
          </div>
        )}
        <div className="add-row">
          <input
            className="input"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={addPlaceholder}
            enterKeyHint="done"
          />
          <button className="btn primary" type="submit" disabled={!text.trim()}>
            Add
          </button>
        </div>
      </form>

      {shown.length === 0 ? (
        <p className="muted agenda-empty">{sectioned ? `Nothing on your ${sectionLabel} list.` : emptyText}</p>
      ) : (
        // key resets the drag context when switching tabs
        <SortableGroup key={sectioned ? addTo : "all"} entries={shown} today={urgency ? today : undefined} onCheck={check} onEdit={setEditing} onReorder={reorder} />
      )}

      {editing && (
        <EntryEditor
          key={editing.id}
          entry={editing}
          withNotes={withNotes}
          sectioned={sectioned}
          withUrgency={urgency}
          onClose={() => setEditing(null)}
          onSave={async (patch) => {
            // Moved to the other list: put it at the bottom there
            if (patch.section && patch.section !== sectionOf(editing)) {
              patch.order = entries.reduce((max, e) => Math.max(max, e.order), 0) + ORDER_GAP
            }
            await storeFor(kind).update(editing.id, patch)
            setEditing(null)
          }}
          onDelete={async () => {
            await storeFor(kind).remove(editing.id)
            setEditing(null)
          }}
        />
      )}
    </div>
  )
}
