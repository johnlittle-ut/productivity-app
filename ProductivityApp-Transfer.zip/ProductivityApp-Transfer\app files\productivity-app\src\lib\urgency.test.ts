import { expect, it } from 'vitest'
import type { ListEntry } from '../types'
import { isUrgent, sortTodos } from './urgency'

const e = (title: string, order: number, extra: Partial<ListEntry> = {}): ListEntry => ({
  id: title,
  updatedAt: 0,
  title,
  notes: '',
  done: false,
  doneAt: null,
  createdAt: 1,
  order,
  ...extra,
})

it('urgent = flagged or due within 7 days (overdue too); sorted soonest due, then flagged, then the rest, keeping manual order', () => {
  const today = '2026-11-04'
  const list = [
    e('plain-1', 1),
    e('far-due', 2, { dueDate: '2026-11-20' }), // more than a week out: not urgent
    e('flagged', 3, { urgent: true }),
    e('due-in-7', 4, { dueDate: '2026-11-11' }), // exactly 7 days: urgent
    e('overdue', 5, { dueDate: '2026-11-01' }),
    e('due-in-8', 6, { dueDate: '2026-11-12' }), // 8 days: not urgent
    e('due-in-7-b', 7, { dueDate: '2026-11-11' }), // same day as due-in-7: manual order breaks the tie
    e('flagged-far', 8, { urgent: true, dueDate: '2026-12-25' }),
    e('plain-2', 9),
  ]

  expect(list.filter((x) => isUrgent(x, today)).map((x) => x.title)).toEqual(['flagged', 'due-in-7', 'overdue', 'due-in-7-b', 'flagged-far'])
  expect(sortTodos(list, today).map((x) => x.title)).toEqual([
    'overdue',
    'due-in-7',
    'due-in-7-b',
    'flagged',
    'flagged-far',
    'plain-1',
    'far-due',
    'due-in-8',
    'plain-2',
  ])
})
