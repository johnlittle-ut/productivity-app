import { dayOfWeek, parseDate } from './dates'

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

let hour24 = false
/** 12 or 24 hour display, set from Settings. */
export function setTimeFormat(f: '12' | '24' | undefined): void {
  hour24 = f === '24'
}

/** '18:30' -> '6:30 PM' (or '18:30' in 24-hour mode) */
export function formatTime(hhmm: string): string {
  const [h, m] = hhmm.split(':').map(Number)
  if (hour24) return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
  const suffix = h >= 12 ? 'PM' : 'AM'
  return `${h % 12 === 0 ? 12 : h % 12}:${String(m).padStart(2, '0')} ${suffix}`
}

/** '2026-11-04' -> '11/4' */
export function shortDate(date: string): string {
  const { m, d } = parseDate(date)
  return `${m}/${d}`
}

export function weekdayName(date: string): string {
  return DAY_NAMES[dayOfWeek(date)]
}

/** '18:30' -> '6:30pm' (compact, for the time-first item layout) */
export function formatTimeShort(hhmm: string): string {
  return hour24 ? formatTime(hhmm) : formatTime(hhmm).replace(' ', '').toLowerCase()
}

/** Plain-text version of an item line: '6:30pm - Thrive'. */
export function itemText(title: string, startTime: string | null): string {
  return startTime ? `${formatTimeShort(startTime)} - ${title}` : title
}

const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

/** '2026-11-02' + '2026-11-08' -> 'Nov 2 – 8'; across months -> 'Oct 26 – Nov 1' */
export function weekRangeLabel(start: string, end: string): string {
  const a = parseDate(start)
  const b = parseDate(end)
  const left = `${MONTH_SHORT[a.m - 1]} ${a.d}`
  if (a.y === b.y && a.m === b.m) return `${left} – ${b.d}`
  const right = `${MONTH_SHORT[b.m - 1]} ${b.d}`
  return a.y === b.y ? `${left} – ${right}` : `${left}, ${a.y} – ${right}, ${b.y}`
}

/** 'Wednesday, Nov 4' */
export function longDate(date: string): string {
  const { m, d } = parseDate(date)
  return `${weekdayName(date)}, ${MONTH_SHORT[m - 1]} ${d}`
}
