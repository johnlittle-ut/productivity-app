import { useEffect, useState } from 'react'
import { browserTimezone } from './dates'

/** The device's current timezone; re-read when the app returns to the foreground (so travel is picked up). */
export function useDeviceTimezone(): string {
  const [tz, setTz] = useState(browserTimezone)
  useEffect(() => {
    const update = () => setTz(browserTimezone())
    document.addEventListener('visibilitychange', update)
    window.addEventListener('focus', update)
    return () => {
      document.removeEventListener('visibilitychange', update)
      window.removeEventListener('focus', update)
    }
  }, [])
  return tz
}
