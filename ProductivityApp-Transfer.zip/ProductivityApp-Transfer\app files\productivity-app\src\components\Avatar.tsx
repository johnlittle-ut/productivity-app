import { groupColorVar, initials, type Member } from '../groups/model'

export function Avatar({ member, size = 28 }: { member: Pick<Member, 'name' | 'color'>; size?: number }) {
  return (
    <span
      className="avatar"
      style={{ background: groupColorVar(member.color), width: size, height: size, fontSize: Math.round(size * 0.4) }}
      title={member.name}
    >
      {initials(member.name)}
    </span>
  )
}
